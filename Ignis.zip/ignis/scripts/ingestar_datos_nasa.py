"""Ingesta de datos NASA nuevos (CSV/JSON en `data/raw/`) hacia el catálogo de investigaciones.

Qué hace: lee cada archivo nuevo, mapea sus columnas a los campos del catálogo (O₂, flujo, presión, hardware, objetivos…),
agrega por investigación y escribe `data/investigaciones_ingestadas.json` (superposición que la API aplica sola,
sin reiniciar). Reglas:
  - NO adivina: una columna cuyo significado o unidad no es claro se omite y se informa.
  - Un valor que contradice uno ya conocido del catálogo se registra como CONFLICTO y no lo sobrescribe.
  - Un formato que no coincide NUNCA rompe la API: el archivo se reporta como fallido y se sigue con el resto.
  - Reporte completo en `data/processed/investigaciones_ingestadas_reporte.json`.
Uso: python scripts/ingestar_datos_nasa.py [--raw data/raw] [--forzar] [--estricto]
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import logging
import re
import sys
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.investigaciones import Investigacion, cargar_catalogo  # noqa: E402
from src.clasificador import clasificar  # noqa: E402
from src.tablas_psi import ADAPTADORES, extraer as extraer_psi, fusionar_rango, numero_psi, unir_rangos  # noqa: E402

logger = logging.getLogger("ingestar_datos_nasa")
RAIZ = Path(__file__).resolve().parent.parent
RAW = RAIZ / "data" / "raw"
SALIDA = RAIZ / "data" / "investigaciones_ingestadas.json"  # junto al catálogo: la API la aplica sola
REPORTE = RAIZ / "data" / "processed" / "investigaciones_ingestadas_reporte.json"
MANIFIESTO = RAIZ / "data" / "processed" / "investigaciones_ingestadas_manifiesto.json"
MAX_BYTES = 50 * 1024 * 1024
PSI_KPA = 6.894757


def _norm(texto: object) -> str:
    t = unicodedata.normalize("NFKD", str(texto)).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "", t)


# campo del catálogo -> patrones de nombre de columna (sobre el nombre normalizado)
SINONIMOS: dict[str, re.Pattern[str]] = {
    "investigacion": re.compile(r"^(investigacion|investigation|experiment|experimento|nombre|name|id|acronym|acronimo|study|estudio)$"),
    "objetivos": re.compile(r"^(objetivos?|objectives?|goals?|description|descripcion|purpose|abstract)$"),
    "combustible_detalle": re.compile(r"^(fuel|combustible|material|fuelmaterial|sample|muestra)$"),
    "hardware": re.compile(r"^(hardware|apparatus|facility|instrumento|instrument|rack)$"),
    "instalacion": re.compile(r"^(location|ubicacion|instalacion|platform|plataforma)$"),
    "o2": re.compile(r"^(o2|oxygen|oxigeno)(percent|pct|porcentaje|fraction|fraccion|concentration|concentracion|volpct|mole|molefraction)?$|^(o2|oxygen|oxigeno)$"),
    "flujo": re.compile(r"^(flow|flujo|airflow|flowspeed|flowvelocity|velocidadflujo|flowrate)(cms|cmpers|ms|mpers|mms)?$"),
    "presion": re.compile(r"^(pressure|presion|p|ptotal|totalpressure)(kpa|psi|pa|atm|bar)?$"),
}


def mapear_columnas(columnas: list[str]) -> dict[str, str]:
    """Columna original -> campo canónico; solo columnas inequívocas (la primera que coincide gana)."""
    mapa: dict[str, str] = {}
    usados: set[str] = set()
    for col in columnas:
        n = _norm(re.sub(r"\(.*?\)|\[.*?\]", "", col)) or _norm(col)
        for campo, patron in SINONIMOS.items():
            if campo not in usados and (patron.match(n) or patron.match(_norm(col))):
                mapa[col] = campo
                usados.add(campo)
                break
    return mapa


def _unidad(col: str) -> str:
    """Unidad declarada en el nombre de la columna ('' si no hay)."""
    m = re.search(r"\((.*?)\)|\[(.*?)\]", col)
    texto = (m.group(1) or m.group(2)) if m else col
    return _norm(texto)


def _numero(v: Any) -> float | None:
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v)
    try:
        return float(str(v).strip().replace(",", "."))
    except ValueError:
        return None


def convertir(campo: str, columna: str, valor: Any) -> tuple[float | None, str | None]:
    """Valor en unidades del catálogo (O₂ en %, flujo en cm/s, presión en kPa) o motivo de omisión."""
    x = _numero(valor)
    if x is None:
        return None, None  # celda vacía o no numérica: se ignora sin ruido
    u, n = _unidad(columna), _norm(columna)
    if campo == "o2":
        if "fraction" in n or "fraccion" in n:
            return x * 100, None
        if "percent" in n or "pct" in n or "porcentaje" in n or u in {"", "o2"} and x > 1.0 or "%" in columna:
            return x, None
        return None, f"O₂ ambiguo en '{columna}' (¿fracción o %?)"
    if campo == "flujo":
        if "cms" in u or "cmpers" in u or "cmsec" in u or n.endswith("cms"):
            return x, None
        if u in {"ms", "mpers"} or n.endswith("ms") and "cm" not in n and "mm" not in n:
            return x * 100, None
        if "mms" in u or "mmpers" in u:
            return x / 10, None
        return None, f"unidad de flujo no reconocida en '{columna}'"
    if campo == "presion":
        if "kpa" in u or "kpa" in n:
            return x, None
        if "psi" in u or "psi" in n:
            return x * PSI_KPA, None
        if u == "pa" or n.endswith("pa") and "kpa" not in n:
            return x / 1000, None
        if "atm" in u:
            return x * 101.325, None
        if "bar" in u:
            return x * 100, None
        return None, f"unidad de presión no reconocida en '{columna}'"
    return None, None


def leer_tabla(ruta: Path) -> list[dict[str, Any]]:
    """Filas de un CSV o JSON (lista de objetos, o un objeto con una lista de objetos).

    Raises:
        ValueError: formato ilegible o sin filas.
    """
    if ruta.stat().st_size > MAX_BYTES:
        raise ValueError("archivo demasiado grande")
    if ruta.suffix.lower() == ".csv":
        with ruta.open(encoding="utf-8-sig", newline="") as f:
            muestra = f.read(4096)
            f.seek(0)
            try:
                dialecto = csv.Sniffer().sniff(muestra, delimiters=",;\t|")
            except csv.Error:
                dialecto = csv.excel
            filas = [dict(f_) for f_ in csv.DictReader(f, dialect=dialecto)]
    else:
        crudo = json.loads(ruta.read_text(encoding="utf-8"))
        if isinstance(crudo, dict):
            crudo = next((v for v in crudo.values() if isinstance(v, list) and v and isinstance(v[0], dict)), None)
        if not isinstance(crudo, list):
            raise ValueError("el JSON no contiene una lista de objetos")
        filas = [x for x in crudo if isinstance(x, dict)]
    if not filas:
        raise ValueError("sin filas")
    return filas


def _slug(nombre: str) -> str | None:
    """Identificador válido para la API (`^[a-z0-9][a-z0-9-]{1,39}$`) a partir del nombre; None si no se puede formar."""
    t = unicodedata.normalize("NFKD", nombre).encode("ascii", "ignore").decode().lower()
    t = re.sub(r"[^a-z0-9]+", "-", t).strip("-")[:39].strip("-")
    return t if re.fullmatch(r"[a-z0-9][a-z0-9-]{1,39}", t) else None


def _investigacion_nueva(id_: str, nombre: str, a: dict[str, Any], archivo: str) -> dict[str, Any]:
    """Ficha mínima y HONESTA de una investigación que el catálogo no tenía: solo lo que el archivo trae; el resto, desconocido."""
    rango = lambda v: {"min": round(min(v), 3), "max": round(max(v), 3)} if v else {"min": None, "max": None}  # noqa: E731
    conocidos = {"o2_pct": bool(a["o2"]), "flujo_cm_s": bool(a["flujo"]), "presion_kpa": bool(a["presion"])}
    sug = clasificar(nombre, a["combustible_detalle"] or "", " ".join(a["hardware"]), a["objetivos"] or "")
    sugerido = " Clasificación SUGERIDA por palabras clave (" + "; ".join(sug["motivos"]) + "): confirmar." if sug["motivos"] else ""
    return {
        "id": id_, "nombre": nombre[:60], "nombre_completo": nombre[:120], "familia": sug["familia"], "combustible_tipos": sug["combustible_tipos"],
        "combustible_detalle": a["combustible_detalle"] or "No declarado en el archivo", "hardware": sorted(a["hardware"]),
        "instalacion": a["instalacion"] or "No declarada en el archivo", "objetivos": a["objetivos"] or "No declarados en el archivo",
        "areas_seguridad": sug["areas_seguridad"], "o2_pct": rango(a["o2"]), "flujo_cm_s": rango(a["flujo"]) if a["flujo"] else None,
        "presion_kpa": rango(a["presion"]) if a["presion"] else None, "gravedad": "desconocida", "datos_en_psi": None,
        "campos_no_verificados": ["familia", "combustible_tipos", "areas_seguridad", "gravedad", "datos_en_psi",
                                  *[c for c, ok in conocidos.items() if not ok]],
        "fuente": f"Ingesta de {archivo}: investigación NO incluida en el catálogo del equipo; gravedad sin clasificar; familia, combustible y áreas, solo si hay pistas, como sugerencia." + sugerido,
    }


def buscar_investigacion(nombre: str, catalogo: list[Investigacion]) -> Investigacion | None:
    n = _norm(nombre)
    if not n:
        return None
    for inv in catalogo:
        if n in {_norm(inv.id), _norm(inv.nombre), _norm(inv.nombre_completo)}:
            return inv
    return None


def procesar_tabla_psi(ruta: Path, catalogo: list[Investigacion]) -> dict[str, Any]:
    """Tabla experimental del PSI (PSI-xx_…): lector tolerante + relleno de huecos sin pisar lo conocido. Devuelve el mismo contrato + `calidad`."""
    r = extraer_psi(ruta)
    base = next((i for i in catalogo if i.id == r["id"]), None)
    conflictos: list[str] = []
    if base is None:
        a = {"o2": r["o2"], "flujo": r["flujo"], "presion": r["presion"], "hardware": set(), "objetivos": None, "combustible_detalle": r["combustible_detalle"], "instalacion": None}
        nuevas = {r["id"]: _investigacion_nueva(r["id"], r["nombre"], a, ruta.name)} if (a["o2"] or a["flujo"] or a["presion"]) else {}
        nuevas and nuevas[r["id"]].update(datos_en_psi=True)
        nuevas and nuevas[r["id"]]["campos_no_verificados"].remove("datos_en_psi")
        return {"actualizaciones": {}, "nuevas": nuevas, "no_mapeadas": [], "omitidas": [], "conflictos": [], "columnas_ignoradas": [], "calidad": r["calidad"]}
    cambios: dict[str, Any] = {"fuente_ingesta": ruta.name}
    for campo, atributo in (("o2", "o2_pct"), ("flujo", "flujo_cm_s"), ("presion", "presion_kpa")):
        if r[campo]:
            nuevo = {"min": round(min(r[campo]), 3), "max": round(max(r[campo]), 3)}
            aplicar, aviso = fusionar_rango(getattr(base, atributo), nuevo)
            if aviso:
                conflictos.append(f"{base.id}.{atributo}: {aviso}")
            if aplicar:
                cambios[atributo] = aplicar
    if r["combustible_detalle"] and "combustible_detalle" in base.campos_no_verificados:
        cambios["combustible_detalle"] = r["combustible_detalle"]
    if base.datos_en_psi is not True:
        cambios["datos_en_psi"] = True  # la tabla experimental existe en el PSI y se cargó
    return {"actualizaciones": {base.id: cambios} if len(cambios) > 1 else {}, "nuevas": {}, "no_mapeadas": [], "omitidas": [], "conflictos": conflictos,
            "columnas_ignoradas": [], "calidad": r["calidad"]}


def procesar_archivo(ruta: Path, catalogo: list[Investigacion]) -> dict[str, Any]:
    """Mapea un archivo. Devuelve {actualizaciones, no_mapeadas, omitidas, conflictos, columnas_ignoradas}."""
    if numero_psi(ruta.name) is not None and ruta.suffix.lower() == ".csv":
        return procesar_tabla_psi(ruta, catalogo)
    filas = leer_tabla(ruta)
    columnas = list(filas[0].keys())
    mapa = mapear_columnas(columnas)
    if "investigacion" not in mapa.values():
        raise ValueError(f"sin columna de identificación de la investigación (columnas: {columnas[:8]})")
    col = {v: k for k, v in mapa.items()}
    acum: dict[str, dict[str, Any]] = {}
    candidatas: dict[str, dict[str, Any]] = {}  # nombre → valores, para investigaciones que aún no están en el catálogo
    no_mapeadas: set[str] = set()
    nombres_nuevos: dict[str, str] = {}
    omitidas: list[str] = []
    for fila in filas:
        nombre = str(fila.get(col["investigacion"], "")).strip()
        inv = buscar_investigacion(nombre, catalogo)
        if inv is None:
            id_nuevo = _slug(nombre) if nombre else None
            if id_nuevo is None:
                if nombre:
                    no_mapeadas.add(nombre)
                continue
            clave, ficha = id_nuevo, True
            nombres_nuevos.setdefault(id_nuevo, nombre)
        else:
            clave, ficha = inv.id, False
        a = acum.setdefault(clave, {"o2": [], "flujo": [], "presion": [], "hardware": set(), "objetivos": None, "combustible_detalle": None,
                                    "instalacion": None})
        for campo in ("o2", "flujo", "presion"):
            if campo in col:
                v, aviso = convertir(campo, col[campo], fila.get(col[campo]))
                if aviso and aviso not in omitidas:
                    omitidas.append(aviso)
                if v is not None:
                    a[campo].append(v)
        for campo in ("hardware",):
            if campo in col and str(fila.get(col[campo], "")).strip():
                a["hardware"].update(x.strip() for x in re.split(r"[;,|]", str(fila[col[campo]])) if x.strip())
        for campo in ("objetivos", "combustible_detalle", "instalacion"):
            if campo in col and not a[campo] and str(fila.get(col[campo], "")).strip():
                a[campo] = str(fila[col[campo]]).strip()[:600]
    actualizaciones: dict[str, dict[str, Any]] = {}
    nuevas: dict[str, dict[str, Any]] = {}
    conflictos: list[str] = []
    for id_, a in acum.items():
        if id_ in nombres_nuevos:
            if a["o2"] or a["flujo"] or a["presion"] or a["hardware"] or a["objetivos"]:
                nuevas[id_] = _investigacion_nueva(id_, nombres_nuevos[id_], a, ruta.name)
            else:
                no_mapeadas.add(nombres_nuevos[id_])  # sin ningún dato utilizable: no se crea una ficha vacía
            continue
        base = next(i for i in catalogo if i.id == id_)
        cambios: dict[str, Any] = {"fuente_ingesta": ruta.name}
        for campo, atributo in (("o2", "o2_pct"), ("flujo", "flujo_cm_s"), ("presion", "presion_kpa")):
            if not a[campo]:
                continue
            nuevo = {"min": round(min(a[campo]), 3), "max": round(max(a[campo]), 3)}
            actual = getattr(base, atributo)
            if actual is None or (actual.min is None and actual.max is None):
                cambios[atributo] = nuevo
            elif (actual.min, actual.max) != (nuevo["min"], nuevo["max"]):
                conflictos.append(f"{id_}.{atributo}: catálogo {actual.min}-{actual.max} vs archivo {nuevo['min']}-{nuevo['max']} (se conserva el catálogo)")
        if a["hardware"] and not base.hardware:
            cambios["hardware"] = sorted(a["hardware"])
        for campo in ("objetivos", "combustible_detalle", "instalacion"):
            if a[campo] and campo in base.campos_no_verificados:
                cambios[campo] = a[campo]
        if len(cambios) > 1:
            actualizaciones[id_] = cambios
    ignoradas = [c for c in columnas if c not in mapa]
    return {"actualizaciones": actualizaciones, "nuevas": nuevas, "no_mapeadas": sorted(no_mapeadas), "omitidas": omitidas, "conflictos": conflictos,
            "columnas_ignoradas": ignoradas}


def _hash(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


def ingestar(raw: Path = RAW, salida: Path = SALIDA, reporte: Path = REPORTE, manifiesto: Path = MANIFIESTO, forzar: bool = False) -> dict[str, Any]:
    """Procesa los archivos nuevos de `raw` y actualiza la superposición. Nunca lanza por un archivo malo."""
    catalogo = cargar_catalogo()
    vistos = {}
    if manifiesto.exists() and not forzar:
        try:
            vistos = json.loads(manifiesto.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            logger.warning("Manifiesto ilegible: se reprocesa todo")
    previo: dict[str, dict[str, Any]] = {}
    nuevas_acum: dict[str, dict[str, Any]] = {}
    if salida.exists():
        try:
            previa = json.loads(salida.read_text(encoding="utf-8"))
            nuevas_acum = {n["id"]: n for n in previa.get("nuevas", []) if isinstance(n, dict) and "id" in n}  # las fichas nuevas se conservan siempre
            if not forzar:
                previo = previa.get("actualizaciones", {})
        except (OSError, json.JSONDecodeError):
            logger.warning("Superposición previa ilegible: se descarta")
    archivos = sorted(p for p in raw.rglob("*") if p.is_file() and p.suffix.lower() in {".csv", ".json"} and "gases" not in p.relative_to(raw).parts)  # data/raw/gases = datos del modo gas if raw.exists() else []
    informe: dict[str, Any] = {"generado": datetime.now(timezone.utc).isoformat(), "archivos": [], "actualizaciones_totales": 0}
    actualizaciones = dict(previo)
    for ruta in archivos:
        rel = ruta.relative_to(raw).as_posix()
        try:
            h = _hash(ruta)
            if vistos.get(rel) == h:
                informe["archivos"].append({"archivo": rel, "estado": "sin_cambios"})
                continue
            r = procesar_archivo(ruta, catalogo)
            for id_, cambios in r["actualizaciones"].items():
                destino = actualizaciones.setdefault(id_, {})
                for atributo in ("o2_pct", "flujo_cm_s", "presion_kpa"):  # varias tablas de una misma investigación: se unen los rangos
                    if atributo in cambios and atributo in destino:
                        cambios[atributo] = unir_rangos(destino[atributo], cambios[atributo])
                destino.update(cambios)
            for id_, ficha in r["nuevas"].items():  # idem para investigaciones nuevas con varias tablas
                if id_ in nuevas_acum:
                    for atributo in ("o2_pct", "flujo_cm_s", "presion_kpa"):
                        if ficha.get(atributo) and ficha[atributo].get("min") is not None:
                            ficha[atributo] = unir_rangos(nuevas_acum[id_].get(atributo) if (nuevas_acum[id_].get(atributo) or {}).get("min") is not None else None, ficha[atributo])
            nuevas_acum.update(r["nuevas"])
            vistos[rel] = h
            estado = "ok" if (r["actualizaciones"] or r["nuevas"] or r.get("calidad")) else "sin_coincidencias"
            informe["archivos"].append({"archivo": rel, "estado": estado, "investigaciones_actualizadas": sorted(r["actualizaciones"]), "investigaciones_nuevas": sorted(r["nuevas"]), "investigaciones_nuevas": sorted(r["nuevas"]),
                                        **{k: r[k] for k in ("no_mapeadas", "omitidas", "conflictos", "columnas_ignoradas")}, **({"calidad": r["calidad"]} if "calidad" in r else {})})
            logger.info("%s: %s (%d investigaciones)", rel, estado, len(r["actualizaciones"]))
        except (ValueError, OSError, json.JSONDecodeError, UnicodeDecodeError, csv.Error) as error:
            logger.warning("%s: FORMATO NO COINCIDE, se omite (%s)", rel, error)
            informe["archivos"].append({"archivo": rel, "estado": "fallido", "motivo": str(error)})
    informe["actualizaciones_totales"] = len(actualizaciones)
    informe["nuevas_totales"] = len(nuevas_acum)
    salida.parent.mkdir(parents=True, exist_ok=True)
    if actualizaciones or nuevas_acum:
        salida.write_text(json.dumps({"version": "1.1", "generado": informe["generado"], "actualizaciones": actualizaciones, "nuevas": list(nuevas_acum.values())}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    manifiesto.write_text(json.dumps(vistos, indent=2) + "\n", encoding="utf-8")
    reporte.write_text(json.dumps(informe, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return informe


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raw", type=Path, default=RAW)
    ap.add_argument("--forzar", action="store_true", help="reprocesa también los archivos ya ingeridos")
    ap.add_argument("--estricto", action="store_true", help="código de salida 1 si algún archivo falla")
    a = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    informe = ingestar(a.raw, forzar=a.forzar)
    fallidos = [x for x in informe["archivos"] if x["estado"] == "fallido"]
    print(f"Archivos: {len(informe['archivos'])} · fallidos: {len(fallidos)} · investigaciones con datos nuevos: {informe['actualizaciones_totales']} · investigaciones nuevas (provisionales): {informe['nuevas_totales']}")
    for x in informe["archivos"]:
        extra = f" · {x.get('motivo')}" if x["estado"] == "fallido" else ""
        print(f"  [{x['estado']}] {x['archivo']}{extra}")
        for n in x.get("investigaciones_nuevas", []):
            print(f"     NUEVA investigación (no estaba en el catálogo): {n} — se clasifica con evidencia baja hasta tener más datos")
        for c in x.get("conflictos", []):
            print(f"     CONFLICTO: {c}")
        for o in x.get("omitidas", []):
            print(f"     OMITIDO: {o}")
    if not informe["archivos"]:
        print(f"No hay CSV/JSON en {a.raw}. La API sigue sirviendo el catálogo actual.")
    return 1 if (a.estricto and fallidos) else 0


if __name__ == "__main__":
    sys.exit(main())
