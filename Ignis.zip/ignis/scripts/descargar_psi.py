"""Descarga de datos del repositorio PSI (Physical Sciences Informatics) de NASA hacia `data/raw/psi/`.

IMPORTANTE (verificado, ver docs/psi_integracion.md): PSI NO documenta una API pública para
Saffire/FLEX/BASS. Sus datos requieren registro (≈24 h) y descarga desde la web. Este script cubre
las tres vías reales y es honesto sobre lo que no puede hacer:

1. ``--url``: descarga directa de un enlace (p. ej. el .zip masivo que PSI envía tras el registro),
   con verificación SHA-256 opcional y extracción segura (guarda contra zip-slip y zip-bombs).
2. ``--prefijo``: listado y descarga del bucket S3 público anónimo ``nasa-psi`` (ListObjectsV2),
   verificando tamaño y MD5/ETag. Hoy solo contiene ``DSI/``, ``OASIS/`` y ``pk4/`` (sin combustión).
3. ``--manual``: imprime los pasos de descarga manual y la carpeta destino.

Seguridad: solo HTTPS, lista blanca de hosts, tope de tamaño, nombres de archivo saneados.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from src.lector_psi import CATALOGO_PSI

logger = logging.getLogger("ignis.descargar_psi")

PORTAL_PSI = "https://science.nasa.gov/biological-physical/data/"
BUSQUEDA_PSI = "https://psi.nasa.gov/physci/repo/search?q=&data_source=psi&data_type=investigation"
HOST_BUCKET = "nasa-psi.s3.us-west-2.amazonaws.com"
HOSTS_PERMITIDOS = frozenset({HOST_BUCKET, "nasa-psi.s3.amazonaws.com", "psi.nasa.gov", "science.nasa.gov"})
TOPE_BYTES = 2 * 1024**3  # 2 GiB por descarga
TOPE_DESCOMPRIMIDO = 8 * 1024**3
NOMBRE_MANIFIESTO = "descargas.json"
_NS_S3 = "{http://s3.amazonaws.com/doc/2006-03-01/}"

# Un transporte recibe una URL y devuelve los bytes; es inyectable para pruebas (sin red).
Transporte = Callable[[str], bytes]


class ErrorDescargaPsi(RuntimeError):
    """Fallo de descarga, verificación o extracción (mensaje accionable)."""


@dataclass(frozen=True)
class ObjetoRemoto:
    """Objeto listado en el bucket."""

    clave: str
    tamano: int
    etag: str


@dataclass(frozen=True)
class ArchivoDescargado:
    """Archivo ya en disco con su huella."""

    ruta: Path
    tamano: int
    sha256: str
    origen: str


def _validar_url(url: str) -> None:
    partes = urllib.parse.urlsplit(url)
    if partes.scheme != "https":
        raise ErrorDescargaPsi(f"Solo se permite HTTPS: {url!r}")
    if partes.hostname not in HOSTS_PERMITIDOS:
        raise ErrorDescargaPsi(f"Host no permitido ({partes.hostname}). Permitidos: {sorted(HOSTS_PERMITIDOS)}")


def transporte_https(url: str, timeout: float = 60.0) -> bytes:
    """Transporte real: GET HTTPS con lista blanca y tope de tamaño."""
    _validar_url(url)
    peticion = urllib.request.Request(url, headers={"User-Agent": "IGNIS-descargar-psi/1.0"})
    try:
        with urllib.request.urlopen(peticion, timeout=timeout) as resp:  # noqa: S310 (esquema y host validados)
            datos = resp.read(TOPE_BYTES + 1)
    except urllib.error.HTTPError as exc:
        raise ErrorDescargaPsi(_explicar_http(exc.code, url)) from exc
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise ErrorDescargaPsi(f"Sin conexión con {url}: {exc}") from exc
    if len(datos) > TOPE_BYTES:
        raise ErrorDescargaPsi(f"La descarga supera el tope de {TOPE_BYTES} bytes")
    return datos


def _explicar_http(codigo: int, url: str) -> str:
    if codigo in (401, 403):
        return (f"HTTP {codigo} en {url}: requiere autenticación/permiso. Los datos de combustión de PSI exigen "
                f"registro; sigue `--manual` y usa luego `--url` con el enlace/zip recibido.")
    if codigo == 404:
        return f"HTTP 404: no existe {url}. Revisa el prefijo con `--lista`."
    return f"HTTP {codigo} al pedir {url}"


def sha256_bytes(datos: bytes) -> str:
    return hashlib.sha256(datos).hexdigest()


def nombre_seguro(nombre: str) -> str:
    """Reduce una clave remota/ruta de zip a un nombre de archivo seguro (sin directorios ni '..')."""
    base = nombre.replace("\\", "/").rsplit("/", 1)[-1]
    limpio = re.sub(r"[^A-Za-z0-9._-]", "_", base).lstrip(".")
    if not limpio:
        raise ErrorDescargaPsi(f"Nombre de archivo inválido: {nombre!r}")
    return limpio


def listar_bucket(prefijo: str, transporte: Transporte = transporte_https, max_objetos: int = 1000) -> list[ObjetoRemoto]:
    """Lista objetos del bucket público con ListObjectsV2 (sin credenciales)."""
    consulta = urllib.parse.urlencode({"list-type": "2", "prefix": prefijo, "max-keys": str(max_objetos)})
    cuerpo = transporte(f"https://{HOST_BUCKET}/?{consulta}")
    try:
        raiz = ET.fromstring(cuerpo)  # noqa: S314 (respuesta de host permitido; sin entidades externas en ElementTree)
    except ET.ParseError as exc:
        raise ErrorDescargaPsi(f"Respuesta de listado ilegible: {exc}") from exc
    if raiz.tag.endswith("Error"):
        codigo = raiz.findtext("Code") or raiz.findtext(f"{_NS_S3}Code") or "desconocido"
        raise ErrorDescargaPsi(f"El bucket respondió con error {codigo}")
    objetos = []
    for nodo in list(raiz.iter(f"{_NS_S3}Contents")) + list(raiz.iter("Contents")):
        clave = nodo.findtext(f"{_NS_S3}Key") or nodo.findtext("Key") or ""
        tam = nodo.findtext(f"{_NS_S3}Size") or nodo.findtext("Size") or "0"
        etag = (nodo.findtext(f"{_NS_S3}ETag") or nodo.findtext("ETag") or "").strip('"')
        if clave and not clave.endswith("/"):
            objetos.append(ObjetoRemoto(clave=clave, tamano=int(tam), etag=etag))
    return objetos


def verificar_integridad(datos: bytes, *, tamano: int | None = None, etag: str | None = None,
                         sha256: str | None = None) -> None:
    """Comprueba tamaño, MD5 (ETag S3 simple) y/o SHA-256 esperados; lanza ErrorDescargaPsi si no cuadran."""
    if tamano is not None and len(datos) != tamano:
        raise ErrorDescargaPsi(f"Tamaño distinto: esperado {tamano}, recibido {len(datos)} (descarga truncada)")
    if etag and "-" not in etag and hashlib.md5(datos).hexdigest() != etag.lower():  # noqa: S324 (ETag de S3, no seguridad)
        raise ErrorDescargaPsi("MD5/ETag no coincide: archivo corrupto")
    if sha256 and sha256_bytes(datos) != sha256.lower():
        raise ErrorDescargaPsi("SHA-256 no coincide con el esperado")


def _escribir(destino: Path, datos: bytes, origen: str) -> ArchivoDescargado:
    destino.parent.mkdir(parents=True, exist_ok=True)
    destino.write_bytes(datos)
    return ArchivoDescargado(ruta=destino, tamano=len(datos), sha256=sha256_bytes(datos), origen=origen)


def descargar_objetos(objetos: list[ObjetoRemoto], carpeta: Path, transporte: Transporte = transporte_https
                      ) -> list[ArchivoDescargado]:
    """Descarga y verifica (tamaño + MD5) cada objeto del bucket en `carpeta`."""
    resultado = []
    for obj in objetos:
        datos = transporte(f"https://{HOST_BUCKET}/{urllib.parse.quote(obj.clave)}")
        verificar_integridad(datos, tamano=obj.tamano, etag=obj.etag)
        resultado.append(_escribir(carpeta / nombre_seguro(obj.clave), datos, f"s3://nasa-psi/{obj.clave}"))
        logger.info("Descargado %s (%d bytes)", obj.clave, obj.tamano)
    return resultado


def extraer_zip_seguro(datos: bytes, carpeta: Path, origen: str) -> list[ArchivoDescargado]:
    """Extrae un zip aplanando rutas (anti zip-slip) y con tope de tamaño descomprimido (anti zip-bomb)."""
    import io

    try:
        zf = zipfile.ZipFile(io.BytesIO(datos))
    except zipfile.BadZipFile as exc:
        raise ErrorDescargaPsi("El archivo no es un zip válido") from exc
    with zf:
        miembros = [m for m in zf.infolist() if not m.is_dir()]
        if sum(m.file_size for m in miembros) > TOPE_DESCOMPRIMIDO:
            raise ErrorDescargaPsi("El zip descomprimido supera el tope permitido")
        salida = []
        for m in miembros:
            partes = Path(m.filename.replace("\\", "/")).parts
            if ".." in partes or m.filename.startswith(("/", "\\")):
                raise ErrorDescargaPsi(f"Ruta peligrosa en el zip: {m.filename!r}")
            salida.append(_escribir(carpeta / nombre_seguro(m.filename), zf.read(m), f"{origen}!{m.filename}"))
    return salida


def descargar_url(url: str, carpeta: Path, *, sha256_esperado: str | None = None,
                  transporte: Transporte = transporte_https) -> list[ArchivoDescargado]:
    """Descarga un enlace directo; si es .zip lo extrae de forma segura. Verifica SHA-256 si se da."""
    datos = transporte(url)
    verificar_integridad(datos, sha256=sha256_esperado)
    nombre = nombre_seguro(urllib.parse.urlsplit(url).path or "descarga.bin")
    if nombre.lower().endswith(".zip"):
        return extraer_zip_seguro(datos, carpeta, url)
    return [_escribir(carpeta / nombre, datos, url)]


def registrar_manifiesto(carpeta: Path, archivos: list[ArchivoDescargado]) -> Path:
    """Anexa las huellas al manifiesto `descargas.json` de la carpeta (trazabilidad de datos crudos)."""
    ruta = carpeta / NOMBRE_MANIFIESTO
    previo = json.loads(ruta.read_text(encoding="utf-8")) if ruta.exists() else []
    ahora = datetime.now(timezone.utc).isoformat(timespec="seconds")
    previo += [{"archivo": a.ruta.name, "bytes": a.tamano, "sha256": a.sha256, "origen": a.origen, "utc": ahora}
               for a in archivos]
    ruta.write_text(json.dumps(previo, indent=2, ensure_ascii=False), encoding="utf-8")
    return ruta


def instrucciones_manuales(clave: str, raiz: Path) -> str:
    exp = CATALOGO_PSI[clave]
    return (f"Descarga manual de {exp.nombre} ({clave}):\n"
            f"  1. Regístrate en {PORTAL_PSI} (aprobación ≈24 h por correo).\n"
            f"  2. Busca la investigación en {BUSQUEDA_PSI} y descarga CSV/HDF5/JSON (o el .zip masivo).\n"
            f"  3. Si recibes un enlace/zip: python -m scripts.descargar_psi --experimento {clave} --url <ENLACE> "
            f"[--sha256 <HUELLA>]\n"
            f"  4. O copia los archivos a {raiz / clave}/ y ejecuta: python -m src.pipeline_datos psi")


def _elegir_experimento() -> str:
    claves = sorted(CATALOGO_PSI)
    print("Experimentos PSI soportados:")
    for i, c in enumerate(claves, 1):
        print(f"  {i}. {c:<12} {CATALOGO_PSI[c].nombre} [{CATALOGO_PSI[c].rol.value}]")
    eleccion = input("Elige número o clave: ").strip().lower()
    if eleccion.isdigit() and 1 <= int(eleccion) <= len(claves):
        return claves[int(eleccion) - 1]
    if eleccion in CATALOGO_PSI:
        return eleccion
    raise ErrorDescargaPsi(f"Opción inválida: {eleccion!r}")


def main(argv: list[str] | None = None, transporte: Transporte = transporte_https) -> int:
    ap = argparse.ArgumentParser(description="Descarga datos PSI hacia data/raw/psi/<experimento>/")
    ap.add_argument("--experimento", choices=sorted(CATALOGO_PSI), help="si se omite, pregunta de forma interactiva")
    ap.add_argument("--raiz", type=Path, default=Path("data/raw/psi"))
    ap.add_argument("--url", help="enlace directo (p. ej. el .zip de PSI tras registrarte)")
    ap.add_argument("--sha256", help="SHA-256 esperado de --url")
    ap.add_argument("--prefijo", help="prefijo del bucket público nasa-psi")
    ap.add_argument("--lista", action="store_true", help="solo listar el bucket (con --prefijo)")
    ap.add_argument("--manual", action="store_true", help="mostrar pasos de descarga manual")
    args = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    try:
        if args.lista:
            for o in listar_bucket(args.prefijo or "", transporte):
                print(f"{o.tamano:>12}  {o.clave}")
            return 0
        clave = args.experimento or _elegir_experimento()
        carpeta = args.raiz / clave
        if args.manual or not (args.url or args.prefijo):
            print(instrucciones_manuales(clave, args.raiz))
            return 0
        if args.url:
            archivos = descargar_url(args.url, carpeta, sha256_esperado=args.sha256, transporte=transporte)
        else:
            archivos = descargar_objetos(listar_bucket(args.prefijo, transporte), carpeta, transporte)
        if not archivos:
            print("No se descargó ningún archivo.")
            return 1
        registrar_manifiesto(carpeta, archivos)
        print(f"{len(archivos)} archivo(s) en {carpeta}. Siguiente: python -m src.pipeline_datos psi")
        return 0
    except ErrorDescargaPsi as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
