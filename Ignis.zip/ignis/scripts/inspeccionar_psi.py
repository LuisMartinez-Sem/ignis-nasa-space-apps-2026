"""Diagnóstico previo a la ingesta: qué hay en `data/raw/psi/` y si el lector lo entiende.

No modifica nada ni versiona datos. Por carpeta informa archivos (nombre, tamaño, tipo), y por
tabla las columnas, dtypes, unidades declaradas, primeras filas y el resultado de `inferir_mapeo`
(variables que se mapearían y las que faltan). Uso:
    python -m scripts.inspeccionar_psi [--raiz data/raw/psi] [--json salida.json]
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from src.lector_psi import CATALOGO_PSI, ErrorLecturaPsi, descubrir_archivos, inferir_mapeo, leer_tabla


def _tamano_legible(n: int) -> str:
    for unidad in ("B", "KB", "MB", "GB"):
        if n < 1024 or unidad == "GB":
            return f"{n:.0f} {unidad}" if unidad == "B" else f"{n:.1f} {unidad}"
        n /= 1024
    return f"{n} B"


def inspeccionar_tabla(ruta: Path, experimento: str) -> dict[str, Any]:
    """Resume una tabla y evalúa si el lector sabría mapearla.

    Args:
        ruta: archivo CSV/JSON/HDF5.
        experimento: clave de carpeta (para el material y el rol por defecto).

    Returns:
        Diccionario serializable; si no se puede leer, trae `error` con la razón.
    """
    try:
        tabla = leer_tabla(ruta)
    except ErrorLecturaPsi as error:
        return {"archivo": ruta.name, "error": str(error)}
    resumen: dict[str, Any] = {
        "archivo": ruta.name, "formato": tabla.formato, "filas": int(len(tabla.datos)),
        "columnas": {c: str(t) for c, t in tabla.datos.dtypes.items()},
        "unidades_declaradas": tabla.unidades_declaradas,
        "cabeza": tabla.datos.head(3).astype(str).to_dict(orient="records"),
    }
    inferencia = inferir_mapeo(tabla, CATALOGO_PSI.get(experimento))
    resumen["mapeo_inferido"] = {k: v for k, v in inferencia.mapeo.get("columnas", {}).items()}
    resumen["faltantes"] = inferencia.faltantes
    resumen["supuestos"] = inferencia.supuestos
    resumen["entendido_por_el_lector"] = not inferencia.faltantes
    return resumen


def inspeccionar(raiz: Path) -> dict[str, Any]:
    """Recorre `raiz/<experimento>/` y devuelve el diagnóstico completo."""
    if not raiz.is_dir():
        raise FileNotFoundError(f"No existe {raiz}")
    informe: dict[str, Any] = {"raiz": str(raiz), "experimentos": {}, "avisos": []}
    leibles, avisos = descubrir_archivos(raiz)
    informe["avisos"] = avisos
    por_exp: dict[str, dict[str, Any]] = {}
    for carpeta in sorted(p for p in raiz.iterdir() if p.is_dir()):
        archivos = [{"nombre": a.name, "tamano": _tamano_legible(a.stat().st_size), "tipo": a.suffix.lower() or "(sin extensión)"}
                    for a in sorted(carpeta.rglob("*")) if a.is_file()]
        por_exp[carpeta.name] = {"en_catalogo": carpeta.name in CATALOGO_PSI, "archivos": archivos, "tablas": []}
    for a in leibles:
        por_exp.setdefault(a.experimento, {"en_catalogo": a.experimento in CATALOGO_PSI, "archivos": [], "tablas": []})
        por_exp[a.experimento]["tablas"].append(inspeccionar_tabla(a.ruta, a.experimento))
    informe["experimentos"] = por_exp
    return informe


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--raiz", type=Path, default=Path("data/raw/psi"))
    ap.add_argument("--json", type=Path, help="guarda el informe completo en este archivo")
    args = ap.parse_args(argv)
    try:
        informe = inspeccionar(args.raiz)
    except FileNotFoundError as error:
        sys.stderr.write(f"ERROR: {error}\n")
        return 2
    texto = json.dumps(informe, indent=2, ensure_ascii=False)
    if args.json:
        args.json.write_text(texto, encoding="utf-8")
    sys.stdout.write(texto + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
