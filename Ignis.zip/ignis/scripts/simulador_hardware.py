"""Simula un ESP32 que envía lecturas por POST a la API cada segundo (pruebas previas a comprar el hardware).

IMPORTANTE: los datos son SIMULADOS (ruido gaussiano sobre una trayectoria definida), no mediciones reales.
Uso: python scripts/simulador_hardware.py --escenario ignicion --duracion 60
"""

from __future__ import annotations

import argparse
import json
import logging
import random
import time
import urllib.error
import urllib.request
from typing import Any

logger = logging.getLogger("simulador_hardware")
ESCENARIOS = ("nominal", "ignicion", "llama-fria")
T_EVENTO_S = 15.0  # el evento empieza a los 15 s


def generar_lectura(t_s: float, escenario: str, rng: random.Random) -> dict[str, Any]:
    """Lectura del 'ESP32' en el instante t: condiciones válidas para `POST /api/v1/predict`.

    Args:
        t_s: segundos desde el arranque.
        escenario: uno de `ESCENARIOS`.
        rng: generador con semilla (reproducible).
    """
    if escenario not in ESCENARIOS:
        raise ValueError(f"Escenario desconocido: {escenario!r}. Válidos: {ESCENARIOS}")
    dt = max(0.0, t_s - T_EVENTO_S)
    o2, t_reaccion = 0.21, None
    if escenario == "ignicion":
        o2 = 0.21 + min(0.06, 0.004 * dt)
        t_reaccion = 295.0 + min(800.0, 120.0 * dt) if dt > 0 else None
    elif escenario == "llama-fria":
        t_reaccion = 295.0 + min(395.0, 130.0 * dt) if dt > 0 else None
    lectura: dict[str, Any] = {
        "fraccion_o2": round(min(0.40, max(0.16, o2 + rng.gauss(0, 0.001))), 4),
        "velocidad_flujo_cm_s": round(max(0.1, 10.0 + rng.gauss(0, 0.3)), 2),
        "presion_kpa": round(min(101.3, max(35.0, 101.0 + rng.gauss(0, 0.1))), 2),
        "temperatura_ambiente_k": round(295.0 + rng.gauss(0, 0.2), 2),
        "espesor_combustible_mm": 0.2,
        "material": "sibal",
        "regimen_flujo": "concurrente",
    }
    if t_reaccion is not None:
        lectura["temperatura_reaccion_k"] = round(t_reaccion + rng.gauss(0, 3.0), 1)
    return lectura


def enviar(url: str, lectura: dict[str, Any], timeout_s: float = 5.0) -> dict[str, Any]:
    """POST JSON a la API; devuelve la respuesta decodificada."""
    peticion = urllib.request.Request(url, data=json.dumps(lectura).encode(), headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(peticion, timeout=timeout_s) as respuesta:  # noqa: S310 (URL controlada por el operador)
        return json.loads(respuesta.read())


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--url", default="http://127.0.0.1:8000/api/v1/predict")
    ap.add_argument("--escenario", choices=ESCENARIOS, default="ignicion")
    ap.add_argument("--duracion", type=int, default=60, help="segundos a simular")
    ap.add_argument("--intervalo", type=float, default=1.0)
    ap.add_argument("--semilla", type=int, default=7)
    a = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    rng = random.Random(a.semilla)
    logger.info("Simulando ESP32 (datos SIMULADOS) -> %s", a.url)
    inicio = time.monotonic()
    for n in range(a.duracion):
        lectura = generar_lectura(n * a.intervalo, a.escenario, rng)
        try:
            r = enviar(a.url, lectura)
            logger.info("t=%3d s  O2=%.3f  Trx=%s  índice=%s  nivel=%s", n, lectura["fraccion_o2"],
                        lectura.get("temperatura_reaccion_k", "-"), r.get("indice_riesgo"), r.get("nivel_riesgo"))
        except (urllib.error.URLError, TimeoutError, ValueError) as error:
            logger.error("t=%3d s  fallo de envío: %s", n, error)
        time.sleep(max(0.0, inicio + (n + 1) * a.intervalo - time.monotonic()))


if __name__ == "__main__":
    main()
