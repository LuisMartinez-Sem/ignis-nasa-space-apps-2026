"""Regenera `src/investigaciones_respaldo.py` (catálogo y anclas de respaldo) desde los JSON de `data/`.

Ejecutar tras editar `data/investigaciones.json` o `data/anclas_reales.json`; un test verifica que no haya deriva.
"""

from __future__ import annotations

import json
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent


def main() -> None:
    catalogo = json.loads((RAIZ / "data" / "investigaciones.json").read_text(encoding="utf-8"))["investigaciones"]
    anclas = json.loads((RAIZ / "data" / "anclas_reales.json").read_text(encoding="utf-8"))["anclas"]
    filas_anclas = [{"id": a["id"], "valor": json.dumps(a.get("valor")), "uso": a.get("uso"), "verificacion": a.get("verificacion"),
                     "fuente_indicada": a.get("fuente_indicada"), "condiciones": json.dumps(a.get("condiciones"), ensure_ascii=False)} for a in anclas]
    salida = ('"""Respaldo HARDCODEADO del catálogo de investigaciones y de las anclas (el sistema nunca debe caerse).\n\n'
              'Generado por `scripts/regenerar_respaldo.py`; no editar a mano. Un test comprueba que coincide con los JSON de `data/`.\n"""\n\n'
              "from __future__ import annotations\n\nimport json\n\n"
              f"CATALOGO_RESPALDO_JSON = {json.dumps(json.dumps(catalogo, ensure_ascii=False))}\n"
              f"ANCLAS_RESPALDO_JSON = {json.dumps(json.dumps(filas_anclas, ensure_ascii=False))}\n\n"
              "CATALOGO_RESPALDO: list[dict] = json.loads(CATALOGO_RESPALDO_JSON)\n"
              "ANCLAS_RESPALDO: list[dict] = json.loads(ANCLAS_RESPALDO_JSON)\n")
    (RAIZ / "src" / "investigaciones_respaldo.py").write_text(salida, encoding="utf-8")
    print(f"Respaldo: {len(catalogo)} investigaciones, {len(filas_anclas)} anclas")


if __name__ == "__main__":
    main()
