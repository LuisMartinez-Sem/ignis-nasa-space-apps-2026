"""Entrena el modelo de gases (modo gas) con data/raw/gases/*.csv y lo guarda en data/processed/modelo_gas.joblib.
No toca el modelo de sólidos. Uso: PYTHONPATH=. python3 scripts/entrenar_gases.py"""
from __future__ import annotations

import json
from pathlib import Path

from src.modo_gas import ModeloGas, cargar_tablas_gas

RAIZ = Path(__file__).resolve().parent.parent


def main() -> None:
    datos = cargar_tablas_gas(RAIZ / "data/raw/gases")
    print(f"{len(datos)} ensayos útiles · tipo_combustible={datos['tipo_combustible'].unique().tolist()} · ignición {datos['ignicion'].mean():.0%}")
    print(datos.groupby(["archivo", "combustible"]).size().to_string())
    modelo = ModeloGas()
    met = modelo.validar(datos)
    modelo.entrenar(datos)
    modelo.metricas = met
    modelo.guardar(RAIZ / "data/processed/modelo_gas.joblib")
    (RAIZ / "data/processed/modelo_gas_metricas.json").write_text(json.dumps(met, indent=2, ensure_ascii=False))
    print(json.dumps(met, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
