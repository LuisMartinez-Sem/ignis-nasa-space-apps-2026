"""Empaquetado: genera el zip del proyecto completo (sin entornos, cachés ni datos de prueba)."""

from __future__ import annotations

import logging
import sys
import zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
DESTINO = RAIZ.parent / "ignis.zip"
REQUERIDOS_JS = ("emergencias.js", "bundle.js", "reconstruccion.js", "whatif.js")
EXCLUIDOS = {"investigaciones_prueba.json", "node_modules", "__pycache__", ".pytest_cache", ".venv", "venv", ".git", ".mypy_cache"}
MARCA_PLACEHOLDER = "placeholder vacío"

logger = logging.getLogger("empaquetar_todo")


def construir(destino: Path = DESTINO) -> list[str]:
    """Genera el zip con todo el proyecto bajo `ignis/` y devuelve el manifiesto."""
    archivos = sorted(p for p in RAIZ.rglob("*")
                      if p.is_file() and p.suffix != ".zip" and not (set(p.relative_to(RAIZ).parts) & EXCLUIDOS))
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
        for p in archivos:
            z.write(p, Path("ignis") / p.relative_to(RAIZ))
    return [p.relative_to(RAIZ).as_posix() for p in archivos]


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    destino = RAIZ.parent / sys.argv[1] if len(sys.argv) > 1 else DESTINO  # p. ej.: python scripts/empaquetar_todo.py ignis_FINAL.zip
    manifiesto = construir(destino)
    print("\n".join(manifiesto))
    print(f"\n{len(manifiesto)} archivos -> {destino} ({destino.stat().st_size / 1e6:.1f} MB)")
