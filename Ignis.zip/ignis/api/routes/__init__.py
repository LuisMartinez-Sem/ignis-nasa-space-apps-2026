"""Rutas HTTP de IGNIS."""
