"""API de IGNIS (FastAPI)."""
