"""Pruebas de /api/v1/hardware/ping (pulso del puente Arduino)."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

import hardware_bridge as hb
from api.main import app
from api.routes import hardware


@pytest.fixture()
def cliente(monkeypatch: pytest.MonkeyPatch):
    reloj = {"t": 1000.0}
    monkeypatch.setattr(hardware, "_reloj", lambda: reloj["t"])
    hardware.reiniciar_estado()
    with TestClient(app) as c:
        c.reloj = reloj  # type: ignore[attr-defined]
        yield c
    hardware.reiniciar_estado()


def test_sin_pulsos_esta_desconectado(cliente: TestClient) -> None:
    assert cliente.get("/api/v1/hardware/ping").json() == {"conectado": False, "dispositivo": "Arduino R3", "ultimo_dato_s": None}


def test_pulso_conecta_y_caduca_a_los_5_segundos(cliente: TestClient) -> None:
    assert cliente.post("/api/v1/hardware/ping").json()["conectado"] is True
    cliente.reloj["t"] += 0.4
    assert cliente.get("/api/v1/hardware/ping").json() == {"conectado": True, "dispositivo": "Arduino R3", "ultimo_dato_s": 0.4}
    cliente.reloj["t"] += 4.6  # 5.0 s exactos: aún conectado
    assert cliente.get("/api/v1/hardware/ping").json()["conectado"] is True
    cliente.reloj["t"] += 0.2  # 5.2 s: caducado
    d = cliente.get("/api/v1/hardware/ping").json()
    assert d["conectado"] is False and d["ultimo_dato_s"] == 5.2
    cliente.post("/api/v1/hardware/ping")  # un pulso nuevo reconecta
    assert cliente.get("/api/v1/hardware/ping").json()["conectado"] is True


def test_nombre_de_dispositivo_validado(cliente: TestClient) -> None:
    assert cliente.post("/api/v1/hardware/ping", json={"dispositivo": "Arduino UNO R3"}).json()["dispositivo"] == "Arduino UNO R3"
    assert cliente.post("/api/v1/hardware/ping", json={"dispositivo": "<script>"}).status_code == 422
    assert cliente.post("/api/v1/hardware/ping", json={"otro": 1}).status_code == 422
    assert cliente.post("/api/v1/hardware/ping", json={"dispositivo": "x" * 41}).status_code == 422


def test_el_puente_envia_el_pulso_tras_cada_lectura_valida() -> None:
    pulsos: list[int] = []
    n = hb.procesar([b"basura", b"24.0\n", b"25.0\n"], url="http://x", unidad="c", campo="ambiente", intervalo_s=0.0,
                    ajustes={"o2": 0.21, "presion_kpa": 101.3, "flujo_cm_s": 10.0, "temp_ambiente_k": 295.0, "espesor_mm": 0.2, "material": "sibal", "regimen": "opuesto"},
                    enviador=lambda u, c: {"indice_riesgo": 1}, salida=lambda s: None, pulsador=lambda lectura=None: pulsos.append(lectura))
    assert n == 2 and len(pulsos) == 2
    assert hb.url_pulso("http://192.168.1.5:8000/api/v1/predict") == "http://192.168.1.5:8000/api/v1/hardware/ping"


def test_el_pulso_guarda_la_ultima_lectura_y_el_historial(cliente: TestClient) -> None:
    cliente.post("/api/v1/hardware/ping", json={"temperatura_k": 297.1, "campo": "ambiente", "indice_riesgo": 65.2, "nivel_riesgo": "ALERTA"})
    cliente.reloj["t"] += 1.0
    cliente.post("/api/v1/hardware/ping", json={"temperatura_k": 297.4, "campo": "ambiente", "indice_riesgo": 65.3, "nivel_riesgo": "ALERTA"})
    d = cliente.get("/api/v1/hardware/lectura").json()
    assert d["lectura"] == {"temperatura_k": 297.4, "campo": "ambiente", "indice_riesgo": 65.3, "nivel_riesgo": "ALERTA"}
    assert [x["temperatura_k"] for x in d["historial"]] == [297.1, 297.4] and d["historial"][0]["hace_s"] == 1.0
    assert cliente.post("/api/v1/hardware/ping", json={"temperatura_k": 5000}).status_code == 422  # fuera de rango físico
