"""Modo gas (experimental): no debe alterar el modelo de sólidos (regresión Saffire-I) y debe ser honesto sobre sus límites."""
from __future__ import annotations

import hashlib
from pathlib import Path

import pytest

from src.dataset_sintetico import anclas_de_velocidad
from src.model import ErrorModelo, ModeloPropagacion
from src.modo_gas import CondicionesGas, ModeloGas, cargar_tablas_gas
from src.predictor import PredictorIgnis

RAIZ = Path(__file__).resolve().parent.parent
MODELO_SOLIDOS = RAIZ / "data/processed/modelo_propagacion.joblib"
# Huella del modelo de sólidos del modelo entregado: si cambia, este test avisa (el modo gas no debe tocarlo).
SHA256_SOLIDOS = "eb7f90cea7aec2d3af268b081895b532200f9c554a5497f778d46a96efbd6d6e"


def _error_saffire_i(predictor: PredictorIgnis) -> float:
    errores = []
    for ancla in anclas_de_velocidad():
        from src.domain import CondicionesAmbiente
        r = predictor.evaluar(CondicionesAmbiente(**ancla["condiciones"]))
        errores.append(abs(r.velocidad_propagacion_mm_s - ancla["valor"]) / ancla["valor"])
    return sum(errores) / len(errores)


def test_regresion_solidos_saffire_sigue_bajo_5_pct() -> None:
    predictor = PredictorIgnis(ModeloPropagacion.cargar(MODELO_SOLIDOS))
    assert _error_saffire_i(predictor) < 0.05


def test_modelo_de_solidos_no_cambio() -> None:
    assert hashlib.sha256(MODELO_SOLIDOS.read_bytes()).hexdigest() == SHA256_SOLIDOS


def test_modo_por_defecto_es_solido_y_gas_exige_modelo() -> None:
    predictor = PredictorIgnis(ModeloPropagacion.cargar(MODELO_SOLIDOS))
    from src.domain import CondicionesAmbiente
    ancla = anclas_de_velocidad()[0]
    c = CondicionesAmbiente(**ancla["condiciones"])
    assert predictor.evaluar(c).velocidad_propagacion_mm_s == predictor.evaluar(c, modo="solido").velocidad_propagacion_mm_s
    gas = CondicionesGas(101.3, 0.21, 1.0, 1.0, "propane")
    with pytest.raises(ErrorModelo):
        predictor.evaluar(gas, modo="gas")
    with pytest.raises(ErrorModelo):
        predictor.evaluar(c, modo="plasma")


@pytest.fixture(scope="module")
def datos_gas():
    return cargar_tablas_gas(RAIZ / "data/raw/gases")


def test_tablas_gas_limpias_y_etiquetadas(datos_gas) -> None:
    assert set(datos_gas["tipo_combustible"]) == {"gas"}
    assert len(datos_gas) > 250 and set(datos_gas["ignicion"]) == {0, 1}
    assert not datos_gas[["presion_kpa", "fraccion_o2"]].isna().any().any()


def test_modelo_gas_supera_al_trivial_y_avisa(datos_gas) -> None:
    m = ModeloGas(n_arboles=100)
    met = m.validar(datos_gas)
    assert met["brier_modelo"] < met["brier_trivial"]  # mejor que decir siempre «sí enciende»
    m.entrenar(datos_gas)
    predictor = PredictorIgnis(ModeloPropagacion.cargar(MODELO_SOLIDOS))
    predictor.registrar_modelo_gas(m)
    r = predictor.evaluar(CondicionesGas(101.3, 0.21, 1.0, 1.0, "propane"), modo="gas")
    assert 0.0 <= r.probabilidad_ignicion_caliente <= 1.0 and r.experimental and not r.fuera_de_dominio
    fuera = predictor.evaluar(CondicionesGas(20.0, 0.21, 1.0, 1.0, "propane"), modo="gas")
    assert fuera.fuera_de_dominio and any("extrapolación" in a for a in fuera.advertencias)
