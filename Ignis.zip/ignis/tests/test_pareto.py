"""Pruebas del Análisis de Frontera de Pareto para priorización de experimentos."""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from api.main import app
from src import investigaciones as inv
from src.pareto import _domina, capas_no_dominadas, hipervolumen


@pytest.fixture(scope="module")
def cliente() -> TestClient:
    with TestClient(app) as c:
        yield c


# ----------------------------------------------------------------------------------------------- matemática pura
def test_dominancia_riesgo_alto_y_evidencia_baja_domina() -> None:
    assert _domina((10, 80), (30, 60))  # (evidencia, riesgo): más riesgo y menos evidencia
    assert not _domina((30, 60), (10, 80))
    assert not _domina((10, 80), (10, 80))  # iguales: ninguno domina


def test_capas_no_dominadas_con_empates_y_orden() -> None:
    pares = [(10, 80), (10, 80), (30, 90), (50, 40), (60, 30)]
    capas = capas_no_dominadas(pares)
    assert capas[0] == capas[1] == 1  # empates exactos comparten capa
    assert capas[2] == 1  # más riesgo aunque con más evidencia: no dominado
    assert capas[3] > 1 and capas[4] >= capas[3]


def test_hipervolumen_valores_conocidos() -> None:
    assert hipervolumen([]) == 0.0
    assert hipervolumen([(0, 100)]) == 1.0  # domina todo el plano
    assert hipervolumen([(50, 100)]) == 0.5
    assert hipervolumen([(0, 50), (50, 100)]) == pytest.approx(0.25 + 0.5)  # escalera: 50·50 + 50·100 = 7500 → 0.75


# ----------------------------------------------------------------------------------------------- endpoint
def test_pareto_estructura_json_para_scatter(cliente: TestClient) -> None:
    r = cliente.get("/api/v1/investigaciones/pareto")
    assert r.status_code == 200
    d = r.json()
    assert d["titulo"] == "Análisis de Frontera de Pareto para priorización de experimentos"
    assert set(d["ejes"]) == {"x", "y"} and d["ejes"]["x"]["id"] == "evidencia" and d["ejes"]["y"]["id"] == "riesgo"
    assert len(d["puntos"]) == 19
    for p in d["puntos"]:
        assert 0 <= p["x"] <= 100 and 0 <= p["y"] <= 100
        assert p["y_bajo"] <= p["y"] <= p["y_alto"]
        assert p["en_frontera"] == (p["capa"] == 1)
        assert sum(c["aporte"] for c in p["evidencia_detalle"]) == pytest.approx(p["x"], abs=0.11)
    ids = {p["id"] for p in d["puntos"]}
    assert d["frontera"] and set(d["frontera"]) <= ids and d["codo"] in d["frontera"]
    assert 0 <= d["hipervolumen"] <= 1
    xs = [q["x"] for q in d["linea_frontera"]]
    assert xs == sorted(xs), "la escalera debe ser monótona en evidencia"


def test_la_frontera_no_esta_dominada_por_nadie(cliente: TestClient) -> None:
    d = cliente.get("/api/v1/investigaciones/pareto").json()
    todos = [(p["x"], p["y"]) for p in d["puntos"]]
    for p in d["puntos"]:
        dominado = any(_domina(o, (p["x"], p["y"])) for o in todos)
        assert dominado != p["en_frontera"]


def test_saffire_i_es_el_mas_documentado_y_no_inventa_campos(cliente: TestClient) -> None:
    d = {p["id"]: p for p in cliente.get("/api/v1/investigaciones/pareto").json()["puntos"]}
    assert d["saffire-i"]["x"] == 100 and d["saffire-i"]["inferidos"] == []
    assert d["bass"]["x"] < d["saffire-i"]["x"] and "o2_pct" in d["bass"]["inferidos"]
    assert d["bass"]["y_bajo"] < d["bass"]["y"] < d["bass"]["y_alto"]  # el desconocimiento se traduce en intervalo
    assert d["spice"]["extrapolacion_combustible"] is True and d["saffire-i"]["extrapolacion_combustible"] is False


def test_pareto_no_choca_con_la_ruta_por_id_y_valida_entorno(cliente: TestClient) -> None:
    assert cliente.get("/api/v1/investigaciones/saffire-i").json()["investigacion"]["id"] == "saffire-i"
    assert cliente.get("/api/v1/investigaciones/pareto?entorno=traje").status_code == 422  # fuera del dominio del modelo
    assert cliente.get("/api/v1/investigaciones/pareto?entorno=marte").status_code == 200


def test_pareto_sigue_vivo_si_se_borra_el_catalogo(cliente: TestClient, tmp_path: Path) -> None:
    ruta = inv.RUTA_CATALOGO
    copia = tmp_path / "inv.json"
    shutil.copy(ruta, copia)
    try:
        ruta.unlink()
        inv.limpiar_cache()
        r = cliente.get("/api/v1/investigaciones/pareto")
        assert r.status_code == 200 and len(r.json()["puntos"]) == 19 and r.json()["estado"]["origen"] == "respaldo"
    finally:
        shutil.copy(copia, ruta)
        inv.limpiar_cache()


def test_incertidumbre_p10_p90_p_frontera_y_dominados(cliente: TestClient) -> None:
    d = {p["id"]: p for p in cliente.get("/api/v1/investigaciones/pareto").json()["puntos"]}
    bass, saf = d["bass"], d["saffire-i"]
    assert bass["y_bajo"] <= bass["riesgo_medio"] <= bass["y_alto"] + 20 and bass["incertidumbre"] == pytest.approx(bass["y_alto"] - bass["y_bajo"], abs=0.11)
    assert saf["incertidumbre"] == 0 and saf["p_frontera"] in (0.0, 1.0)  # todo conocido: sin incertidumbre, resultado exacto
    assert all(0 <= p["p_frontera"] <= 1 for p in d.values())
    assert d["fm2"]["p_frontera"] >= d["bass"]["p_frontera"]  # menos evidencia, al menos tan probable de ser crítica
    assert d["fm2"]["dominados"] >= d["bass"]["dominados"] >= d["saffire-i"]["dominados"]


def test_p_frontera_es_determinista_y_valida_casos_simples() -> None:
    import numpy as np

    from src.pareto import _p_frontera

    # A (x=10,y=80) siempre domina a B (x=50,y=40): B nunca está en la frontera; A siempre
    a = _p_frontera([10, 50], [np.array([80.0]), np.array([40.0])], [80, 40], remuestrear=True)
    assert list(a) == [1.0, 0.0]
    # incertidumbre: B puede valer 60 o 100; con 100 supera a A (más y, aunque con más evidencia): P(B en frontera)=1 (no dominada por A si y_B>y_A)
    b = _p_frontera([10, 50], [np.array([80.0]), np.array([60.0, 100.0])], [80, 80], remuestrear=True)
    assert b[0] == 1.0 and 0.3 < b[1] < 0.7
    assert list(_p_frontera([10, 50], [np.array([80.0]), np.array([60.0, 100.0])], [80, 80], remuestrear=True)) == list(b)  # semilla fija
