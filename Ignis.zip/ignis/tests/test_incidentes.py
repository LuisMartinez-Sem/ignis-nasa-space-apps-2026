"""Catálogo, simulador y endpoints de incidentes históricos."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from src.incidentes_historicos import CatalogoIncidentes, ErrorIncidente, Incidente, DIRECTORIO_INCIDENTES

IDS = {"mir-1997", "apollo1-1967", "iss-2015-falsa-alarma", "saffire-2016-2024"}


def test_catalogo_carga_los_cuatro_incidentes() -> None:
    assert {i.id for i in CatalogoIncidentes().listar()} == IDS


def test_id_invalido_se_rechaza_sin_tocar_disco() -> None:
    with pytest.raises(ErrorIncidente):
        CatalogoIncidentes().obtener("../../etc/passwd")
    with pytest.raises(ErrorIncidente):
        CatalogoIncidentes().obtener("no-existe-123")


def test_json_roto_no_tumba_el_catalogo(tmp_path: Path) -> None:
    (tmp_path / "roto.json").write_text("{no es json", encoding="utf-8")
    valido = (DIRECTORIO_INCIDENTES / "apollo1-1967.json").read_text(encoding="utf-8")
    (tmp_path / "ok.json").write_text(valido, encoding="utf-8")
    assert [i.id for i in CatalogoIncidentes(tmp_path).listar()] == ["apollo1-1967"]


def test_referencia_a_fuente_inexistente_es_invalida() -> None:
    datos = json.loads((DIRECTORIO_INCIDENTES / "apollo1-1967.json").read_text(encoding="utf-8"))
    datos["timeline_humano"][0]["fuente"] = 99
    with pytest.raises(ValidationError, match="fuentes inexistentes"):
        Incidente.model_validate(datos)


def test_tipo_sin_datos_requeridos_es_invalido() -> None:
    datos = json.loads((DIRECTORIO_INCIDENTES / "mir-1997.json").read_text(encoding="utf-8"))
    datos["telemetria_ilustrativa"] = []
    with pytest.raises(ValidationError, match="faltan datos"):
        Incidente.model_validate(datos)


def test_ningun_incidente_afirma_cifras_no_defendibles() -> None:
    """Salvaguarda de honestidad: la cifra de 14 min solo puede aparecer como no verificada."""
    mir = CatalogoIncidentes().obtener("mir-1997")
    for evento in mir.timeline_humano:
        if evento.t_s == 840:
            assert evento.confianza == "no_verificado"
    assert all(e.confianza != "documentado" or e.fuente is not None for e in mir.timeline_humano)


def test_endpoint_lista(cliente) -> None:
    respuesta = cliente.get("/api/v1/incidentes")
    assert respuesta.status_code == 200
    assert {i["id"] for i in respuesta.json()} == IDS


@pytest.mark.parametrize("identificador", sorted(IDS))
def test_simular_cada_incidente(cliente, identificador: str) -> None:
    respuesta = cliente.get(f"/api/v1/incidentes/{identificador}/simular")
    assert respuesta.status_code == 200, respuesta.text
    cuerpo = respuesta.json()
    # Saffire (validación) no tiene cronología humana: son experimentos controlados
    if cuerpo["tipo"] != "validacion":
        assert cuerpo["timeline_humano"]
    assert cuerpo["timeline_ignis"]
    assert cuerpo["fuentes"] and cuerpo["supuestos"]
    assert cuerpo["impacto"]["metodologia"]


def test_mir_reaccion_es_contrafactual_y_menor_que_la_ventana(cliente) -> None:
    impacto = cliente.get("/api/v1/incidentes/mir-1997/simular").json()["impacto"]
    metricas = impacto["metricas"]
    assert impacto["es_contrafactual"] is True
    assert 0 <= metricas["reaccion_ignis_s"] < metricas["ventana_min_s"]
    assert "veces más rápido" not in impacto["resumen"]


def test_apollo_no_se_evalua_con_el_modelo(cliente) -> None:
    """Atmósfera fuera de dominio: no hay índice inventado, sí la lista de variables fuera."""
    cuerpo = cliente.get("/api/v1/incidentes/apollo1-1967/simular").json()
    metricas = cuerpo["impacto"]["metricas"]
    assert cuerpo["modelo_aplicable"] is False
    assert metricas["indice_riesgo"] is None and metricas["fuera_de_dominio"] is True
    assert "fraccion_o2" in metricas["variables_fuera_de_dominio"]


def test_iss_no_escala_ante_pico_aislado(cliente) -> None:
    metricas = cliente.get("/api/v1/incidentes/iss-2015-falsa-alarma/simular").json()["impacto"]["metricas"]
    assert metricas["alarma_en_traza_del_incidente"] is False
    assert metricas["falsas_alarmas_ignis_pct"] < metricas["falsas_alarmas_umbral_simple_pct"]


def test_saffire_reporta_brecha_sin_fingir_validacion(cliente) -> None:
    cuerpo = cliente.get("/api/v1/incidentes/saffire-2016-2024/simular").json()
    assert cuerpo["impacto"]["es_contrafactual"] is False
    assert cuerpo["impacto"]["metricas"]["n_con_medicion"] == 2
    assert "sintétic" in cuerpo["impacto"]["metodologia"].lower()


@pytest.mark.parametrize("ruta", ["no-existe", "../x", "A" * 80])
def test_incidente_inexistente_o_malformado(cliente, ruta: str) -> None:
    assert cliente.get(f"/api/v1/incidentes/{ruta}/simular").status_code in (404, 422)


def test_apollo_e_iss_no_producen_nulos_para_el_hud(cliente) -> None:
    """Regresión: Apollo 1 mostraba 'null/undefined' (sin índice_con_aire); ISS debe traer sus métricas completas."""
    import time
    for _ in range(40):
        a = cliente.get("/api/v1/incidentes/apollo1-1967/simular")
        if a.status_code != 503:
            break
        time.sleep(1)
    assert a.status_code == 200
    a = a.json()
    assert a["fuera_de_dominio"] is True and a["impacto"]["metricas"]["indice_riesgo"] is None
    assert isinstance(a["impacto"]["metricas"]["indice_con_aire"], float)
    i = cliente.get("/api/v1/incidentes/iss-2015-falsa-alarma/simular")
    if i.status_code == 200:
        m = i.json()["impacto"]["metricas"]
        assert i.json()["fuera_de_dominio"] is False and m["falsas_alarmas_ignis_pct"] is not None and m["falsas_alarmas_umbral_simple_pct"] is not None
