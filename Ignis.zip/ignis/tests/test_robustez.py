"""Robustez del SI Dashboard: respaldo, ingesta del 13 de noviembre, preset→Monitor y mapa de riesgo."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from scripts import ingestar_datos_nasa as ing
from src import investigaciones as inv
from src.investigaciones_respaldo import ANCLAS_RESPALDO, CATALOGO_RESPALDO

RAIZ = Path(__file__).resolve().parent.parent


@pytest.fixture
def catalogo_roto(monkeypatch, tmp_path):
    """Apunta el catálogo a una ruta que no existe y limpia el caché (y lo restaura al terminar)."""
    def _apuntar(contenido: str | None):
        ruta = tmp_path / "investigaciones.json"
        if contenido is not None:
            ruta.write_text(contenido, encoding="utf-8")
        monkeypatch.setattr(inv, "RUTA_CATALOGO", ruta)
        inv.limpiar_cache()
        return ruta
    yield _apuntar
    inv.limpiar_cache()


def test_respaldo_sin_deriva_respecto_a_los_json() -> None:
    """Si editas data/*.json, corre scripts/regenerar_respaldo.py: el respaldo debe ser idéntico."""
    assert CATALOGO_RESPALDO == json.loads((RAIZ / "data" / "investigaciones.json").read_text(encoding="utf-8"))["investigaciones"]
    assert len(CATALOGO_RESPALDO) == 19 and len(ANCLAS_RESPALDO) == 6


@pytest.mark.parametrize("contenido", [None, "{roto", "[]", '{"investigaciones": []}', '{"investigaciones": [{"id": "x"}]}', ""])
def test_la_api_no_se_cae_si_el_archivo_falta_o_esta_corrupto(cliente, catalogo_roto, contenido) -> None:
    catalogo_roto(contenido)
    for ruta in ("/api/v1/investigaciones", "/api/v1/investigaciones/ranking?entorno=luna", "/api/v1/investigaciones/gaps",
                 "/api/v1/investigaciones/export?formato=csv", "/api/v1/investigaciones/export?formato=json",
                 "/api/v1/investigaciones/comparar?ids=bass,saffire-i", "/api/v1/investigaciones/saffire-i"):
        r = cliente.get(ruta)
        assert r.status_code == 200, (ruta, r.status_code, r.text[:120])
    c = cliente.get("/api/v1/investigaciones").json()
    assert c["total"] == 19 and c["estado"]["origen"] == "respaldo" and "RESPALDO" in c["estado"]["detalle"]
    assert cliente.get("/api/v1/investigaciones/ranking?entorno=iss").json()["estado"]["origen"] == "respaldo"


def test_se_recupera_solo_cuando_el_archivo_vuelve(cliente, catalogo_roto) -> None:
    ruta = catalogo_roto(None)
    assert cliente.get("/api/v1/investigaciones").json()["estado"]["origen"] == "respaldo"
    ruta.write_text((RAIZ / "data" / "investigaciones.json").read_text(encoding="utf-8"), encoding="utf-8")
    assert cliente.get("/api/v1/investigaciones").json()["estado"]["origen"] == "archivo"  # sin reiniciar


def test_anclas_exportables_aun_sin_el_archivo_de_anclas(cliente, monkeypatch, tmp_path) -> None:
    monkeypatch.setattr(inv, "RUTA_ANCLAS", tmp_path / "no-existe.json")
    r = cliente.get("/api/v1/investigaciones/export?formato=json&conjunto=anclas")
    assert r.status_code == 200 and len(r.json()) == 6


def test_ingesta_corrupta_se_ignora_y_se_sirve_el_catalogo_base(cliente, catalogo_roto, tmp_path) -> None:
    ruta = catalogo_roto((RAIZ / "data" / "investigaciones.json").read_text(encoding="utf-8"))
    (ruta.with_name("investigaciones_ingestadas.json")).write_text("{basura")
    inv.limpiar_cache()
    c = cliente.get("/api/v1/investigaciones").json()
    assert c["total"] == 19 and c["estado"]["origen"] == "archivo" and c["estado"]["ingesta_aplicada"] == []


# ------------------------------------------------------------------------------------------- ingesta
CSV_NUEVO = ("Investigation,O2 (%),Flow (cm/s),Pressure (psi),Hardware,Objective\n"
             "BASS,21,10,14.7,MSG,Objetivo de prueba\nBASS,30,20,10.2,MSG,x\nSaffire-I,25,20,14.7,H,y\nNoExiste,1,1,1,a,b\n")


def test_ingesta_mapea_agrega_y_convierte_unidades(tmp_path) -> None:
    raw = tmp_path / "raw"
    raw.mkdir()
    (raw / "nuevo.csv").write_text(CSV_NUEVO, encoding="utf-8")
    salida, reporte = tmp_path / "o.json", tmp_path / "r.json"
    informe = ing.ingestar(raw, salida, reporte, tmp_path / "m.json")
    assert informe["archivos"][0]["estado"] == "ok" and informe["archivos"][0]["investigaciones_nuevas"] == ["noexiste"]
    bass = json.loads(salida.read_text())["actualizaciones"]["bass"]
    assert bass["o2_pct"] == {"min": 21.0, "max": 30.0} and bass["flujo_cm_s"] == {"min": 10.0, "max": 20.0}
    assert bass["presion_kpa"]["min"] == pytest.approx(70.3, abs=0.1) and bass["presion_kpa"]["max"] == pytest.approx(101.35, abs=0.1)  # psi → kPa
    assert any("saffire-i.o2_pct" in c for c in informe["archivos"][0]["conflictos"])  # contradice el ancla: se conserva el catálogo
    assert "o2_pct" not in json.loads(salida.read_text())["actualizaciones"].get("saffire-i", {})


def test_ingesta_formatos_malos_fallan_con_elegancia(tmp_path) -> None:
    raw = tmp_path / "raw"
    raw.mkdir()
    (raw / "sin_id.csv").write_text("foo,bar\n1,2\n")
    (raw / "roto.json").write_text("{roto")
    (raw / "vacio.csv").write_text("")
    (raw / "binario.csv").write_bytes(b"\xff\xfe\x00\x01")
    (raw / "lista.json").write_text('{"x": 5}')
    informe = ing.ingestar(raw, tmp_path / "o.json", tmp_path / "r.json", tmp_path / "m.json")
    assert [a["estado"] for a in informe["archivos"]] == ["fallido"] * 5
    assert not (tmp_path / "o.json").exists()  # nada que aplicar


def test_ingesta_unidad_ambigua_no_se_adivina(tmp_path) -> None:
    raw = tmp_path / "raw"
    raw.mkdir()
    (raw / "a.csv").write_text("Investigation,Flow,Pressure\nBASS,10,101\n")
    informe = ing.ingestar(raw, tmp_path / "o.json", tmp_path / "r.json", tmp_path / "m.json")
    assert informe["archivos"][0]["estado"] == "sin_coincidencias" and len(informe["archivos"][0]["omitidas"]) == 2


def test_ingesta_es_idempotente_y_la_api_aplica_los_datos(cliente, catalogo_roto, tmp_path) -> None:
    ruta = catalogo_roto((RAIZ / "data" / "investigaciones.json").read_text(encoding="utf-8"))
    raw = tmp_path / "raw"
    raw.mkdir()
    (raw / "nuevo.csv").write_text("Investigation,O2 (%)\nBASS,21\nBASS,30\n")
    ing.ingestar(raw, ruta.with_name("investigaciones_ingestadas.json"), tmp_path / "r.json", tmp_path / "m.json")
    segunda = ing.ingestar(raw, ruta.with_name("investigaciones_ingestadas.json"), tmp_path / "r.json", tmp_path / "m.json")
    assert segunda["archivos"][0]["estado"] == "sin_cambios"
    bass = cliente.get("/api/v1/investigaciones/bass").json()["investigacion"]
    assert bass["o2_pct"] == {"min": 21.0, "max": 30.0} and "o2_pct" not in bass["campos_no_verificados"]
    assert cliente.get("/api/v1/investigaciones").json()["estado"]["ingesta_aplicada"] == ["bass"]


def test_script_de_ingesta_sin_datos_no_rompe(tmp_path) -> None:
    r = subprocess.run([sys.executable, str(RAIZ / "scripts" / "ingestar_datos_nasa.py"), "--raw", str(tmp_path / "no-hay")], capture_output=True, text=True, cwd=RAIZ)
    assert r.returncode == 0 and "No hay CSV/JSON" in r.stdout


# ---------------------------------------------------------------------------------------- preset y mapa
def test_preset_lunar_entrega_valores_exactos_para_los_sliders(cliente) -> None:
    d = cliente.post("/api/v1/preset/lunar").json()
    assert d["monitor"]["modo"] == "manual"
    assert d["monitor"]["sliders"] == {"ctl-o2": 30.0, "ctl-flujo": 10.0, "ctl-presion": 70.0, "ctl-temp": 300.0, "ctl-termopar": False}
    assert d["monitor"]["condiciones"]["fraccion_o2"] == 0.3 and d["monitor"]["condiciones"]["presion_kpa"] == 70.0
    assert d["monitor"]["condiciones"]["material"] == "sibal"


def test_los_sliders_del_preset_existen_en_el_html_con_rangos_compatibles() -> None:
    html = (RAIZ / "frontend" / "index.html").read_text(encoding="utf-8")
    import re
    for id_, valor in (("ctl-o2", 30.0), ("ctl-flujo", 10.0), ("ctl-presion", 70.0), ("ctl-temp", 300.0)):
        m = re.search(rf'id="{id_}" type="range" min="([\d.]+)" max="([\d.]+)"', html)
        assert m, id_
        assert float(m.group(1)) <= valor <= float(m.group(2))
    assert 'id="ctl-termopar"' in html


def test_mapa_de_riesgo(cliente) -> None:
    r = cliente.get("/api/v1/mapa-riesgo")
    if r.status_code == 503:
        pytest.skip("modelo cargando")
    d = r.json()
    assert len(d["indice"]) == 25 and all(len(f) == 25 for f in d["indice"])
    ids = {m["id"]: m for m in d["marcadores"]}
    assert ids["luna"]["dentro_del_dominio"] and not ids["traje"]["dentro_del_dominio"] and "evidencia-0" in ids
    assert d["indice"][-1][-1] > d["indice"][0][0]  # más O₂ y presión → más potencial


def test_preset_lunar_explica_el_indice_con_el_delta_calculado() -> None:
    from fastapi.testclient import TestClient

    from api.main import app
    from api.routes.preset import explicar_preset

    assert explicar_preset(10.4) == "Riesgo si hubiera ignición. No hay evento en curso. Comparado con la ISS (+10.4 pts)."
    assert "(-3.2 pts)" in explicar_preset(-3.2) and "0.0 pts, igual" in explicar_preset(0.0)
    with TestClient(app) as c:
        d = c.post("/api/v1/preset/lunar", json={}).json()
    assert d["explicacion"].startswith("Riesgo si hubiera ignición. No hay evento en curso.")
    assert f"{abs(d['delta_indice_vs_iss']):.1f} pts" in d["explicacion"]


def test_toda_investigacion_tiene_una_fuente_especifica_y_honesta() -> None:
    import json

    from src.investigaciones import RUTA_CATALOGO

    for i in json.loads(RUTA_CATALOGO.read_text(encoding="utf-8"))["investigaciones"]:
        assert "texto oficial" in i["fuente"] and len(i["fuente"]) > 40
        if i["id"] == "saffire-i":
            assert "ancla" in i["fuente"] and "no verificada" in i["fuente"]


# ----------------------------------------------------------------------------------- investigaciones NUEVAS (nombres que el catálogo no tenía)
CSV_CON_NOMBRE_NUEVO = ("Experiment,O2 (%),Flow (cm/s),Pressure (kPa),Hardware\n"
                        "Zeta-Burn Test,26,12,80,Rack Z\nZeta-Burn Test,34,18,70,Rack Z\nSaffire-I,21.7,20,101.3,Saffire\n")


def test_nombre_nuevo_crea_una_ficha_honesta_y_se_clasifica(tmp_path, monkeypatch) -> None:
    from fastapi.testclient import TestClient

    from api.main import app
    from src import investigaciones as inv

    catalogo = tmp_path / "investigaciones.json"
    shutil.copy(inv.RUTA_CATALOGO, catalogo)
    raw = tmp_path / "raw"
    raw.mkdir()
    (raw / "z.csv").write_text(CSV_CON_NOMBRE_NUEVO, encoding="utf-8")
    informe = ing.ingestar(raw, tmp_path / "investigaciones_ingestadas.json", tmp_path / "r.json", tmp_path / "m.json")
    assert informe["archivos"][0]["investigaciones_nuevas"] == ["zeta-burn-test"] and informe["nuevas_totales"] == 1
    monkeypatch.setattr(inv, "RUTA_CATALOGO", catalogo)
    inv.limpiar_cache()
    try:
        lista, estado = inv.cargar_catalogo_con_estado()
        nueva = next(i for i in lista if i.id == "zeta-burn-test")
        assert len(lista) == 20 and estado.nuevas_ingestadas == ["zeta-burn-test"] and estado.huella
        assert nueva.o2_pct.min == 26.0 and nueva.o2_pct.max == 34.0 and nueva.familia == "otra" and nueva.gravedad == "desconocida"
        assert {"familia", "combustible_tipos", "gravedad", "datos_en_psi"} <= set(nueva.campos_no_verificados)  # lo no declarado queda como desconocido
        with TestClient(app) as c:
            d = c.get("/api/v1/investigaciones/pareto").json()
            p = next(x for x in d["puntos"] if x["id"] == "zeta-burn-test")
            assert len(d["puntos"]) == 20
            # O₂ (25) + presión (20) + flujo (10) declarados por el archivo; datos en PSI y gravedad desconocidos suman 0
            assert p["x"] == 55.0 and p["inferidos"] == []  # lo que el archivo trae NO se infiere
            assert c.get("/api/v1/investigaciones/ranking?entorno=luna").status_code == 200
        # idempotente: repetir la ingesta no duplica
        ing.ingestar(raw, tmp_path / "investigaciones_ingestadas.json", tmp_path / "r.json", tmp_path / "m.json", forzar=True)
        inv.limpiar_cache()
        assert len(inv.cargar_catalogo()) == 20
    finally:
        inv.limpiar_cache()


def test_la_huella_cambia_cuando_llega_informacion(tmp_path) -> None:
    from src import investigaciones as inv

    catalogo = tmp_path / "investigaciones.json"
    shutil.copy(inv.RUTA_CATALOGO, catalogo)
    inv.limpiar_cache()
    antes = inv.cargar_catalogo_con_estado(catalogo)[1].huella
    raw = tmp_path / "raw"
    raw.mkdir()
    (raw / "a.csv").write_text("Investigation,O2 (%)\nBASS,28\n", encoding="utf-8")
    ing.ingestar(raw, tmp_path / "investigaciones_ingestadas.json", tmp_path / "r.json", tmp_path / "m.json")
    assert inv.cargar_catalogo_con_estado(catalogo)[1].huella != antes
    inv.limpiar_cache()


def test_mapa_incluye_cobertura_dinamica_y_el_estado_cambia_con_la_ingesta(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from fastapi.testclient import TestClient

    from api.main import app

    with TestClient(app) as c:
        h0 = c.get("/api/v1/investigaciones/estado").json()["huella"]
        m0 = c.get("/api/v1/mapa-riesgo").json()
        assert h0 and m0["huella"] == h0
        assert [x["id"] for x in m0["cobertura"]] == ["saffire-i"] and m0["cobertura"][0]["puntual"] is True  # única con O₂ y presión conocidos
