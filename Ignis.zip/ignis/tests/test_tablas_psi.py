"""Lector tolerante de tablas PSI: filas vacías, duplicados, unidades mixtas, erratas y relleno de huecos sin pisar lo conocido."""
from __future__ import annotations

from pathlib import Path

import pytest

from src.investigaciones import Rango
from src.tablas_psi import extraer, fusionar_rango, leer_tolerante, numero_psi, unir_rangos


def _csv(tmp: Path, nombre: str, texto: str, codificacion: str = "utf-8") -> Path:
    ruta = tmp / nombre
    ruta.write_bytes(texto.encode(codificacion))
    return ruta


def test_numero_psi_del_nombre() -> None:
    assert numero_psi("PSI-159_Experimental_table_CFI-G.csv") == 159 and numero_psi("otra.csv") is None


def test_filas_vacias_duplicadas_y_notas_no_rompen(tmp_path: Path) -> None:
    ruta = _csv(tmp_path, "PSI-39_x.csv", "Flex Number,Pressure,Oxygen,Fuel\n1,1 atm ,0.21,C12H26\n1,1 atm ,0.21,C12H26\n,,,\n,,,\n2,2 atm,0.17,C12H26\nNote 1 algo,,,\n")
    r = extraer(ruta)
    cal = r["calidad"]
    assert cal["filas_utiles"] == 2 and cal["filas_vacias"] == 2 and cal["filas_duplicadas"] == 1 and cal["filas_nota"] == 1
    assert r["presion"] == pytest.approx([101.325, 202.65]) and r["o2"] == pytest.approx([21.0, 17.0])  # fracción → %, atm → kPa
    assert any("duplicadas" in a["texto"] for a in cal["avisos"])


def test_texto_numerico_y_valores_imposibles(tmp_path: Path) -> None:
    ruta = _csv(tmp_path, "PSI-69_x.csv", "FLEX Test #,FLEX Identifier,Fuel,Ambient pressure; mmHg,O initial ambient composition; mole fraction\n1,A1,Methanol,757.7,0.21\n2,A2,Heptane,0,0.3\n3,A1,Methanol,540,0.34\n")
    r = extraer(ruta)
    assert r["presion"] == pytest.approx([757.7 * 0.133322368, 540 * 0.133322368])  # la presión 0 se descarta, no se promedia
    assert any("presión 0" in a["texto"] for a in r["calidad"]["avisos"]) and any("A1" in a["texto"] for a in r["calidad"]["avisos"])


def test_codificacion_no_utf8_se_lee(tmp_path: Path) -> None:
    ruta = _csv(tmp_path, "PSI-69_y.csv", "FLEX Test #,FLEX Identifier,Fuel,Ambient pressure; mmHg,O initial ambient composition; mole fraction\n1,A1,Metanol–x,760,0.21\n", "cp1252")
    r = extraer(ruta)
    assert r["calidad"]["codificacion"] == "cp1252" and r["o2"] == [21.0]


def test_tabla_desconocida_se_rechaza_sin_adivinar(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="sin adaptador"):
        extraer(_csv(tmp_path, "PSI-9999_x.csv", "a,b\n1,2\n"))


def test_fusion_rellena_huecos_sin_pisar() -> None:
    assert fusionar_rango(Rango(min=None, max=None), {"min": 1, "max": 2}) == ({"min": 1, "max": 2}, None)
    assert fusionar_rango(Rango(min=None, max=85.0), {"min": 18, "max": 40}) == ({"min": 18, "max": 85.0}, None)  # subconjunto: sin conflicto
    nuevo, aviso = fusionar_rango(Rango(min=21.7, max=21.7), {"min": 21.5, "max": 21.7})
    assert nuevo is None and aviso and "se conserva" in aviso  # el archivo se sale del valor verificado: conflicto, no se pisa
    assert unir_rangos({"min": 12, "max": 85}, {"min": 18, "max": 40}) == {"min": 12, "max": 85}


def test_lector_tolerante_exige_filas(tmp_path: Path) -> None:
    with pytest.raises(ValueError):
        leer_tolerante(_csv(tmp_path, "PSI-39_vacio.csv", ""))


def test_endpoint_calidad_datos(cliente) -> None:
    r = cliente.get("/api/v1/investigaciones/calidad-datos")
    assert r.status_code == 200 and {"archivos", "resumen"} <= set(r.json())
