"""Generador de señales, detector temporal causal y benchmark."""

from __future__ import annotations

import numpy as np
import pytest

pytest.importorskip("torch")

from src.detector_temporal import DetectorTemporal, entrenar_detector, primera_alarma
from src.senales import CANALES, TIPOS_EVENTO, generar_secuencias
from src.trazas import ErrorTraza, racha_minima, traza_representativa
from src.benchmark_deteccion import evaluar_benchmark
from src.config import obtener_configuracion


@pytest.fixture(scope="module")
def detector() -> DetectorTemporal:
    return DetectorTemporal.cargar(obtener_configuracion().ruta_detector)


def test_senales_son_deterministas_y_del_tamano_correcto() -> None:
    a, _, meta = generar_secuencias(30, semilla=1)
    b, _, _ = generar_secuencias(30, semilla=1)
    assert np.array_equal(a, b) and a.shape[2] == len(CANALES) and len(meta) == 30


def test_traza_representativa_cubre_todos_los_tipos() -> None:
    for tipo in TIPOS_EVENTO:
        assert traza_representativa(tipo).senales.shape[1] == len(CANALES)
    with pytest.raises(ErrorTraza):
        traza_representativa("inventado")


def test_racha_minima_coincide_con_primera_alarma() -> None:
    votos = np.random.default_rng(0).random((50, 120)) > 0.6
    assert np.array_equal(racha_minima(votos, 3), primera_alarma(votos, 3))


def test_causalidad_el_futuro_no_cambia_el_pasado(detector) -> None:
    señales, _, _ = generar_secuencias(4, semilla=9)
    original = detector.probabilidades(señales)
    alterado = señales.copy()
    alterado[:, 200:, :] += 50.0  # manipular solo el futuro
    assert np.allclose(original[:, :200], detector.probabilidades(alterado)[:, :200], atol=1e-5)


def test_streaming_dispara_con_llama_caliente_y_no_con_nominal(detector) -> None:
    def alarma_en(tipo: str) -> bool:
        flujo = detector.streaming()
        return any(flujo.paso(m).alarma_nueva for m in traza_representativa(tipo).senales)

    assert alarma_en("caliente") and not alarma_en("nominal") and not alarma_en("artefacto")


def test_muestra_con_forma_invalida_falla(detector) -> None:
    with pytest.raises(ValueError):
        detector.streaming().paso(np.zeros(3))


def test_entrenar_detector_minimo_produce_modelo_usable() -> None:
    mini = entrenar_detector(120, 1, 0)
    assert mini.entrenado


def test_benchmark_ignis_sin_falsas_alarmas_y_mas_sensible_que_camara(detector) -> None:
    informe = evaluar_benchmark(detector, n_secuencias=240)
    metodos = {m.nombre: m for m in informe.metodos}
    ignis = metodos["IGNIS · TCN multicanal"]
    assert ignis.falsas_alarmas_por_hora <= metodos["Umbral térmico fijo (30 K)"].falsas_alarmas_por_hora
    assert ignis.tasa_deteccion_global > metodos["Cámara visible"].tasa_deteccion_global
    assert informe.latencia_inferencia_ms_p95 < 50
