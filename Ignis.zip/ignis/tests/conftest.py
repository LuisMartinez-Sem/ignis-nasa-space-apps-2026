"""Fixtures compartidas: modelo pequeño entrenado una sola vez por sesión."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from src.config import obtener_configuracion
from src.data_loader import cargar_dataset
from src.model import ModeloPropagacion
from src.predictor import PredictorIgnis


@pytest.fixture(scope="session")
def modelo_pequeno() -> ModeloPropagacion:
    """Modelo reducido (rápido) sobre datos sintéticos."""
    datos, origen = cargar_dataset(None, n_muestras_sinteticas=2000, semilla=7)
    modelo = ModeloPropagacion(n_arboles=40, semilla=7)
    modelo.entrenar(datos, origen)
    return modelo


@pytest.fixture(scope="session")
def predictor_pequeno(modelo_pequeno: ModeloPropagacion) -> PredictorIgnis:
    """Predictor sobre el modelo reducido."""
    return PredictorIgnis(modelo_pequeno)


@pytest.fixture(scope="session")
def cliente(tmp_path_factory: pytest.TempPathFactory):
    """TestClient con lifespan real, modelo en directorio temporal y config mínima."""
    parche = pytest.MonkeyPatch()
    ruta_modelo = tmp_path_factory.mktemp("modelo") / "modelo.joblib"
    parche.setenv("IGNIS_ENTORNO", "pruebas")
    parche.setenv("IGNIS_NIVEL_LOG", "WARNING")
    parche.setenv("IGNIS_RUTA_MODELO", str(ruta_modelo))
    parche.setenv("IGNIS_N_MUESTRAS_SINTETICAS", "1500")
    parche.setenv("IGNIS_N_ARBOLES", "30")
    # DL y detector: se cargan los pesos preentrenados del repo (rápido), sin reentrenar nunca
    parche.setenv("IGNIS_ENTRENAR_PROFUNDO_AL_INICIAR", "false")
    parche.setenv("IGNIS_ESPERAR_MODELOS_OPCIONALES", "true")
    obtener_configuracion.cache_clear()

    from api.main import crear_app  # import tardío: ya con el entorno de pruebas

    with TestClient(crear_app()) as cliente_http:
        yield cliente_http
    parche.undo()
    obtener_configuracion.cache_clear()


CONDICIONES_VALIDAS = {
    "fraccion_o2": 0.21,
    "velocidad_flujo_cm_s": 10.0,
    "presion_kpa": 101.3,
    "temperatura_ambiente_k": 295.0,
    "espesor_combustible_mm": 0.2,
    "material": "sibal",
}


@pytest.fixture
def condiciones_validas() -> dict:
    """Copia mutable de condiciones válidas (aire, flujo pico, SIBAL)."""
    return dict(CONDICIONES_VALIDAS)


@pytest.fixture(autouse=True, scope="session")
def _catalogo_base_aislado(tmp_path_factory: pytest.TempPathFactory):
    """Los tests usan el catálogo BASE: la ingesta real de data/ (tablas PSI cargadas) no debe alterar sus expectativas."""
    import shutil

    from src import investigaciones as inv

    destino = tmp_path_factory.mktemp("catalogo_base") / "investigaciones.json"
    shutil.copy(inv.RUTA_CATALOGO, destino)
    original = inv.RUTA_CATALOGO
    inv.RUTA_CATALOGO = destino
    yield
    inv.RUTA_CATALOGO = original
