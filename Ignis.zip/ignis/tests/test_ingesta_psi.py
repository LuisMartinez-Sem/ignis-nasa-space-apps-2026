"""Ingesta PSI: formatos (CSV/JSON/HDF5), unidades SI e imperiales, cobertura y versionado.

IMPORTANTE: los archivos de estos tests son MOCKS generados a partir del dataset sintético
y convertidos a otras unidades. No son datos de la NASA: validan la mecánica de la ingesta.
"""

from __future__ import annotations

import json
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
import pytest

from src.dataset_sintetico import generar_dataset_sintetico
from src.data_loader import ErrorDatos
from src.ingesta_psi import ingestar_psi, cargar_cobertura
from src.lector_psi import (
    CATALOGO_PSI, ErrorLecturaPsi, RolExperimento, descubrir_archivos, inferir_mapeo, leer_tabla, normalizar_unidad,
)
from src.pipeline_datos import cargar_version, listar_versiones


def _base(n: int = 60, semilla: int = 1) -> pd.DataFrame:
    return generar_dataset_sintetico(n, semilla).head(n).reset_index(drop=True)


def _imperial(base: pd.DataFrame) -> pd.DataFrame:
    """Mismo contenido en unidades imperiales y con nombres tipo PSI (unidad entre paréntesis)."""
    return pd.DataFrame({
        "O2 (%)": base["fraccion_o2"] * 100,
        "Flow velocity (ft/s)": base["velocidad_flujo_cm_s"] / 30.48,
        "Pressure (psia)": base["presion_kpa"] / 6.894757,
        "Ambient temperature (°F)": (base["temperatura_ambiente_k"] - 273.15) * 9 / 5 + 32,
        "Thickness (mil)": base["espesor_combustible_mm"] / 0.0254,
        "Spread rate (in/s)": base["velocidad_propagacion_mm_s"] / 25.4,
        "Flow direction": base["regimen_flujo"].map({"concurrente": "concurrent", "opuesto": "opposed"}),
    })


@pytest.fixture
def arbol_psi(tmp_path: Path) -> Path:
    """data/raw/psi con 5 experimentos en 3 formatos + un PDF y un experimento sin unidades."""
    raiz = tmp_path / "raw" / "psi"
    for carpeta in ("saffire-i", "bass", "bass-ii", "flex", "saffire-ii"):
        (raiz / carpeta).mkdir(parents=True)
    # Saffire-I: CSV imperial, material por defecto del experimento (sibal)
    base = _base(60, 1)
    _imperial(base).to_csv(raiz / "saffire-i" / "tabla.csv", index=False)
    (raiz / "saffire-i" / "informe.pdf").write_bytes(b"%PDF-1.4 mock")
    # BASS: JSON con unidades declaradas en un bloque 'units' y material en columna
    b = _base(40, 2)
    json.dump({
        "units": {"o2": "fraction", "flow": "cm/s", "p": "kPa", "t_amb": "K", "thick": "mm", "spread": "mm/s"},
        "data": [{"o2": r.fraccion_o2, "flow": r.velocidad_flujo_cm_s, "p": r.presion_kpa, "t_amb": r.temperatura_ambiente_k,
                  "thick": r.espesor_combustible_mm, "spread": r.velocidad_propagacion_mm_s, "material": r.material}
                 for r in b.itertuples()],
    }, open(raiz / "bass" / "resultados.json", "w"))
    # BASS-II: HDF5 con atributo 'units' en cada dataset
    h = _base(30, 3)
    with h5py.File(raiz / "bass-ii" / "corridas.h5", "w") as f:
        for nombre, serie, unidad in (
            ("oxygen", h["fraccion_o2"] * 100, "%"), ("flow_speed", h["velocidad_flujo_cm_s"] / 100, "m/s"),
            ("pressure", h["presion_kpa"] * 1000, "Pa"), ("ambient_temp", h["temperatura_ambiente_k"] - 273.15, "degC"),
            ("thickness", h["espesor_combustible_mm"] / 1000, "m"), ("spread_rate", h["velocidad_propagacion_mm_s"] / 1000, "m/s"),
        ):
            d = f.create_dataset(f"grupo/{nombre}", data=serie.to_numpy())
            d.attrs["units"] = unidad
        f.create_dataset("grupo/material", data=np.array(h["material"].tolist(), dtype="S10"))
    # FLEX: CSV válido pero de rol llama_fria → se reporta, NO entra al entrenamiento
    _imperial(_base(25, 4)).to_csv(raiz / "flex" / "gotas.csv", index=False)
    # Saffire-II: columnas sin unidad reconocible → se omite con motivo claro
    pd.DataFrame({"oxygen": [0.21, 0.22], "flow": [10, 12], "pressure": [101, 100], "thickness": [0.3, 0.3], "spread": [1.0, 1.2]}
                 ).to_csv(raiz / "saffire-ii" / "sin_unidades.csv", index=False)
    return raiz


def test_normalizar_unidad_alias() -> None:
    assert normalizar_unidad("psia") == "psi" and normalizar_unidad("°C") == "c" and normalizar_unidad(" cm / s ") == "cm_s"
    assert normalizar_unidad("furlongs/fortnight") is None


def test_descubre_formatos_e_ignora_lo_demas(arbol_psi: Path) -> None:
    archivos, avisos = descubrir_archivos(arbol_psi)
    assert {a.formato for a in archivos} == {"csv", "json", "hdf5"}
    assert any("informe.pdf" in a for a in avisos)


def test_lectores_devuelven_unidades_declaradas(arbol_psi: Path) -> None:
    h5 = leer_tabla(arbol_psi / "bass-ii" / "corridas.h5")
    assert h5.unidades_declaradas["pressure"] == "Pa" and len(h5.datos) == 30
    js = leer_tabla(arbol_psi / "bass" / "resultados.json")
    assert js.unidades_declaradas["flow"] == "cm/s" and len(js.datos) == 40


def test_formato_no_soportado_y_json_roto(tmp_path: Path) -> None:
    with pytest.raises(ErrorLecturaPsi):
        leer_tabla(tmp_path / "x.xlsx")
    roto = tmp_path / "roto.json"
    roto.write_text("{no json", encoding="utf-8")
    with pytest.raises(ErrorLecturaPsi):
        leer_tabla(roto)


def test_inferencia_reconoce_unidades_del_nombre_de_columna(arbol_psi: Path) -> None:
    tabla = leer_tabla(arbol_psi / "saffire-i" / "tabla.csv")
    inferencia = inferir_mapeo(tabla, CATALOGO_PSI["saffire-i"])
    columnas = inferencia.mapeo["columnas"]
    assert columnas["presion_kpa"]["unidad"] == "psi" and columnas["temperatura_ambiente_k"]["unidad"] == "f"
    assert columnas["velocidad_propagacion_mm_s"]["unidad"] == "in_s" and not inferencia.faltantes
    assert inferencia.mapeo["material_fijo"] == "sibal"


def test_ingesta_completa_convierte_unidades_y_versiona(arbol_psi: Path, tmp_path: Path) -> None:
    datos_dir = tmp_path
    resultado = ingestar_psi(arbol_psi, datos_dir)
    r = resultado.reporte
    por_exp = {e.experimento: e for e in r.experimentos}

    # Entrenamiento: saffire-i (60) + bass (40) + bass-ii (30). FLEX (25) se reporta aparte.
    assert r.filas_entrenamiento == 130
    assert r.filas_por_experimento["flex"] == 25 and not por_exp["flex"].entra_al_entrenamiento
    assert por_exp["flex"].rol is RolExperimento.LLAMA_FRIA
    assert any("flex" in a and "NO se usan" in a for a in r.avisos)

    # Cobertura por experimento
    assert por_exp["saffire-i"].filas_crudas == 60 and por_exp["saffire-i"].estado == "ok"
    assert por_exp["bass-ii"].formatos == ["hdf5"] and por_exp["bass"].formatos == ["json"]
    assert por_exp["saffire-ii"].estado == "omitido" and "mapeo.json" in " ".join(por_exp["saffire-ii"].archivos_omitidos.values())

    # Versionado con SHA-256 y datos físicamente correctos tras convertir imperial/SI
    version = resultado.version
    assert version is not None and version.origen == "real" and version.n_filas == 130 and len(version.sha256) == 64
    datos = cargar_version(datos_dir, version.id)
    base = _base(60, 1)
    s1 = datos[datos["id_experimento"].str.startswith("saffire-i/")].reset_index(drop=True)
    assert np.allclose(s1["fraccion_o2"], base["fraccion_o2"], atol=1e-6)
    assert np.allclose(s1["presion_kpa"], base["presion_kpa"], rtol=1e-5)
    assert np.allclose(s1["temperatura_ambiente_k"], base["temperatura_ambiente_k"], atol=1e-4)
    assert np.allclose(s1["velocidad_propagacion_mm_s"], base["velocidad_propagacion_mm_s"], rtol=1e-5)
    assert set(s1["regimen_flujo"]) <= {"opuesto", "concurrente"}
    b2 = datos[datos["id_experimento"].str.startswith("bass-ii/")]
    assert np.allclose(sorted(b2["presion_kpa"]), sorted(_base(30, 3)["presion_kpa"]), rtol=1e-5)  # Pa → kPa
    assert set(b2["material"]) <= {"sibal", "pmma", "celulosa"}

    # El reporte queda junto a la versión y se puede recuperar
    guardado = cargar_cobertura(datos_dir, version)
    assert guardado is not None and guardado.filas_entrenamiento == 130


def test_ingesta_es_idempotente(arbol_psi: Path, tmp_path: Path) -> None:
    primera = ingestar_psi(arbol_psi, tmp_path).version
    segunda = ingestar_psi(arbol_psi, tmp_path).version
    assert primera is not None and segunda is not None and primera.id == segunda.id
    assert len(listar_versiones(tmp_path)) == 1


def test_filas_fuera_del_dominio_se_descartan_y_se_cuentan(tmp_path: Path) -> None:
    raiz = tmp_path / "raw" / "psi" / "bass"
    raiz.mkdir(parents=True)
    tabla = _imperial(_base(30, 5))
    tabla.loc[0, "O2 (%)"] = 90.0  # fuera del dominio operativo (máx. 40 %)
    tabla.loc[1, "Pressure (psia)"] = np.nan
    tabla["material"] = "pmma"
    tabla.to_csv(raiz / "t.csv", index=False)
    resultado = ingestar_psi(tmp_path / "raw" / "psi", tmp_path)
    cobertura = resultado.reporte.experimentos[0]
    assert cobertura.filas_crudas == 30 and cobertura.filas_validas == 28
    assert cobertura.descartadas["filas_descartadas"] == 2
    assert any("fraccion_o2" in motivo and "dominio" in motivo for motivo in cobertura.descartadas)


def test_mapeo_manual_manda_sobre_la_inferencia_y_admite_constantes(tmp_path: Path) -> None:
    carpeta = tmp_path / "raw" / "psi" / "saffire-ii"
    carpeta.mkdir(parents=True)
    base = _base(20, 6)
    pd.DataFrame({"o2": base["fraccion_o2"], "flujo": base["velocidad_flujo_cm_s"], "v": base["velocidad_propagacion_mm_s"]}
                 ).to_csv(carpeta / "t.csv", index=False)
    (carpeta / "mapeo.json").write_text(json.dumps({
        "columnas": {"fraccion_o2": {"columna": "o2", "unidad": "fraccion"},
                     "velocidad_flujo_cm_s": {"columna": "flujo", "unidad": "cm_s"},
                     "velocidad_propagacion_mm_s": {"columna": "v", "unidad": "mm_s"}},
        "constantes": {"presion_kpa": 101.3, "temperatura_ambiente_k": 295.0, "espesor_combustible_mm": 0.4},
        "material_fijo": "sibal", "regimen_fijo": "concurrente",
    }), encoding="utf-8")
    resultado = ingestar_psi(tmp_path / "raw" / "psi", tmp_path)
    assert resultado.reporte.filas_entrenamiento == 20
    datos = cargar_version(tmp_path, resultado.version.id)  # type: ignore[union-attr]
    assert (datos["presion_kpa"] == 101.3).all() and (datos["regimen_flujo"] == "concurrente").all()


def test_mapeo_manual_invalido_falla_ruidosamente(tmp_path: Path) -> None:
    carpeta = tmp_path / "raw" / "psi" / "bass"
    carpeta.mkdir(parents=True)
    (carpeta / "t.csv").write_text("a,b\n1,2\n", encoding="utf-8")
    (carpeta / "mapeo.json").write_text("{esto no es json", encoding="utf-8")
    with pytest.raises(ErrorDatos):
        ingestar_psi(tmp_path / "raw" / "psi", tmp_path)


def test_sin_archivos_no_registra_version(tmp_path: Path) -> None:
    (tmp_path / "raw" / "psi").mkdir(parents=True)
    resultado = ingestar_psi(tmp_path / "raw" / "psi", tmp_path)
    assert resultado.version is None and resultado.reporte.filas_entrenamiento == 0
    assert any("descarga datos" in a for a in resultado.reporte.avisos)
