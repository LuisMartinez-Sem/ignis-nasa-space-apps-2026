"""Cambios de la revisión técnica: dominio operativo, índice con tanh y roadmap público."""

from __future__ import annotations

import numpy as np
import pytest
from pydantic import ValidationError

from src.domain import (
    RANGOS, RANGOS_HISTORICOS, CondicionesAmbiente, CondicionesHistoricas, advertencias_operativas,
)
from src.predictor import (
    PESO_LLAMA_FRIA, PESO_PROBABILIDAD, PESO_VELOCIDAD, VELOCIDAD_NORMALIZACION_MM_S, calcular_indice_riesgo,
)


def _cond(**cambios) -> dict:
    base = dict(fraccion_o2=0.21, velocidad_flujo_cm_s=10.0, presion_kpa=101.3, temperatura_ambiente_k=295.0,
                espesor_combustible_mm=0.2, material="sibal")
    return {**base, **cambios}


def test_rangos_exactos_de_la_revision() -> None:
    assert RANGOS["fraccion_o2"] == (0.16, 0.40)
    assert RANGOS["presion_kpa"][0] == 35.0
    # La atmósfera nominal de la ISS (101,3 kPa) debe ser válida: tope = atmósfera estándar
    assert RANGOS["presion_kpa"][1] >= 101.3
    assert RANGOS["velocidad_flujo_cm_s"] == (0.0, 100.0)


@pytest.mark.parametrize(("campo", "valor"), [
    ("fraccion_o2", 0.159), ("fraccion_o2", 0.41), ("presion_kpa", 34.9), ("presion_kpa", 101.4),
])
def test_valores_fuera_del_dominio_operativo_se_rechazan(campo: str, valor: float) -> None:
    with pytest.raises(ValidationError):
        CondicionesAmbiente(**_cond(**{campo: valor}))


def test_condiciones_historicas_aceptan_o2_puro_pero_el_dominio_operativo_no() -> None:
    CondicionesHistoricas(**_cond(fraccion_o2=1.0, presion_kpa=115.1))
    assert RANGOS_HISTORICOS["fraccion_o2"][1] == 1.0
    with pytest.raises(ValidationError):
        CondicionesAmbiente(**_cond(fraccion_o2=1.0))


@pytest.mark.parametrize(("o2", "presion", "esperadas"), [
    (0.21, 101.3, 0), (0.36, 101.3, 0), (0.361, 101.3, 1), (0.40, 101.3, 1),
    (0.21, 40.0, 0), (0.21, 39.9, 1), (0.38, 36.0, 2),
])
def test_advertencias_en_el_borde(o2: float, presion: float, esperadas: int) -> None:
    c = CondicionesAmbiente(**_cond(fraccion_o2=o2, presion_kpa=presion))
    assert len(advertencias_operativas(c)) == esperadas


def test_pesos_del_indice_suman_uno_y_son_los_de_la_revision() -> None:
    assert (PESO_PROBABILIDAD, PESO_VELOCIDAD, PESO_LLAMA_FRIA) == (0.55, 0.30, 0.15)
    assert PESO_PROBABILIDAD + PESO_VELOCIDAD + PESO_LLAMA_FRIA == pytest.approx(1.0)


def test_indice_tanh_es_monotono_acotado_y_satura_suavemente() -> None:
    v = np.array([0.0, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 200.0])
    indice = calcular_indice_riesgo(np.ones_like(v), v, np.zeros_like(v))
    assert np.all(np.diff(indice) > 0), "con tanh la velocidad nunca deja de aportar (no hay tope duro)"
    assert indice.max() <= 100.0
    # A la velocidad de referencia la severidad es tanh(1) ≈ 0,76, no 1,0 como con min()
    en_referencia = calcular_indice_riesgo(np.array([1.0]), np.array([VELOCIDAD_NORMALIZACION_MM_S]), np.array([0.0]))
    assert en_referencia[0] == pytest.approx(100 * (0.55 + 0.30 * np.tanh(1.0)))


def test_indice_velocidades_moderadas_de_microgravedad() -> None:
    """1-2 mm/s (rango de Saffire-I) aportan severidad moderada: con la ley calibrada (escala 4.74 mm/s) 2 mm/s suman ~11 pts."""
    sin_velocidad = calcular_indice_riesgo(np.array([0.5]), np.array([0.0]), np.array([0.0]))[0]
    con_2_mm_s = calcular_indice_riesgo(np.array([0.5]), np.array([2.0]), np.array([0.0]))[0]
    assert 0 < con_2_mm_s - sin_velocidad < 12.0


def test_endpoint_variables_no_incluidas(cliente) -> None:
    filas = cliente.get("/api/v1/modelo/variables_no_incluidas").json()
    assert {f["prioridad"] for f in filas} == {"alta", "media"}
    nombres = " ".join(f["variable"] for f in filas)
    assert "Geometría" in nombres and "Historial de ignición" in nombres
