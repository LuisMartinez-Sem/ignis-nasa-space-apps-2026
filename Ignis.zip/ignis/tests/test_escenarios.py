"""Guiones de reproducción: coherencia, honestidad (sin Apollo evaluado) y endpoint."""

from __future__ import annotations

import pytest

from src.escenarios import catalogo_escenarios, generar_reproduccion, sintetizar_senales

IDS = {"nominal", "escalada", "mitigacion", "cool-flame", "mir-1997", "iss-2015", "apollo1-1967", "saffire-2016-2024"}


def test_catalogo_tiene_los_seis_escenarios_y_los_incidentes() -> None:
    assert set(catalogo_escenarios()) == IDS


def test_senales_deterministas_y_con_forma_correcta() -> None:
    e = catalogo_escenarios()["escalada"]
    a, b = sintetizar_senales(e), sintetizar_senales(e)
    assert a.shape == (900, 6) and (a == b).all()
    assert a[:300, 0].max() < 20 and a[700:, 0].max() > 400  # frío antes de la ignición, caliente después


def test_nominal_no_tiene_evento_ni_marcas(cliente) -> None:
    r = cliente.get("/api/v1/escenarios/nominal/reproduccion").json()
    assert not any(f["evento_activo"] for f in r["frames"]) and r["marcas_ignis"] == []


def test_escalada_marca_alarma_y_critico(cliente) -> None:
    r = cliente.get("/api/v1/escenarios/escalada/reproduccion").json()
    textos = {m["texto"] for m in r["marcas_ignis"]}
    assert "Alarma del detector TCN" in textos and "Índice en CRITICO" in textos
    assert r["fuego"]["sector"] == "B-2" and r["latencias_ms"]["tcn_ms_medio"] is not None


def test_apollo_nunca_se_evalua_con_el_modelo(cliente) -> None:
    r = cliente.get("/api/v1/escenarios/apollo1-1967/reproduccion").json()
    assert all(f["indice_riesgo"] is None and f["fuera_de_dominio"] for f in r["frames"])
    assert r["frames"][0]["condiciones"]["fraccion_o2"] == 1.0


def test_saffire_compara_prediccion_con_medicion(cliente) -> None:
    r = cliente.get("/api/v1/escenarios/saffire-2016-2024/reproduccion").json()
    assert r["frames"][0]["medicion_mm_s"] == pytest.approx(1.8) and r["frames"][0]["velocidad_propagacion_mm_s"] is not None


def test_iss_pico_aislado_no_alarma(cliente) -> None:
    r = cliente.get("/api/v1/escenarios/iss-2015/reproduccion").json()
    assert not any(f["alarma_detector"] for f in r["frames"])


def test_listado_e_id_invalido(cliente) -> None:
    lista = cliente.get("/api/v1/escenarios").json()
    assert {e["id"] for e in lista} == IDS and {e["grupo"] for e in lista} == {"escenario", "incidente"}
    assert cliente.get("/api/v1/escenarios/no-existe/reproduccion").status_code == 404
    assert cliente.get("/api/v1/escenarios/..%2Fx/reproduccion").status_code in (404, 422)
