"""El simulador de ESP32 genera lecturas que la API acepta."""

from __future__ import annotations

import random

import pytest

from scripts.simulador_hardware import ESCENARIOS, generar_lectura


@pytest.mark.parametrize("escenario", ESCENARIOS)
def test_lecturas_aceptadas_por_la_api(cliente, escenario) -> None:
    rng = random.Random(1)
    for t in (0, 14, 16, 30, 59):
        r = cliente.post("/api/v1/predict", json=generar_lectura(t, escenario, rng))
        assert r.status_code == 200, r.text


def test_nominal_sin_reaccion_y_determinista() -> None:
    assert "temperatura_reaccion_k" not in generar_lectura(40, "nominal", random.Random(1))
    assert generar_lectura(30, "ignicion", random.Random(3)) == generar_lectura(30, "ignicion", random.Random(3))
    with pytest.raises(ValueError):
        generar_lectura(1, "x", random.Random(1))
