"""Tests del modelo, Cool Flames y predictor (lógica crítica)."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from src.cool_flame import clasificar_estado, probabilidad_llama_fria
from src.domain import CondicionesAmbiente, EstadoLlamaFria, NivelRiesgo
from src.model import ErrorModelo, ModeloPropagacion
from src.predictor import PredictorIgnis, calcular_indice_riesgo, clasificar_nivel


def _condiciones(base: dict, **cambios) -> CondicionesAmbiente:
    return CondicionesAmbiente(**{**base, **cambios})


def test_modelo_metricas_aceptables(modelo_pequeno: ModeloPropagacion) -> None:
    assert modelo_pequeno.metricas is not None
    assert modelo_pequeno.metricas.auc_propagacion > 0.95
    assert modelo_pequeno.metricas.r2_velocidad > 0.85


def test_bajo_limite_de_extincion_no_propaga(
    predictor_pequeno: PredictorIgnis, condiciones_validas: dict
) -> None:
    r = predictor_pequeno.evaluar(_condiciones(condiciones_validas, fraccion_o2=0.165, velocidad_flujo_cm_s=2.0))
    assert r.probabilidad_propagacion < 0.2
    assert r.nivel_riesgo is NivelRiesgo.NOMINAL


def test_alto_o2_propaga_con_riesgo_alto(
    predictor_pequeno: PredictorIgnis, condiciones_validas: dict
) -> None:
    r = predictor_pequeno.evaluar(_condiciones(condiciones_validas, fraccion_o2=0.35))
    assert r.probabilidad_propagacion > 0.8
    assert r.nivel_riesgo in (NivelRiesgo.ALERTA, NivelRiesgo.CRITICO)


def test_incertidumbre_y_velocidad_no_negativas(
    predictor_pequeno: PredictorIgnis, condiciones_validas: dict
) -> None:
    r = predictor_pequeno.evaluar(_condiciones(condiciones_validas))
    assert r.velocidad_propagacion_mm_s >= 0 and r.incertidumbre_mm_s >= 0


def test_lote_coincide_con_evaluacion_individual(
    predictor_pequeno: PredictorIgnis, condiciones_validas: dict
) -> None:
    lote = [_condiciones(condiciones_validas, fraccion_o2=o2) for o2 in (0.17, 0.21, 0.30)]
    individuales = [predictor_pequeno.evaluar(c) for c in lote]
    en_lote = predictor_pequeno.evaluar_lote(lote)
    assert [r.indice_riesgo for r in individuales] == pytest.approx([r.indice_riesgo for r in en_lote])


def test_lote_vacio_devuelve_lista_vacia(predictor_pequeno: PredictorIgnis) -> None:
    assert predictor_pequeno.evaluar_lote([]) == []


def test_modelo_sin_entrenar_falla_explicitamente() -> None:
    with pytest.raises(ErrorModelo):
        PredictorIgnis(ModeloPropagacion())


def test_guardar_y_cargar_conserva_predicciones(
    modelo_pequeno: ModeloPropagacion, condiciones_validas: dict, tmp_path: Path
) -> None:
    ruta = tmp_path / "m.joblib"
    modelo_pequeno.guardar(ruta)
    recargado = ModeloPropagacion.cargar(ruta)
    condiciones = _condiciones(condiciones_validas, fraccion_o2=0.25)
    a = PredictorIgnis(modelo_pequeno).evaluar(condiciones)
    b = PredictorIgnis(recargado).evaluar(condiciones)
    assert a.indice_riesgo == pytest.approx(b.indice_riesgo)
    assert recargado.origen_datos == modelo_pequeno.origen_datos


def test_cargar_modelo_corrupto_falla_con_error_claro(tmp_path: Path) -> None:
    ruta = tmp_path / "roto.joblib"
    ruta.write_bytes(b"esto no es un modelo")
    with pytest.raises(ErrorModelo):
        ModeloPropagacion.cargar(ruta)


# --- Cool Flames --------------------------------------------------------------
def test_llama_fria_maxima_en_la_ventana() -> None:
    temperaturas = np.array([300.0, 700.0, 1300.0])
    prob = probabilidad_llama_fria(temperaturas, np.full(3, 0.18), np.full(3, 101.3))
    assert prob[1] > 0.9 and prob[0] < 0.01 and prob[2] < 0.01


def test_llama_fria_nan_se_propaga() -> None:
    prob = probabilidad_llama_fria(np.array([np.nan]), np.array([0.2]), np.array([101.3]))
    assert np.isnan(prob[0])


@pytest.mark.parametrize(
    ("probabilidad", "esperado"),
    [
        (None, EstadoLlamaFria.NO_EVALUADA),
        (float("nan"), EstadoLlamaFria.NO_EVALUADA),
        (0.05, EstadoLlamaFria.INACTIVA),
        (0.40, EstadoLlamaFria.POSIBLE),
        (0.90, EstadoLlamaFria.PROBABLE),
    ],
)
def test_clasificar_estado_llama_fria(probabilidad, esperado) -> None:
    assert clasificar_estado(probabilidad) is esperado


def test_sin_temperatura_reaccion_no_se_evalua_llama_fria(
    predictor_pequeno: PredictorIgnis, condiciones_validas: dict
) -> None:
    r = predictor_pequeno.evaluar(_condiciones(condiciones_validas))
    assert r.estado_llama_fria is EstadoLlamaFria.NO_EVALUADA
    assert r.probabilidad_llama_fria is None


def test_llama_fria_probable_genera_accion_de_termografia(
    predictor_pequeno: PredictorIgnis, condiciones_validas: dict
) -> None:
    r = predictor_pequeno.evaluar(
        _condiciones(condiciones_validas, fraccion_o2=0.18, temperatura_reaccion_k=700.0)
    )
    assert r.estado_llama_fria is EstadoLlamaFria.PROBABLE
    assert any("termografía" in accion for accion in r.acciones_sugeridas)


# --- Índice de riesgo -----------------------------------------------------------
def test_indice_riesgo_acotado_y_monotono() -> None:
    prob = np.array([0.0, 0.5, 1.0])
    indice = calcular_indice_riesgo(prob, np.array([0.0, 5.0, 50.0]), np.array([np.nan, 0.0, 1.0]))
    assert indice.min() >= 0 and indice.max() <= 100
    assert np.all(np.diff(indice) > 0)


def test_fronteras_de_nivel() -> None:
    niveles = clasificar_nivel(np.array([0.0, 24.9, 25.0, 50.0, 75.0, 100.0]))
    assert niveles == [
        NivelRiesgo.NOMINAL, NivelRiesgo.NOMINAL, NivelRiesgo.PRECAUCION,
        NivelRiesgo.ALERTA, NivelRiesgo.CRITICO, NivelRiesgo.CRITICO,
    ]
