"""Anclas publicadas (Saffire-I, FLEX): el generador y los modelos deben reproducirlas."""

from __future__ import annotations

import json

import numpy as np
import pytest

from src.cool_flame import probabilidad_llama_fria
from src.dataset_sintetico import (
    FACTOR_CONCURRENTE, FACTOR_MATERIAL, DESPLAZAMIENTO_LIMITE_CONCURRENTE, DESPLAZAMIENTO_LIMITE_O2,
    FILAS_POR_ANCLA, RUTA_ANCLAS, anclas_de_velocidad, cargar_anclas, generar_dataset_sintetico,
    limite_o2_extincion, velocidad_propagacion_ideal_mm_s,
)
from src.domain import Material

TOLERANCIA_MODELO = 0.20  # ±20 % pedido para las predicciones de los modelos


def _ley(c: dict) -> float:
    conc = c["regimen_flujo"] == "concurrente"
    material = Material(c["material"])
    desplazamiento = DESPLAZAMIENTO_LIMITE_O2[material] + (DESPLAZAMIENTO_LIMITE_CONCURRENTE if conc else 0.0)
    a = lambda v: np.array([v], dtype=float)  # noqa: E731
    limite = limite_o2_extincion(a(c["velocidad_flujo_cm_s"]), a(c["presion_kpa"]), a(desplazamiento))
    return float(velocidad_propagacion_ideal_mm_s(
        a(c["fraccion_o2"]), a(c["velocidad_flujo_cm_s"]), a(c["presion_kpa"]), a(c["espesor_combustible_mm"]),
        a(FACTOR_MATERIAL[material]), limite, FACTOR_CONCURRENTE if conc else 1.0, a(c["temperatura_ambiente_k"]))[0])


def test_archivo_de_anclas_es_valido_y_separa_entrenamiento_de_referencia() -> None:
    anclas = {a["id"]: a for a in cargar_anclas()}
    assert len(anclas) >= 4
    assert {a["uso"] for a in anclas.values()} == {"entrenamiento", "referencia"}
    # Fuera del dominio del modelo o no son velocidades: no se entrenan
    for fuera in ("saffire-ii-silicona-1g", "saffire-i-tiempo-combustion-s1", "saffire-i-tiempo-combustion-s2"):
        assert anclas[fuera]["uso"] == "referencia" and anclas[fuera]["motivo_exclusion"]
    assert {a["id"] for a in anclas_de_velocidad()} == {"saffire-i-concurrente", "saffire-i-opuesto"}
    assert all(a["verificacion"] for a in anclas.values())


def test_json_de_anclas_roto_falla_con_mensaje(tmp_path) -> None:
    roto = tmp_path / "a.json"
    roto.write_text("{no", encoding="utf-8")
    with pytest.raises(ValueError, match="inválido"):
        cargar_anclas(roto)
    roto.write_text(json.dumps({"x": 1}), encoding="utf-8")
    with pytest.raises(ValueError, match="anclas"):
        cargar_anclas(roto)


@pytest.mark.parametrize("ancla", anclas_de_velocidad(), ids=lambda a: a["id"])
def test_la_ley_calibrada_reproduce_el_ancla(ancla: dict) -> None:
    assert _ley(ancla["condiciones"]) == pytest.approx(ancla["valor"], rel=0.01)


def test_dataset_conserva_tamano_e_inyecta_filas_ancla() -> None:
    datos = generar_dataset_sintetico(6000, 42)
    assert len(datos) == 6000
    cola = datos.tail(FILAS_POR_ANCLA * len(anclas_de_velocidad()))
    for ancla in anclas_de_velocidad():
        filas = cola[cola["regimen_flujo"] == ancla["condiciones"]["regimen_flujo"]]
        assert len(filas) == FILAS_POR_ANCLA
        assert filas["velocidad_propagacion_mm_s"].mean() == pytest.approx(ancla["valor"], rel=0.05)
    assert len(generar_dataset_sintetico(100, 1)) == 100  # pocas filas: sin anclas, comportamiento previo


def _consulta(ancla: dict) -> dict:
    return {**ancla["condiciones"]}


@pytest.mark.parametrize("motor", ["rf", "profundo"])
@pytest.mark.parametrize("ancla", anclas_de_velocidad(), ids=lambda a: a["id"])
def test_los_modelos_predicen_las_anclas_dentro_de_20_pct(cliente, motor: str, ancla: dict) -> None:
    respuesta = cliente.post(f"/api/v1/predict?motor={motor}", json=_consulta(ancla))
    assert respuesta.status_code == 200, respuesta.text
    prediccion = respuesta.json()["velocidad_propagacion_mm_s"]
    error = abs(prediccion - ancla["valor"]) / ancla["valor"]
    assert error <= TOLERANCIA_MODELO, f"{motor}: {prediccion:.2f} vs {ancla['valor']} ({error:.0%})"


def test_se_conserva_la_razon_concurrente_opuesto_de_saffire_i(cliente) -> None:
    v = {}
    for ancla in anclas_de_velocidad():
        v[ancla["id"]] = cliente.post("/api/v1/predict?motor=rf", json=_consulta(ancla)).json()["velocidad_propagacion_mm_s"]
    razon = v["saffire-i-concurrente"] / v["saffire-i-opuesto"]
    assert 1.385 * 0.85 <= razon <= 1.385 * 1.15


def test_ventana_flex_550_800_k_es_el_semimaximo_de_la_llama_fria() -> None:
    ancla = next(a for a in cargar_anclas() if a["id"] == "flex-cool-flame-ventana")
    bajo, alto = ancla["valor"]
    T = np.array([450.0, bajo, 675.0, alto, 900.0])
    p = probabilidad_llama_fria(T, np.full(5, 0.18), np.full(5, 80.0))
    assert p[2] == p.max(), "el máximo cae dentro de la ventana"
    assert p[1] >= 0.5 * p[2] * 0.98 and p[3] >= 0.5 * p[2] * 0.98, "los bordes de la ventana valen ~la mitad del pico"
    assert p[0] < 0.1 and p[4] < 0.1, "fuera de la ventana la probabilidad es despreciable"
