"""Modo Emergencia: estructura, honestidad (medido vs objetivo) y límites declarados."""

from __future__ import annotations

import pytest

from src.config import obtener_configuracion
from src.detector_temporal import DetectorTemporal
from src.emergencias import IDS_EMERGENCIAS, ErrorEmergencia, construir_emergencia, listar_emergencias


@pytest.fixture(scope="module")
def detector() -> DetectorTemporal:
    return DetectorTemporal.cargar(obtener_configuracion().ruta_detector)


@pytest.fixture(scope="module")
def fichas(predictor_pequeno, detector) -> dict:
    return {i: construir_emergencia(i, predictor_pequeno, detector) for i in IDS_EMERGENCIAS}


def test_catalogo_tiene_las_cuatro_emergencias() -> None:
    assert [e["id"] for e in listar_emergencias()] == ["mir-1997", "iss-2015", "columbus-cool-flame", "saffire-cable"]


def test_estructura_completa(fichas) -> None:
    for f in fichas.values():
        assert f.timeline_humano and f.timeline_ignis and f.guia_copiloto
        assert f.impacto.modulo_afectado and f.condiciones_iniciales
        assert f.guia_copiloto[-1].startswith("Apoyo a decisión")


def test_id_desconocido_y_detector_ausente(predictor_pequeno, detector) -> None:
    with pytest.raises(ErrorEmergencia):
        construir_emergencia("apollo", predictor_pequeno, detector)
    with pytest.raises(ErrorEmergencia):
        construir_emergencia("mir-1997", predictor_pequeno, None)


def test_mir_detecta_rapido_y_ventana_es_contrafactual(fichas) -> None:
    f = fichas["mir-1997"]
    assert f.mediciones["deteccion_s"] is not None and f.mediciones["deteccion_s"] < 3.0
    assert f.impacto.tipo_tiempo == "ventana_de_oportunidad_contrafactual"
    assert f.impacto.tiempo_ahorrado_s == pytest.approx(90 - f.mediciones["deteccion_s"], abs=0.01)


def test_iss_el_pico_aislado_no_da_alarma(fichas) -> None:
    f = fichas["iss-2015"]
    assert f.mediciones["alarmas"] == 0.0
    assert f.mediciones["descarte_s"] < 2.0
    assert f.impacto.vidas_en_riesgo is None  # no documentado: no se inventa


def test_columbus_humano_no_ve_y_ignis_detecta(fichas) -> None:
    f = fichas["columbus-cool-flame"]
    assert f.es_hipotetico and all(e.t_s is None for e in f.timeline_humano)
    assert f.mediciones["deteccion_s"] is not None and f.mediciones["deteccion_s"] < 2.0
    assert f.mediciones["alerta_s"] is not None and f.mediciones["alerta_s"] < 5.0
    assert f.impacto.tiempo_ahorrado_s is None


def test_cable_localizacion_3d_no_esta_implementada(fichas) -> None:
    f = fichas["saffire-cable"]
    assert f.mediciones["localizacion_3d_s"] is None
    assert "Localización 3D del foco" in f.capacidades_no_implementadas
    assert f.objetivos_diseno["localizacion_3d_s"] == 1.5  # objetivo, no medición
    assert any(e.t_s == 45 and e.confianza == "supuesto" for e in f.timeline_humano)


def test_objetivos_de_diseno_separados_y_sin_medicion_inventada(fichas) -> None:
    for f in fichas.values():
        assert f.objetivos_diseno  # el objetivo pedido queda registrado aparte
        for clave in f.objetivos_diseno:
            assert clave in f.mediciones or clave in ("guia_extincion_s", "extincion_ignis_simulada_s")
        assert all(v is None or isinstance(v, float) for v in f.mediciones.values())


def test_mir_espuma_no_co2_y_comparacion_con_extincion(fichas) -> None:
    f = fichas["mir-1997"]
    assert f.guia_copiloto[0] == "Aislar sector y usar espuma."
    assert not any("extintor de CO" in g.lower() and "no usar" not in g.lower() for g in f.guia_copiloto)
    assert f.mediciones["extincion_s"] == 90.0 and f.timeline_humano[1].t_s == 0
    assert any(e.t_s == 90 for e in f.timeline_humano)


def test_endpoint_emergencias_contrato_frontend(cliente) -> None:
    lista = cliente.get("/api/v1/emergencias").json()
    assert [e["id"] for e in lista] == ["mir-1997", "iss-2015", "columbus-cool-flame"]
    assert {"id", "nombre", "fecha", "lugar", "tipo", "es_incendio", "modelo_aplicable", "resumen"} <= set(lista[0])
    assert cliente.get("/api/v1/emergencias/nope-x").status_code == 404
    assert cliente.get("/api/v1/emergencias/saffire-cable").status_code == 404
    r = cliente.get("/api/v1/emergencias/mir-1997")
    if r.status_code == 503:
        return
    d = r.json()
    assert d["incidente"]["id"] == "mir-1997" and d["incidente"]["timeline_humano"]
    assert {"deteccion_s", "supresion_s", "supresion_es_supuesto", "falsas_alarmas", "es_supuesto"} <= set(d["ignis"])
    assert d["humano"]["extincion_s"] == 90 and d["humano"]["deteccion_s"] == 0
    m = d["simulacion"]["muestras"][0]
    assert {"t_s", "indice_riesgo", "fraccion_o2", "temperatura_reaccion_k", "nivel_riesgo", "estado_ntc"} <= set(m)
    assert d["acciones"][0]["descripcion"] == "Aislar sector y usar espuma."
    assert {"id", "descripcion", "fuente", "fuente_verificada", "confianzas", "primer_t_s"} <= set(d["acciones"][0])
    c = cliente.get("/api/v1/emergencias/columbus-cool-flame").json()
    assert c["incidente"]["inicio_evento_s"] == 10.0 and c["humano"] is None
    assert cliente.get("/api/v1/emergencias/iss-2015").json()["ignis"]["falsas_alarmas"] == 0.0


def test_si_insights(cliente) -> None:
    datos = cliente.get("/api/v1/si-insights").json()
    assert len(datos) >= 4 and all({"tipo", "texto", "fuente", "verificacion"} <= set(i) for i in datos)
    assert any("1.8" in i["texto"] and "1.3" in i["texto"] for i in datos)
    assert any("550" in i["texto"] and "800" in i["texto"] for i in datos)
