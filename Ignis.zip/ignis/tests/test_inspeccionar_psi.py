"""Inspección previa de data/raw/psi con el árbol simulado."""

from __future__ import annotations

import json
from pathlib import Path

from scripts import inspeccionar_psi as ins
from tests.test_ingesta_psi import arbol_psi  # noqa: F401  (fixture)


def test_informe_lista_archivos_y_diagnostica_tablas(arbol_psi: Path) -> None:  # noqa: F811
    informe = ins.inspeccionar(arbol_psi)
    sa = informe["experimentos"]["saffire-i"]
    assert {a["nombre"] for a in sa["archivos"]} == {"tabla.csv", "informe.pdf"}
    tabla = sa["tablas"][0]
    assert tabla["entendido_por_el_lector"] and tabla["filas"] == 60 and tabla["mapeo_inferido"]["presion_kpa"]["unidad"] == "psi"
    # Sin unidades reconocibles: se reporta como NO entendido, con sus faltantes (no se adivina)
    malo = informe["experimentos"]["saffire-ii"]["tablas"][0]
    assert not malo["entendido_por_el_lector"] and "presion_kpa" in malo["faltantes"]


def test_cli_json_y_carpeta_inexistente(arbol_psi: Path, tmp_path: Path) -> None:  # noqa: F811
    salida = tmp_path / "informe.json"
    assert ins.main(["--raiz", str(arbol_psi), "--json", str(salida)]) == 0
    assert "saffire-i" in json.loads(salida.read_text(encoding="utf-8"))["experimentos"]
    assert ins.main(["--raiz", str(tmp_path / "nada")]) == 2
