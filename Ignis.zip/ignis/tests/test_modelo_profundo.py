"""Ensemble profundo: entrenamiento mínimo, incertidumbre, persistencia y afinado."""

from __future__ import annotations

import numpy as np
import pytest

pytest.importorskip("torch")

from src.data_loader import cargar_dataset
from src.model import ErrorModelo
from src.modelo_profundo import ModeloProfundo


@pytest.fixture(scope="module")
def datos():
    return cargar_dataset(None, n_muestras_sinteticas=1200, semilla=3)


@pytest.fixture(scope="module")
def modelo(datos) -> ModeloProfundo:
    m = ModeloProfundo(miembros=3, semilla=3)
    m.entrenar(datos[0], datos[1], epocas=12)
    return m


def test_predicciones_validas_y_con_incertidumbre(modelo, datos) -> None:
    cruda = modelo.predecir(datos[0].head(50))
    assert np.all(cruda.velocidad_mm_s >= 0)
    assert np.all((cruda.probabilidad_propagacion >= 0) & (cruda.probabilidad_propagacion <= 1))
    assert np.all(cruda.incertidumbre_mm_s >= 0)


def test_predecir_sin_entrenar_falla() -> None:
    with pytest.raises(ErrorModelo):
        ModeloProfundo(miembros=2).predecir(cargar_dataset(None, 500, 1)[0].head(3))


def test_guardar_y_cargar_reproduce_predicciones(modelo, datos, tmp_path) -> None:
    ruta = tmp_path / "m.pt"
    modelo.guardar(ruta)
    recargado = ModeloProfundo.cargar(ruta)
    original = modelo.predecir(datos[0].head(20)).velocidad_mm_s
    assert np.allclose(original, recargado.predecir(datos[0].head(20)).velocidad_mm_s, atol=1e-5)


def test_cargar_archivo_corrupto_falla_limpio(tmp_path) -> None:
    ruta = tmp_path / "roto.pt"
    ruta.write_bytes(b"no es un modelo")
    with pytest.raises(ErrorModelo):
        ModeloProfundo.cargar(ruta)


def test_afinar_devuelve_metricas_antes_y_despues(modelo, datos) -> None:
    reales = datos[0].sample(120, random_state=1)
    resultado = modelo.afinar(reales, datos[0].sample(120, random_state=2), epocas=3)
    assert resultado.mae_antes_mm_s >= 0 and resultado.mae_despues_mm_s >= 0
