"""SI Dashboard: catálogo, ranking explicable, huecos, exportación y preset lunar."""

from __future__ import annotations

import csv
import io

import pytest

from src import investigaciones as inv

NOMBRES_RETO = {"bass", "bass-ii", "spice", "slice", "saffire-i", "saffire-ii", "saffire-iii", "same", "same-r", "daft", "daft-2",
                "flex", "flex-2", "cfi", "acme-cfi-g", "acme-bre", "acme-efield", "luci", "fm2"}


def test_catalogo_cubre_las_investigaciones_del_reto() -> None:
    assert {i.id for i in inv.cargar_catalogo()} == NOMBRES_RETO
    assert sum(inv.PESOS.values()) == 100


def test_catalogo_no_inventa_o2_ni_flujo() -> None:
    """Solo Saffire-I (ancla del equipo) y CFI-G (reto: hasta 85 %) traen O₂; el resto es desconocido."""
    con_o2 = {i.id for i in inv.cargar_catalogo() if i.o2_pct.min is not None or i.o2_pct.max is not None}
    assert con_o2 == {"saffire-i", "acme-cfi-g"}
    assert all("o2_pct" in i.campos_no_verificados for i in inv.cargar_catalogo() if i.id not in con_o2)


def test_ranking_orden_desglose_e_interpretacion() -> None:
    r = inv.ranking("luna")
    assert [x.posicion for x in r] == list(range(1, len(r) + 1))
    assert all(r[i].puntaje >= r[i + 1].puntaje for i in range(len(r) - 1))
    for x in r:
        assert abs(sum(d.aporte for d in x.desglose) - x.puntaje) < 0.2 and x.interpretacion.startswith("Relevancia")
        assert 0 <= x.puntaje <= 100
    assert [x.investigacion.id for x in inv.ranking("iss", area="supresion")] and all("supresion" in x.investigacion.areas_seguridad for x in inv.ranking("iss", area="supresion"))


def test_ranking_cambia_con_el_entorno() -> None:
    assert inv.ranking("iss")[0].puntaje != inv.ranking("luna")[0].puntaje or inv.ranking("iss")[0].investigacion.id != inv.ranking("luna")[0].investigacion.id
    luna = {x.investigacion.id: x for x in inv.ranking("luna")}
    por = {d.componente: d.valor for d in luna["luci"].desglose}
    assert por["gravedad"] == 1.0  # gravedad parcial pendiente: máxima relevancia, pero…
    assert por["datos"] == 0.0  # …sin datos en PSI


def test_huecos_honestos() -> None:
    ids = {h.id for h in inv.huecos()}
    assert {"sin-gravedad-parcial", "sin-modelo-supresion", "sin-validacion-externa", "sin-solidos-luna"} <= ids
    assert {h.ambito for h in inv.huecos()} == {"nasa_psi", "ignis"}


def test_csv_seguro_y_con_columnas_de_relevancia() -> None:
    filas = list(csv.DictReader(io.StringIO(inv.exportar_csv())))
    assert len(filas) == len(NOMBRES_RETO) and {"relevancia_iss", "relevancia_luna", "relevancia_marte", "relevancia_traje"} <= set(filas[0])
    assert inv._seguro_csv("=HYPERLINK(1)") == "'=HYPERLINK(1)" and inv._seguro_csv("ok") == "ok"
    assert len(inv.filas_exportacion("anclas")) == 6


def test_catalogo_invalido(tmp_path) -> None:
    ruta = tmp_path / "x.json"
    ruta.write_text("{roto")
    with pytest.raises(inv.ErrorCatalogo):
        inv.leer_catalogo_estricto(ruta)


def test_endpoints(cliente) -> None:
    c = cliente.get("/api/v1/investigaciones").json()
    assert c["total"] == 19 and set(c["items"][0]["relevancia"]) == {"iss", "luna", "marte", "traje"}
    r = cliente.get("/api/v1/investigaciones/ranking?entorno=luna&combustible=solido").json()
    assert r["entorno"]["id"] == "luna" and r["total"] > 0 and all("solido" in x["investigacion"]["combustible_tipos"] for x in r["resultados"])
    assert cliente.get("/api/v1/investigaciones/ranking?entorno=venus").status_code == 422
    assert cliente.get("/api/v1/investigaciones/gaps").status_code == 200
    e = cliente.get("/api/v1/investigaciones/export?formato=csv")
    assert e.status_code == 200 and "attachment" in e.headers["content-disposition"] and e.text.startswith("id,")
    assert cliente.get("/api/v1/investigaciones/export?formato=json&conjunto=anclas").json()[0]["id"]
    assert cliente.get("/api/v1/investigaciones/comparar?ids=bass,saffire-i").json()["diferencias"]
    assert cliente.get("/api/v1/investigaciones/comparar?ids=bass,nope").status_code == 404
    assert cliente.get("/api/v1/investigaciones/saffire-i").status_code == 200
    assert cliente.get("/api/v1/investigaciones/xx-no").status_code == 404
    assert len(cliente.get("/api/v1/investigaciones/aplicaciones-terrestres").json()) == 3


def test_preset_lunar(cliente) -> None:
    r = cliente.post("/api/v1/preset/lunar")
    assert r.status_code == 200
    d = r.json()
    assert d["condiciones"]["fraccion_o2"] >= 0.30 and d["condiciones"]["presion_kpa"] <= 70.3
    assert d["evaluacion"]["indice_riesgo"] > d["referencia_iss"]["indice_riesgo"]
    assert abs(d["ppo2_kpa"] - 21.1) < 0.2 and any("gravedad" in a.lower() for a in d["advertencias"])
    assert cliente.post("/api/v1/preset/lunar", json={"fraccion_o2": 0.25}).status_code == 422  # < 30 %
    assert cliente.post("/api/v1/preset/lunar", json={"presion_kpa": 90}).status_code == 422  # > 70,3 kPa
    assert cliente.post("/api/v1/preset/lunar", json={"x": 1}).status_code == 422
