"""PDF forense, telemetría ISS y contratos API ↔ frontend (con el JS real de emergencias.js)."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import pytest

from src.iss_telemetria import telemetria_iss

JS = Path(__file__).resolve().parent.parent / "frontend" / "js" / "emergencias.js"


def test_pdf_forense(cliente) -> None:
    r = cliente.get("/api/v1/incidentes/mir-1997/reporte_pdf")
    if r.status_code == 503:
        pytest.skip("detector aún entrenando")
    assert r.status_code == 200 and r.headers["content-type"] == "application/pdf" and r.content.startswith(b"%PDF")
    assert cliente.get("/api/v1/incidentes/no-existe/reporte_pdf").status_code == 404


def test_telemetria_iss_realista_y_etiquetada(cliente) -> None:
    d = cliente.get("/api/v1/iss/telemetria").json()
    assert d["simulado"] is True and "NO es telemetría real" in d["fuente"]
    assert 0.205 < d["fraccion_o2"] < 0.213 and 100.5 < d["presion_kpa"] < 101.5
    assert telemetria_iss(1000.0) == telemetria_iss(1000.0)


@pytest.mark.skipif(shutil.which("node") is None, reason="requiere node")
def test_contrato_emergencias_con_el_normalizador_real_del_frontend(cliente, tmp_path) -> None:
    lista = cliente.get("/api/v1/emergencias").json()
    detalles = {e["id"]: cliente.get(f"/api/v1/emergencias/{e['id']}") for e in lista}
    if any(r.status_code != 200 for r in detalles.values()):
        pytest.skip("modelos aún cargando")
    # frontend/package.json declara "type": "module" y emergencias.js es UMD/CommonJS: se prueba una copia fuera de ese ámbito
    (tmp_path / "emergencias.js").write_text(JS.read_text(encoding="utf-8"), encoding="utf-8")
    (tmp_path / "reconstruccion.js").write_text("module.exports = {};\n", encoding="utf-8")  # las funciones probadas no la usan
    guion = ("const E=require(process.argv[1]);const d=JSON.parse(require('fs').readFileSync(0,'utf8'));"
             "const l=d.lista.map(E.normalizarEmergencia);if(l.some(x=>x===null))throw new Error('lista invalida');"
             "const o=E.ordenarEmergencias(l).map(x=>x.id);"
             "const det=Object.values(d.detalles).map(E.normalizarDetalle);"
             "console.log(JSON.stringify({orden:o,muestras:det.map(x=>x.muestras.length>0),acciones:det.map(x=>x.acciones.length>0),"
             "timeline:det.map(x=>x.timeline.length>0),ignis:det.map(x=>x.ignis!==null)}));")
    entrada = json.dumps({"lista": lista, "detalles": {k: v.json() for k, v in detalles.items()}})
    salida = subprocess.run(["node", "-e", guion, str(tmp_path / "emergencias.js")], input=entrada, capture_output=True, text=True)
    assert salida.returncode == 0, salida.stderr
    salida = salida.stdout
    r = json.loads(salida)
    assert r["orden"] == ["mir-1997", "iss-2015", "columbus-cool-flame"]
    assert all(r["muestras"]) and all(r["acciones"]) and all(r["timeline"]) and all(r["ignis"])


def test_contrato_si_insights(cliente) -> None:
    datos = cliente.get("/api/v1/si-insights").json()
    assert all(set(i) == {"tipo", "texto", "fuente", "verificacion"} for i in datos)  # sin consumidor JS: contrato = el pedido


@pytest.mark.parametrize("incidente", ["mir-1997", "iss-2015-falsa-alarma", "apollo1-1967", "saffire-2016-2024"])
def test_pdf_profesional_sin_500(cliente, incidente) -> None:
    import time
    for _ in range(40):
        r = cliente.get(f"/api/v1/incidentes/{incidente}/reporte_pdf")
        if r.status_code != 503:
            break
        time.sleep(1)
    assert r.status_code == 200 and r.content.startswith(b"%PDF")


@pytest.mark.skipif(shutil.which("pdftotext") is None, reason="requiere pdftotext")
def test_informe_contiene_encabezado_tabla_y_pie(cliente, tmp_path) -> None:
    import time
    for _ in range(40):
        r = cliente.get("/api/v1/incidentes/mir-1997/reporte_pdf")
        if r.status_code != 503:
            break
        time.sleep(1)
    assert r.status_code == 200
    ruta = tmp_path / "mir.pdf"
    ruta.write_bytes(r.content)
    texto = subprocess.run(["pdftotext", "-layout", str(ruta), "-"], capture_output=True, text=True, check=True).stdout
    for esperado in ("IGNIS", "INFORME FORENSE", "Tiempo de detección de IGNIS", "Tiempo de supresión", "Ventaja de IGNIS",
                     "Aislar sector y usar espuma", "Reporte generado automáticamente por IGNIS - Clasificación: Simulación"):
        assert esperado in texto, esperado


ESTADO_VIVO = {"escenario": "Escalada <test> & ₂", "t_s": 42.0, "indice_riesgo": 71.3, "nivel_riesgo": "CRITICO", "velocidad_propagacion_mm_s": 3.2,
               "probabilidad_propagacion": 0.83, "probabilidad_llama_fria": 0.1, "estado_llama_fria": "POSIBLE", "alarma_detector": True,
               "evento_activo": True, "condiciones": {"fraccion_o2": 0.25, "velocidad_flujo_cm_s": 10.0, "material": "sibal"},
               "acciones_sugeridas": ["Aislar sector"], "historial": [{"t_s": i, "indice_riesgo": min(100, i * 1.7)} for i in range(0, 43)]}


def test_pdf_live(cliente) -> None:
    r = cliente.post("/api/v1/incidentes/reporte_pdf_live", json=ESTADO_VIVO)
    assert r.status_code == 200 and r.content.startswith(b"%PDF") and r.headers["content-type"] == "application/pdf"
    assert cliente.post("/api/v1/incidentes/reporte_pdf_live", json={}).status_code == 200  # estado mínimo: todo opcional
    assert cliente.post("/api/v1/incidentes/reporte_pdf_live", json={"indice_riesgo": 500}).status_code == 422
    assert cliente.post("/api/v1/incidentes/reporte_pdf_live", json={"campo_raro": 1}).status_code == 422


@pytest.mark.skipif(shutil.which("pdftotext") is None, reason="requiere pdftotext")
def test_pdf_live_contenido(cliente, tmp_path) -> None:
    r = cliente.post("/api/v1/incidentes/reporte_pdf_live", json=ESTADO_VIVO)
    (tmp_path / "v.pdf").write_bytes(r.content)
    texto = subprocess.run(["pdftotext", "-layout", str(tmp_path / "v.pdf"), "-"], capture_output=True, text=True, check=True).stdout
    for esperado in ("CAJA NEGRA", "Índice de riesgo", "71 / 100 (CRITICO)", "ACTIVA", "Aislar sector", "Historial del índice de riesgo",
                     "Reporte generado automáticamente por IGNIS - Clasificación: Simulación"):
        assert esperado in texto, esperado
