"""Tests de la API HTTP y WebSocket (lifespan real, modelo pequeño)."""

from __future__ import annotations

import pytest

from api.websocket import DURACION_ESCENARIO_S, condiciones_escenario


def test_health(cliente) -> None:
    respuesta = cliente.get("/health")
    assert respuesta.status_code == 200
    cuerpo = respuesta.json()
    assert cuerpo["estado"] == "ok" and cuerpo["modelo_cargado"] is True
    assert "rf" in cuerpo["motores"]
    assert cuerpo["incidentes"] >= 4


def test_frontend_se_sirve_en_la_raiz(cliente) -> None:
    respuesta = cliente.get("/")
    assert respuesta.status_code == 200
    assert "text/html" in respuesta.headers["content-type"]
    assert "IGNIS" in respuesta.text


@pytest.mark.parametrize(
    "ruta",
    ["/css/main.css", "/css/hud.css", "/css/animations.css", "/js/main.js", "/js/anillos.js", "/js/ws.js"],
)
def test_frontend_sirve_recursos_estaticos(cliente, ruta: str) -> None:
    assert cliente.get(ruta).status_code == 200


def test_la_api_tiene_prioridad_sobre_el_frontend(cliente) -> None:
    assert cliente.get("/health").json()["estado"] == "ok"
    assert cliente.get("/ruta-inexistente").status_code == 404


def test_predict_valido(cliente, condiciones_validas: dict) -> None:
    respuesta = cliente.post("/api/v1/predict", json=condiciones_validas)
    assert respuesta.status_code == 200
    cuerpo = respuesta.json()
    assert 0 <= cuerpo["indice_riesgo"] <= 100
    assert cuerpo["nivel_riesgo"] in {"NOMINAL", "PRECAUCION", "ALERTA", "CRITICO"}
    assert cuerpo["origen_datos"] == "sintetico"


@pytest.mark.parametrize(
    ("campo", "valor"),
    [
        ("fraccion_o2", 5.0),
        ("regimen_flujo", "diagonal"),
        ("fraccion_o2", -0.1),
        ("velocidad_flujo_cm_s", -1.0),
        ("material", "plutonio"),
        ("presion_kpa", "alta"),
    ],
)
def test_predict_rechaza_entradas_invalidas(cliente, condiciones_validas: dict, campo, valor) -> None:
    condiciones_validas[campo] = valor
    assert cliente.post("/api/v1/predict", json=condiciones_validas).status_code == 422


def test_predict_rechaza_campos_extra(cliente, condiciones_validas: dict) -> None:
    condiciones_validas["campo_inyectado"] = "x"
    assert cliente.post("/api/v1/predict", json=condiciones_validas).status_code == 422


def test_predict_rechaza_campo_faltante(cliente, condiciones_validas: dict) -> None:
    del condiciones_validas["material"]
    assert cliente.post("/api/v1/predict", json=condiciones_validas).status_code == 422


def test_batch_conserva_orden(cliente, condiciones_validas: dict) -> None:
    lote = [{**condiciones_validas, "fraccion_o2": o2} for o2 in (0.17, 0.21, 0.35)]
    respuesta = cliente.post("/api/v1/predict/batch", json={"condiciones": lote})
    assert respuesta.status_code == 200
    indices = [r["indice_riesgo"] for r in respuesta.json()["resultados"]]
    assert indices == sorted(indices)


def test_batch_rechaza_vacio_y_exceso(cliente, condiciones_validas: dict) -> None:
    assert cliente.post("/api/v1/predict/batch", json={"condiciones": []}).status_code == 422
    exceso = {"condiciones": [condiciones_validas] * 501}
    assert cliente.post("/api/v1/predict/batch", json=exceso).status_code == 422


def test_info_modelo(cliente) -> None:
    cuerpo = cliente.get("/api/v1/model/info").json()
    assert cuerpo["origen_datos"] == "sintetico"
    assert cuerpo["metricas"]["auc_propagacion"] > 0.9


def test_cors_rechaza_origen_no_permitido(cliente) -> None:
    respuesta = cliente.get("/health", headers={"Origin": "http://sitio-malicioso.example"})
    assert "access-control-allow-origin" not in respuesta.headers


def test_ws_predict_responde_y_sobrevive_a_errores(cliente, condiciones_validas: dict) -> None:
    with cliente.websocket_connect("/ws/predict") as ws:
        ws.send_json({"basura": True})
        assert ws.receive_json()["tipo"] == "error"
        ws.send_json(condiciones_validas)
        mensaje = ws.receive_json()
        assert mensaje["tipo"] == "telemetria"
        assert 0 <= mensaje["evaluacion"]["indice_riesgo"] <= 100


def test_ws_predict_rechaza_mensaje_gigante(cliente) -> None:
    with cliente.websocket_connect("/ws/predict") as ws:
        ws.send_text("x" * 10_000)
        assert ws.receive_json()["tipo"] == "error"


def test_ws_demo_emite_telemetria(cliente) -> None:
    with cliente.websocket_connect("/ws/demo?ritmo_hz=10") as ws:
        primero = ws.receive_json()
        segundo = ws.receive_json()
    assert primero["origen"] == "escenario_demo"
    assert segundo["t_s"] > primero["t_s"]


def test_escenario_demo_cubre_llama_fria_y_es_ciclico() -> None:
    # Fase final (t>55 s): la llama caliente se apagó y queda en ventana de Cool Flame
    cierre = condiciones_escenario(57.0)
    assert 600 < cierre.temperatura_reaccion_k < 800
    assert condiciones_escenario(DURACION_ESCENARIO_S + 5.0) == condiciones_escenario(5.0)
