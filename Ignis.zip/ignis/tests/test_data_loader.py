"""Tests de carga, validación y generación de datos."""

from __future__ import annotations

import asyncio
from pathlib import Path

import numpy as np
import pytest

from src.data_loader import (
    ErrorDatos,
    cargar_csv,
    cargar_csv_async,
    cargar_dataset,
    validar_dataframe,
)
from src.dataset_sintetico import generar_dataset_sintetico, limite_o2_extincion


def test_sintetico_es_reproducible_con_misma_semilla() -> None:
    a = generar_dataset_sintetico(300, semilla=1)
    b = generar_dataset_sintetico(300, semilla=1)
    assert a.equals(b)


def test_sintetico_rechaza_tamano_invalido() -> None:
    with pytest.raises(ValueError):
        generar_dataset_sintetico(0)


def test_sintetico_contiene_ambas_clases() -> None:
    datos = generar_dataset_sintetico(2000, semilla=3)
    propaga = datos["velocidad_propagacion_mm_s"] > 0.05
    assert propaga.any() and (~propaga).any()


def test_limite_o2_es_minimo_en_flujo_pico() -> None:
    flujos = np.array([1.0, 10.0, 50.0])
    limite = limite_o2_extincion(flujos, np.full(3, 101.325), np.zeros(3))
    assert limite[1] < limite[0] and limite[1] < limite[2]


def test_validar_rechaza_columna_faltante() -> None:
    datos = generar_dataset_sintetico(50).drop(columns=["presion_kpa"])
    with pytest.raises(ErrorDatos, match="faltantes"):
        validar_dataframe(datos)


def test_validar_rechaza_fuera_de_rango() -> None:
    datos = generar_dataset_sintetico(50)
    datos.loc[0, "fraccion_o2"] = 1.5
    with pytest.raises(ErrorDatos, match="fuera de"):
        validar_dataframe(datos)


def test_validar_rechaza_nulos() -> None:
    datos = generar_dataset_sintetico(50)
    datos.loc[3, "temperatura_ambiente_k"] = np.nan
    with pytest.raises(ErrorDatos, match="nulos"):
        validar_dataframe(datos)


def test_validar_rechaza_material_desconocido() -> None:
    datos = generar_dataset_sintetico(50)
    datos.loc[0, "material"] = "plutonio"
    with pytest.raises(ErrorDatos, match="Materiales desconocidos"):
        validar_dataframe(datos)


def test_validar_rechaza_dataset_vacio() -> None:
    with pytest.raises(ErrorDatos, match="vacío"):
        validar_dataframe(generar_dataset_sintetico(10).iloc[0:0])


def test_cargar_csv_roundtrip(tmp_path: Path) -> None:
    original = generar_dataset_sintetico(120, semilla=5)
    ruta = tmp_path / "datos.csv"
    original.to_csv(ruta, index=False)
    cargado = cargar_csv(ruta)
    assert len(cargado) == 120
    assert np.allclose(cargado["fraccion_o2"], original["fraccion_o2"])


def test_cargar_csv_inexistente(tmp_path: Path) -> None:
    with pytest.raises(ErrorDatos, match="No existe"):
        cargar_csv(tmp_path / "no_existe.csv")


def test_cargar_csv_async(tmp_path: Path) -> None:
    ruta = tmp_path / "datos.csv"
    generar_dataset_sintetico(60).to_csv(ruta, index=False)
    assert len(asyncio.run(cargar_csv_async(ruta))) == 60


def test_cargar_dataset_etiqueta_origen(tmp_path: Path) -> None:
    _, origen_sintetico = cargar_dataset(None, 500, 1)
    ruta = tmp_path / "real.csv"
    generar_dataset_sintetico(80).to_csv(ruta, index=False)
    _, origen_real = cargar_dataset(ruta, 500, 1)
    assert (origen_sintetico, origen_real) == ("sintetico", "real")


def test_cargar_dataset_no_degrada_en_silencio_si_csv_falla(tmp_path: Path) -> None:
    with pytest.raises(ErrorDatos):
        cargar_dataset(tmp_path / "falta.csv", 500, 1)
