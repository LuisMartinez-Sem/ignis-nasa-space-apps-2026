"""Pruebas de scripts/descargar_psi.py con transporte simulado (sin red)."""

from __future__ import annotations

import hashlib
import io
import json
import zipfile
from pathlib import Path

import pytest

from scripts import descargar_psi as d


def _listado(items: list[tuple[str, bytes]]) -> bytes:
    filas = "".join(
        f'<Contents><Key>{k}</Key><Size>{len(v)}</Size><ETag>"{hashlib.md5(v).hexdigest()}"</ETag></Contents>'
        for k, v in items)
    return f'<ListBucketResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">{filas}</ListBucketResult>'.encode()


def _transporte(objetos: dict[str, bytes]) -> d.Transporte:
    def t(url: str) -> bytes:
        if "list-type=2" in url:
            return _listado(list(objetos.items()))
        for k, v in objetos.items():
            if url.endswith(k):
                return v
        raise d.ErrorDescargaPsi("404")
    return t


def test_url_solo_https_y_host_permitido() -> None:
    with pytest.raises(d.ErrorDescargaPsi):
        d.transporte_https("http://psi.nasa.gov/x")
    with pytest.raises(d.ErrorDescargaPsi):
        d.transporte_https("https://evil.example.com/x")


def test_lista_y_descarga_bucket_verifica_md5(tmp_path: Path) -> None:
    obj = {"DSI/a.csv": b"a,b\n1,2\n", "DSI/b.csv": b"x\n"}
    t = _transporte(obj)
    objetos = d.listar_bucket("DSI/", t)
    assert {o.clave for o in objetos} == set(obj)
    archivos = d.descargar_objetos(objetos, tmp_path, t)
    assert (tmp_path / "a.csv").read_bytes() == b"a,b\n1,2\n" and archivos[0].sha256 == hashlib.sha256(b"a,b\n1,2\n").hexdigest()


def test_md5_corrupto_y_tamano_truncado_se_rechazan() -> None:
    with pytest.raises(d.ErrorDescargaPsi, match="MD5"):
        d.verificar_integridad(b"hola", etag="0" * 32)
    with pytest.raises(d.ErrorDescargaPsi, match="Tamaño"):
        d.verificar_integridad(b"hola", tamano=10)
    d.verificar_integridad(b"hola", tamano=4, etag="123-4")  # ETag multiparte: no se compara MD5


def test_url_directa_verifica_sha256_y_registra_manifiesto(tmp_path: Path) -> None:
    contenido = b"o2,flow\n0.21,10\n"
    url = "https://psi.nasa.gov/datos/tabla.csv"
    huella = hashlib.sha256(contenido).hexdigest()
    archivos = d.descargar_url(url, tmp_path, sha256_esperado=huella, transporte=lambda _u: contenido)
    ruta = d.registrar_manifiesto(tmp_path, archivos)
    assert json.loads(ruta.read_text())[0]["sha256"] == huella
    with pytest.raises(d.ErrorDescargaPsi, match="SHA-256"):
        d.descargar_url(url, tmp_path, sha256_esperado="0" * 64, transporte=lambda _u: contenido)


def test_zip_se_extrae_y_bloquea_zip_slip(tmp_path: Path) -> None:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("carpeta/datos.csv", "a\n1\n")
    out = d.extraer_zip_seguro(buf.getvalue(), tmp_path, "mock")
    assert (tmp_path / "datos.csv").exists() and len(out) == 1
    malo = io.BytesIO()
    with zipfile.ZipFile(malo, "w") as z:
        z.writestr("../../escape.txt", "x")
    with pytest.raises(d.ErrorDescargaPsi, match="peligrosa"):
        d.extraer_zip_seguro(malo.getvalue(), tmp_path, "mock")
    assert not (tmp_path.parent / "escape.txt").exists()


def test_zip_invalido_y_nombre_seguro() -> None:
    with pytest.raises(d.ErrorDescargaPsi):
        d.extraer_zip_seguro(b"no es zip", Path("."), "mock")
    assert d.nombre_seguro("../../etc/pass wd.csv") == "pass_wd.csv"


def test_error_403_explica_ruta_manual() -> None:
    assert "registro" in d._explicar_http(403, "https://x")


def test_cli_manual_e_interactivo(tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]) -> None:
    monkeypatch.setattr("builtins.input", lambda _p="": "saffire-i")
    assert d.main(["--raiz", str(tmp_path)]) == 0
    assert "Regístrate" in capsys.readouterr().out
    t = _transporte({"DSI/a.csv": b"x\n"})
    assert d.main(["--experimento", "bass", "--raiz", str(tmp_path), "--prefijo", "DSI/"], transporte=t) == 0
    assert (tmp_path / "bass" / "a.csv").exists() and (tmp_path / "bass" / d.NOMBRE_MANIFIESTO).exists()
    assert d.main(["--lista", "--prefijo", "DSI/"], transporte=t) == 0


def test_cli_error_devuelve_codigo_2(tmp_path: Path) -> None:
    def falla(_u: str) -> bytes:
        raise d.ErrorDescargaPsi("HTTP 403")
    assert d.main(["--experimento", "bass", "--raiz", str(tmp_path), "--url", "https://psi.nasa.gov/x.zip"], transporte=falla) == 2
