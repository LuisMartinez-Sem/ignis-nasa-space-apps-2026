"""Estado de modelos, motores, explicabilidad, datos, WebSocket de sensores y cabeceras."""

from __future__ import annotations

import pytest


def test_estado_modelos(cliente) -> None:
    cuerpo = cliente.get("/api/v1/modelo/estado").json()
    assert cuerpo["componentes"]["rf"]["estado"] == "listo"
    assert cuerpo["detector_listo"] is True
    assert {"rf", "profundo"} <= set(cuerpo["motores"])


def test_predict_con_motor_profundo_y_explicacion(cliente, condiciones_validas: dict) -> None:
    respuesta = cliente.post("/api/v1/predict?motor=profundo&explicar=true", json=condiciones_validas)
    assert respuesta.status_code == 200
    cuerpo = respuesta.json()
    assert cuerpo["motor"] == "profundo"
    assert cuerpo["factores"], "debe explicar qué variable mueve el riesgo"


def test_motor_desconocido_da_409(cliente, condiciones_validas: dict) -> None:
    assert cliente.post("/api/v1/predict?motor=magia", json=condiciones_validas).status_code == 409
    assert cliente.post("/api/v1/predict?motor=NO-VALIDO!", json=condiciones_validas).status_code == 422


def test_explain_endpoint(cliente, condiciones_validas: dict) -> None:
    factores = cliente.post("/api/v1/explain", json=condiciones_validas).json()
    assert {f["variable"] for f in factores} >= {"fraccion_o2"}


def test_fuera_del_dominio_operativo_se_rechaza(cliente, condiciones_validas: dict) -> None:
    """O2 > 0,40 y presión fuera de [35, 101,325] kPa ya no son entradas válidas (422)."""
    for campo, valor in (("fraccion_o2", 1.0), ("fraccion_o2", 0.15), ("presion_kpa", 20.0), ("presion_kpa", 115.0)):
        malas = {**condiciones_validas, campo: valor}
        assert cliente.post("/api/v1/predict", json=malas).status_code == 422, (campo, valor)


def test_advertencia_cerca_del_borde_del_dominio(cliente, condiciones_validas: dict) -> None:
    alto_o2 = cliente.post("/api/v1/predict", json={**condiciones_validas, "fraccion_o2": 0.38}).json()
    assert any("O₂" in a for a in alto_o2["advertencias"])
    baja_p = cliente.post("/api/v1/predict", json={**condiciones_validas, "presion_kpa": 38.0}).json()
    assert any("Presión baja" in a for a in baja_p["advertencias"])
    nominal = cliente.post("/api/v1/predict", json=condiciones_validas).json()
    assert nominal["advertencias"] == []


def test_versiones_de_datos(cliente) -> None:
    assert cliente.get("/api/v1/datos/versiones").status_code == 200
    assert cliente.get("/api/v1/datos/versiones/..%2F..%2Fetc").status_code in (404, 422)
    assert cliente.get("/api/v1/datos/versiones/20990101-000000_deadbeef").status_code == 404


def test_cabeceras_de_seguridad(cliente) -> None:
    cabeceras = cliente.get("/health").headers
    assert "default-src 'self'" in cabeceras["content-security-policy"]
    assert cabeceras["x-content-type-options"] == "nosniff"
    assert cabeceras["x-request-id"]


def test_ws_sensores_emite_muestras_con_alarma(cliente) -> None:
    with cliente.websocket_connect("/ws/sensores?tipo=caliente&velocidad=20") as ws:
        mensajes = [ws.receive_json() for _ in range(160)]
    assert mensajes[0]["tipo"] == "sensores"
    assert set(mensajes[0]["canales"]) >= {"delta_t_k", "ir_rel", "co_ppm"}
    assert any(m["alarma_nueva"] for m in mensajes), "una llama caliente debe disparar la alarma"


def test_ws_sensores_rechaza_tipo_invalido(cliente) -> None:
    from starlette.websockets import WebSocketDisconnect

    with pytest.raises(WebSocketDisconnect):
        with cliente.websocket_connect("/ws/sensores?tipo=inventado") as ws:
            ws.receive_json()


def test_ws_respeta_el_tope_de_conexiones(cliente) -> None:
    limite = cliente.app.state.limite_ws
    original = limite.maximo
    limite.maximo = limite.activas  # sin cupo
    try:
        from starlette.websockets import WebSocketDisconnect

        with pytest.raises(WebSocketDisconnect):
            with cliente.websocket_connect("/ws/demo") as ws:
                ws.receive_json()
    finally:
        limite.maximo = original
