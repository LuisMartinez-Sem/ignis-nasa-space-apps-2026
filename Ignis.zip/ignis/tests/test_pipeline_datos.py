"""Pipeline de datos: perfilado, mapeo de unidades, versionado inmutable y anti path-traversal."""

from __future__ import annotations

import json

import pandas as pd
import pytest

from src.data_loader import ErrorDatos
from src.dataset_sintetico import generar_dataset_sintetico
from src.pipeline_datos import (
    generar_y_versionar_sintetico, ingestar_csv, listar_versiones, obtener_version, perfilar_dataset,
)


def test_perfil_reporta_huecos_de_cobertura() -> None:
    datos = generar_dataset_sintetico(800, 1)
    datos = datos[datos["material"] == "sibal"]  # solo un material: debe señalarse el hueco
    perfil = perfilar_dataset(datos)
    assert perfil.n_filas == len(datos)
    assert perfil.huecos_de_cobertura


def test_versionado_es_idempotente(tmp_path) -> None:
    v1 = generar_y_versionar_sintetico(tmp_path, 600, 5)
    v2 = generar_y_versionar_sintetico(tmp_path, 600, 5)
    assert v1.id == v2.id and len(listar_versiones(tmp_path)) == 1
    assert (tmp_path / "versiones" / v1.id / "datos.csv").is_file()


def test_ingesta_con_mapeo_convierte_unidades(tmp_path) -> None:
    base = generar_dataset_sintetico(600, 2).head(200)
    crudo = pd.DataFrame({
        "o2_pct": base["fraccion_o2"] * 100, "flujo_m_s": base["velocidad_flujo_cm_s"] / 100,
        "p_psi": base["presion_kpa"] / 6.894757, "t_k": base["temperatura_ambiente_k"],
        "esp": base["espesor_combustible_mm"], "mat": base["material"],
        "v": base["velocidad_propagacion_mm_s"],
    })
    csv = tmp_path / "psi.csv"
    crudo.to_csv(csv, index=False)
    mapeo = tmp_path / "mapeo.json"
    mapeo.write_text(json.dumps({
        "columnas": {
            "fraccion_o2": {"columna": "o2_pct", "unidad": "porcentaje"},
            "velocidad_flujo_cm_s": {"columna": "flujo_m_s", "unidad": "m_s"},
            "presion_kpa": {"columna": "p_psi", "unidad": "psi"},
            "temperatura_ambiente_k": {"columna": "t_k", "unidad": "k"},
            "espesor_combustible_mm": {"columna": "esp", "unidad": "mm"},
            "velocidad_propagacion_mm_s": {"columna": "v", "unidad": "mm_s"},
        },
        "material": "mat", "regimen_fijo": "opuesto",
    }), encoding="utf-8")
    version = ingestar_csv(csv, tmp_path / "datos", "real", mapeo)
    assert version.origen == "real" and version.n_filas == 200
    guardado = pd.read_csv(tmp_path / "datos" / "versiones" / version.id / "datos.csv")
    assert guardado["fraccion_o2"].between(0.1, 1.0).all()  # % -> fracción
    assert guardado["presion_kpa"].between(20, 200).all()  # psi -> kPa


def test_version_con_id_malicioso_se_rechaza(tmp_path) -> None:
    with pytest.raises(ErrorDatos):
        obtener_version(tmp_path, "../../etc/passwd")


def test_csv_inexistente(tmp_path) -> None:
    with pytest.raises(ErrorDatos):
        ingestar_csv(tmp_path / "nada.csv", tmp_path, "real")
