"""Línea del pitch, línea base y comparativa RF vs. profundo (con datos 'reales' simulados)."""

from __future__ import annotations

from pathlib import Path

import pytest

from src.config import Configuracion
from src.dataset_sintetico import generar_dataset_sintetico
from src.ingesta_psi import ingestar_psi
from src.model import ModeloPropagacion
from src.pipeline_datos import listar_versiones
from src import reporte_psi as r
from tests.test_ingesta_psi import arbol_psi  # noqa: F401  (fixture)


@pytest.fixture
def config(tmp_path: Path) -> Configuracion:
    datos = tmp_path / "datos"
    (datos / "processed").mkdir(parents=True)
    cfg = Configuracion(directorio_datos=datos, ruta_modelo=datos / "processed" / "rf.joblib",
                        n_arboles=20, epocas_profundo=5, n_miembros_ensemble=2)
    rf = ModeloPropagacion(20, 1)
    rf.entrenar(generar_dataset_sintetico(600, 1), "sintetico")
    rf.guardar(cfg.ruta_modelo)
    return cfg


def test_linea_sin_datos_no_inventa_cifras() -> None:
    linea = r.linea_pitch(None, 77.0, None)
    assert linea == ("Modelo entrenado con 0 filas de Saffire, 0 de FLEX, 0 de BASS. "
                     "Recalibración en curso. Error Saffire-I reducido de 77% a [?]%.")


def test_linea_base_se_fija_una_vez(config: Configuracion) -> None:
    a = r.fijar_linea_base(config)
    b = r.fijar_linea_base(config)
    assert a.error_abs_medio_pct == b.error_abs_medio_pct and a.n_con_medicion == 2


def test_actualizar_pitch_es_idempotente(tmp_path: Path) -> None:
    p = tmp_path / "pitch.md"
    p.write_text("# Pitch\ntexto\n", encoding="utf-8")
    assert r.actualizar_pitch(p, "linea uno") and not r.actualizar_pitch(p, "linea uno")
    assert r.actualizar_pitch(p, "linea dos")
    assert p.read_text().count(r.MARCA_INI) == 1 and "linea dos" in p.read_text() and "linea uno" not in p.read_text()


def test_comparativa_exige_datos_reales(config: Configuracion) -> None:
    from src.pipeline_datos import generar_y_versionar_sintetico
    v = generar_y_versionar_sintetico(config.directorio_datos, 300, 1)
    with pytest.raises(r.ErrorReporte, match="reales"):
        r.generar_comparativa(config, v.id)


def test_comparativa_y_linea_con_ingesta_simulada(config: Configuracion, arbol_psi: Path, tmp_path: Path) -> None:  # noqa: F811
    res = ingestar_psi(arbol_psi, config.directorio_datos)
    assert res.version is not None
    comp = r.generar_comparativa(config, res.version.id)
    assert {m.nombre for m in comp.motores} >= {"rf"} and comp.ganador_mae in {m.nombre for m in comp.motores}
    assert all(m.error_saffire_i_pct is not None for m in comp.motores) and comp.advertencias
    linea = r.linea_pitch(res.reporte, 100.0, comp.motores[0].error_saffire_i_pct)
    assert "con 60 filas de Saffire, 25 de FLEX, 70 de BASS" in linea  # bass 40 + bass-ii 30
    assert "# Comparativa" in r.a_markdown(comp, None)
