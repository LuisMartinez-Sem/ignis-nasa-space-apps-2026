"""CSV de prueba: entra, se refleja en todo el catálogo, se marca como PRUEBA y se puede quitar sin dejar rastro."""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from src import importacion_prueba as prueba
from src import investigaciones as inv


@pytest.fixture()
def catalogo_tmp(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Catálogo temporal: los tests jamás escriben en data/."""
    destino = tmp_path / "investigaciones.json"
    shutil.copy(inv.RUTA_CATALOGO, destino)
    monkeypatch.setattr(inv, "RUTA_CATALOGO", destino)
    inv.limpiar_cache()
    yield destino
    inv.limpiar_cache()


def test_importar_crea_fichas_marcadas_y_se_ven_en_el_catalogo(catalogo_tmp: Path) -> None:
    antes = len(inv.cargar_catalogo())
    informe = prueba.importar(prueba.PLANTILLA_CSV)
    assert informe.estado == "ok" and informe.filas == 6
    assert set(informe.investigaciones_nuevas) == {"demo-luna-a", "demo-marte-b", "demo-iss-c"}
    lista, estado = inv.cargar_catalogo_con_estado()
    assert len(lista) == antes + 3
    assert set(estado.prueba) == set(informe.investigaciones_nuevas)
    ficha = inv.obtener("demo-luna-a")
    assert ficha is not None and "PRUEBA" in ficha.fuente and "[PRUEBA]" in ficha.nombre_completo
    assert (ficha.o2_pct.min, ficha.o2_pct.max) == (30.0, 40.0)
    assert (ficha.presion_kpa.min, ficha.presion_kpa.max) == (55.0, 70.0)
    assert ficha.gravedad == "desconocida" and ficha.datos_en_psi is None  # no se inventa nada que el CSV no diga


def test_la_huella_cambia_al_importar_y_vuelve_al_quitar(catalogo_tmp: Path) -> None:
    h0 = inv.cargar_catalogo_con_estado()[1].huella
    prueba.importar(prueba.PLANTILLA_CSV)
    assert inv.cargar_catalogo_con_estado()[1].huella != h0
    assert prueba.quitar() is True
    estado = inv.cargar_catalogo_con_estado()[1]
    assert estado.huella == h0 and estado.prueba == []
    assert prueba.quitar() is False  # idempotente


def test_no_toca_el_catalogo_real_ni_la_ingesta(catalogo_tmp: Path) -> None:
    antes = catalogo_tmp.read_bytes()
    prueba.importar(prueba.PLANTILLA_CSV)
    assert catalogo_tmp.read_bytes() == antes
    assert not catalogo_tmp.with_name("investigaciones_ingestadas.json").exists()


@pytest.mark.parametrize("contenido", ["", "   \n", "solo,una,fila\n", "a,b\n1,2\n"])
def test_csv_inutilizable_da_error_claro_y_no_escribe(catalogo_tmp: Path, contenido: str) -> None:
    with pytest.raises(prueba.ErrorImportacion):
        prueba.importar(contenido)
    assert not prueba.ruta_prueba().exists()


def test_unidad_ambigua_se_omite_sin_adivinar(catalogo_tmp: Path) -> None:
    informe = prueba.importar("Investigation,O2,Pressure\nDemo-X,0.3,70\n")
    # «Pressure» sin unidad no se interpreta; «O2» entre 0 y 1 sin %/fracción es ambiguo
    assert informe.omitidas
    ficha = inv.obtener("demo-x")
    assert ficha is None or ficha.presion_kpa is None


def test_unidades_se_convierten_a_kpa_y_porcentaje(catalogo_tmp: Path) -> None:
    prueba.importar("Investigation,O2 fraction,Pressure (psi)\nDemo-U,0.30,10.2\n")
    f = inv.obtener("demo-u")
    assert f is not None and f.o2_pct.min == 30.0 and f.presion_kpa is not None and abs(f.presion_kpa.min - 70.328) < 0.01


def test_api_ciclo_completo(catalogo_tmp: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from api.main import app

    with TestClient(app) as c:
        _ciclo(c)


def _ciclo(c: TestClient) -> None:
    r = c.get("/api/v1/investigaciones/prueba/plantilla")
    assert r.status_code == 200 and "Demo-Luna-A" in r.text
    h0 = c.get("/api/v1/investigaciones/estado").json()["huella"]
    r = c.post("/api/v1/investigaciones/prueba", json={"contenido": r.text})
    assert r.status_code == 200 and r.json()["estado"] == "ok"
    e = c.get("/api/v1/investigaciones/estado").json()
    assert e["huella"] != h0 and len(e["prueba"]) == 3
    rk = c.get("/api/v1/investigaciones/ranking?entorno=luna&limite=100").json()
    assert any(x["investigacion"]["id"] == "demo-luna-a" for x in rk["resultados"])
    par = c.get("/api/v1/investigaciones/pareto?entorno=luna").json()
    assert any(p["id"] == "demo-luna-a" and p["provisional"] for p in par["puntos"])
    mapa = c.get("/api/v1/mapa-riesgo").json()
    assert any(x["id"] == "demo-luna-a" for x in mapa["cobertura"])
    assert c.delete("/api/v1/investigaciones/prueba").json() == {"quitado": True}
    assert c.get("/api/v1/investigaciones/estado").json()["huella"] == h0


def test_api_rechaza_csv_malo_y_produccion(catalogo_tmp: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from api.main import app
    from src.config import obtener_configuracion

    c = TestClient(app)
    assert c.post("/api/v1/investigaciones/prueba", json={"contenido": "a,b\n1,2\n"}).status_code == 422
    assert c.post("/api/v1/investigaciones/prueba", json={"contenido": ""}).status_code == 422
    cfg = obtener_configuracion()
    monkeypatch.setattr(cfg, "entorno", "produccion")
    assert c.post("/api/v1/investigaciones/prueba", json={"contenido": prueba.PLANTILLA_CSV}).status_code == 403
