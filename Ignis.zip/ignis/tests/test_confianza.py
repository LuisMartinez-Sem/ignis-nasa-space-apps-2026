"""Informe de confianza, clasificador de palabras clave e incidentes propios."""

from __future__ import annotations

import pytest

from src.clasificador import clasificar
from src.incidentes_historicos import CatalogoIncidentes, ErrorIncidente


def test_clasificador_sugiere_solo_con_pistas() -> None:
    r = clasificar("Cotton fabric flammability", "cotton sheet", "Glovebox", "limites de inflamabilidad")
    assert r["combustible_tipos"] == ["solido"] and r["familia"] == "solidos" and "prevencion" in r["areas_seguridad"]
    gota = clasificar("n-heptane droplet", "", "MDCA", "extinguish with water mist")
    assert gota["combustible_tipos"] == ["gota"] and "supresion" in gota["areas_seguridad"]
    vacio = clasificar("Mystery", "", "", "")
    assert vacio["combustible_tipos"] == [] and vacio["areas_seguridad"] == [] and vacio["familia"] == "otra"


def test_clasificador_no_confunde_palabras() -> None:
    assert clasificar("gasto energetico")["combustible_tipos"] == []


def test_informe_confianza_endpoint(cliente) -> None:
    r = cliente.get("/api/v1/investigaciones/saffire-i/confianza?entorno=luna")
    assert r.status_code == 200
    d = r.json()
    producto = d["evidencia"] * d["factores"][0]["valor"] * d["factores"][1]["valor"] * d["factores"][2]["valor"]
    assert d["confianza"] == pytest.approx(producto, abs=0.06)
    assert d["indice_p10"] <= d["indice"] <= d["indice_p90"]
    assert sum(d["resumen_entradas"].values()) == 6
    assert cliente.get("/api/v1/investigaciones/no-existe/confianza").status_code == 404
    assert cliente.get("/api/v1/investigaciones/saffire-i/confianza?entorno=marte").status_code == 200
    pdf = cliente.get("/api/v1/investigaciones/saffire-i/confianza.pdf")
    assert pdf.status_code == 200 and pdf.content[:4] == b"%PDF"


def _registro(identificador: str) -> dict:
    return {
        "id": identificador, "nombre": "Prueba", "fecha": "sin fecha", "lugar": "Lab", "regimen_gravedad": "microgravedad", "tipo": "precondicion",
        "resumen": "Incidente de prueba", "modelo_aplicable": True,
        "condiciones_base": {"fraccion_o2": 0.3, "velocidad_flujo_cm_s": 10.0, "presion_kpa": 70.0, "temperatura_ambiente_k": 295.0,
                             "espesor_combustible_mm": 0.3, "material": "sibal", "regimen_flujo": "opuesto"},
        "fuentes": [{"id": 1, "titulo": "Informe", "organizacion": "Usuario", "fiabilidad": "baja"}],
    }


def test_incidentes_propios_se_agregan_y_quitan(tmp_path) -> None:
    cat = CatalogoIncidentes(tmp_path / "base")
    inc = cat.agregar_propio(_registro("propio-prueba-123"))
    assert inc.propio and [r.id for r in cat.listar() if r.propio] == ["propio-prueba-123"]
    with pytest.raises(ErrorIncidente):
        cat.agregar_propio(_registro("propio-prueba-123"))  # repetido
    with pytest.raises(ErrorIncidente):
        cat.agregar_propio(_registro("mir-1997x"))  # sin prefijo propio-
    with pytest.raises(ErrorIncidente):
        cat.quitar_propio("mir-1997")  # los base no se quitan
    cat.quitar_propio("propio-prueba-123")
    assert cat.listar() == []
