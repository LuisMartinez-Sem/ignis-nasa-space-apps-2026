"""Pruebas del puente Arduino → API (sin hardware: puerto y red simulados)."""

from __future__ import annotations

import urllib.error

import pytest
from fastapi.testclient import TestClient

import hardware_bridge as hb
from api.main import app
from src.domain import CondicionesAmbiente

AJUSTES = {"o2": 0.21, "presion_kpa": 101.3, "flujo_cm_s": 10.0, "temp_ambiente_k": 295.0, "espesor_mm": 0.2, "material": "sibal", "regimen": "opuesto"}


@pytest.mark.parametrize("linea,esperado", [(b"25.3\r\n", 25.3), ("T=412,5", 412.5), (b"Temp: -3.0 C", -3.0), (b"1e2", 100.0),
                                            (b"", None), (b"hola", None), (b"\xff\xfe", None), ("nan", None),
                                            ("Humedad: 45.00 %  Temperatura: 24.00 *C", 24.0), ("Humidity: 45.0%  Temperature: 23.5\xb0C", 23.5),
                                            ("T=24,5 H=40", 24.5), ("45.0,24.0", None), ("Failed to read from DHT sensor!", None)])
def test_parsear_linea(linea, esperado) -> None:
    assert hb.parsear_linea(linea) == esperado


def test_conversion_de_unidades() -> None:
    assert hb.a_kelvin(25.0, "c") == pytest.approx(298.15)
    assert hb.a_kelvin(300.0, "k") == 300.0
    assert hb.a_kelvin(77.0, "f") == pytest.approx(298.15)
    with pytest.raises(ValueError):
        hb.a_kelvin(1.0, "x")


def test_el_json_es_valido_para_la_api() -> None:
    cond = hb.construir_condiciones(500.0, campo="reaccion", **AJUSTES)
    modelo = CondicionesAmbiente.model_validate(cond)  # Pydantic de la API
    assert modelo.fraccion_o2 == 0.21 and modelo.presion_kpa == 101.3 and modelo.temperatura_reaccion_k == 500.0
    amb = CondicionesAmbiente.model_validate(hb.construir_condiciones(300.0, campo="ambiente"))
    assert amb.temperatura_ambiente_k == 300.0 and amb.temperatura_reaccion_k is None


def test_fuera_de_rango_se_rechaza_con_mensaje_claro() -> None:
    with pytest.raises(ValueError, match="fuera del rango"):
        hb.construir_condiciones(100.0)  # 100 K: casi seguro una unidad equivocada
    with pytest.raises(ValueError):
        hb.construir_condiciones(500.0, campo="otro")


def test_bucle_con_la_api_real_en_proceso() -> None:
    with TestClient(app) as c:
        def enviador(url: str, cond: dict) -> dict:
            r = c.post("/api/v1/predict", json=cond)
            if r.status_code != 200:
                raise ValueError(f"HTTP {r.status_code}")
            return r.json()

        salida: list[str] = []
        n = hb.procesar([b"basura\n", b"25.0\n", b"650.0\n", b"-500\n", b"700,0\n"], url="http://x", unidad="c", campo="reaccion", intervalo_s=0.0,
                        ajustes=AJUSTES, enviador=enviador, salida=salida.append)
    texto = "\n".join(salida)
    assert n == 3 and texto.count("índice=") == 3  # 25 °C, 650 °C y 700 °C; "basura" se ignora
    assert "[ERROR]" in texto and "fuera del rango" in texto  # -500 °C no válido: informado, sin romper el bucle


def test_un_fallo_de_red_no_detiene_el_puente() -> None:
    llamadas: list[int] = []

    def enviador(url: str, cond: dict) -> dict:
        llamadas.append(1)
        if len(llamadas) == 1:
            raise urllib.error.URLError("sin conexión")
        return {"indice_riesgo": 12.0, "nivel_riesgo": "bajo"}

    salida: list[str] = []
    n = hb.procesar([b"400\n", b"410\n"], url="http://x", unidad="k", campo="reaccion", intervalo_s=0.0, ajustes=AJUSTES, enviador=enviador, salida=salida.append)
    assert n == 1 and "[ERROR]" in salida[0] and "índice=12.0" in salida[1]


def test_el_intervalo_limita_la_frecuencia() -> None:
    reloj = {"t": 0.0}

    def lineas():  # lecturas a 0.0, 0.2, 0.6 y 0.7 s: con intervalo de 0.5 s solo pasan la 1.ª y la 3.ª
        for t in (0.0, 0.2, 0.6, 0.7):
            reloj["t"] = t
            yield b"400\n"

    n = hb.procesar(lineas(), url="http://x", unidad="k", campo="reaccion", intervalo_s=0.5, ajustes=AJUSTES,
                    enviador=lambda u, c: {"indice_riesgo": 1}, reloj=lambda: reloj["t"], salida=lambda s: None)
    assert n == 2


def test_url_no_http_se_rechaza() -> None:
    with pytest.raises(ValueError, match="http"):
        hb.enviar("file:///etc/passwd", {})


def test_columna_explicita_resuelve_lineas_ambiguas() -> None:
    assert hb.parsear_linea("45.0,24.0", columna=2) == 24.0
    assert hb.parsear_linea("45.0,24.0", columna=3) is None


def test_basura_serial_no_rompe_ni_inunda() -> None:
    salida: list[str] = []
    basura = [b"\x00\xff\xfe\x80", b"\xde\xad\xbe\xef", b"@@@@", b""] * 60 + [b"Temperatura: 24.5 C\n"]
    n = hb.procesar(basura, url="http://x", unidad="c", campo="ambiente", intervalo_s=0.0, ajustes=AJUSTES,
                    enviador=lambda u, c: {"indice_riesgo": 5.0, "nivel_riesgo": "BAJO"}, salida=salida.append)
    assert n == 1
    assert sum("[AVISO]" in x for x in salida) <= 3  # avisa pocas veces, no una por línea


def test_json_del_dht11_lo_acepta_el_endpoint_real() -> None:
    """Esquema Pydantic de la API: el JSON exacto que envía el puente con un DHT11 (aire, °C) y con un termopar."""
    with TestClient(app) as c:
        for campo, lectura in (("ambiente", 24.0), ("reaccion", 450.0)):
            cond = hb.construir_condiciones(hb.a_kelvin(lectura, "c"), campo=campo, **AJUSTES)
            r = c.post("/api/v1/predict", json=cond)
            assert r.status_code == 200, r.text
            assert 0 <= r.json()["indice_riesgo"] <= 100
        # DHT11 en su rango completo (0-50 °C) siempre válido
        for grados in (0.0, 50.0):
            assert c.post("/api/v1/predict", json=hb.construir_condiciones(hb.a_kelvin(grados, "c"), campo="ambiente", **AJUSTES)).status_code == 200


def test_desconexion_a_mitad_de_lectura_reconecta(monkeypatch: pytest.MonkeyPatch) -> None:
    """COM4 se desconecta (SerialException/PermissionError) y vuelve: el generador sigue entregando líneas."""
    import sys
    import types

    class ErrorSerial(Exception):
        pass

    guiones = [[b"24.0\n", ErrorSerial("ClearCommError: dispositivo desconectado")], [PermissionError("Acceso denegado")], [b"25.0\n", b"26.0\n"]]
    intentos = {"n": 0}

    class FalsoPuerto:
        def __init__(self, puerto: str, baudios: int, timeout: float = 1) -> None:
            self.cola = list(guiones[intentos["n"]])
            intentos["n"] += 1

        def __enter__(self) -> "FalsoPuerto":
            return self

        def __exit__(self, *a: object) -> None:
            return None

        def reset_input_buffer(self) -> None:
            return None

        def readline(self) -> bytes:
            if not self.cola:
                raise KeyboardInterrupt  # fin de la prueba
            x = self.cola.pop(0)
            if isinstance(x, Exception):
                raise x
            return x

    falso = types.SimpleNamespace(Serial=FalsoPuerto, SerialException=ErrorSerial)
    monkeypatch.setitem(sys.modules, "serial", falso)
    monkeypatch.setattr(hb.time, "sleep", lambda s: None)
    recibidas: list[bytes] = []
    with pytest.raises(KeyboardInterrupt):
        for linea in hb.lineas_serial("COM4", 9600, reintento_s=0):
            recibidas.append(linea)
    assert recibidas == [b"24.0\n", b"25.0\n", b"26.0\n"] and intentos["n"] == 3
