"""Puente Arduino → IGNIS: lee temperaturas por el puerto serial y consulta `POST /api/v1/predict`.

Cada línea con un número (p. ej. `25.3`, `T=412,5`, `Temp: 25.3 C`) se toma como la temperatura medida por el sensor,
se convierte a kelvin y se envía a la API junto con el resto de condiciones (O₂ 0.21, 101.3 kPa, ...). Se imprime
la respuesta del servidor. Si el sensor mide el aire (DHT11, por defecto) se usa `--campo ambiente`; solo un termopar
sobre la llama justifica `--campo reaccion`. Un DHT11 NO detecta llamas (mide 0-50 °C de aire y humedad).

IMPORTANTE: la temperatura es la única medición real; O₂, presión, flujo, espesor y material son los VALORES FIJOS
que se declaran por argumentos (no los mide el Arduino). El resultado del modelo (sintético, calibrado, no validado)
es un índice de riesgo orientativo, no una alarma certificada.

Uso:
    pip install -r requirements-hardware.txt
    python hardware_bridge.py --puerto COM4                  # Windows
    python hardware_bridge.py --puerto /dev/ttyACM0 --unidad c --campo ambiente
    echo 412.5 | python hardware_bridge.py --stdin          # prueba sin Arduino
"""

from __future__ import annotations

import argparse
import json
import logging
import math
import re
import sys
import time
import urllib.error
import urllib.request
from collections.abc import Callable, Iterable, Iterator
from typing import Any
from urllib.parse import urlparse

logger = logging.getLogger("hardware_bridge")

URL_POR_DEFECTO = "http://127.0.0.1:8000/api/v1/predict"
BAUDIOS_POR_DEFECTO = 9600
PUERTO_POR_DEFECTO = "COM3"
# Rangos físicos que acepta la API (src/domain.py::RANGOS) en kelvin; se validan aquí para dar un mensaje claro.
RANGO_K = {"reaccion": (250.0, 2000.0), "ambiente": (250.0, 400.0)}
UMBRAL_SIN_LLAMA_K = 350.0  # por debajo, un termopar «de reacción» está midiendo aire, no llama
_NUMERO = re.compile(r"[-+]?\d+(?:[.,]\d+)?(?:[eE][-+]?\d+)?")


_ETIQUETA_TEMP = re.compile(r"(?:temp(?:eratura|erature)?|t)\s*[:=]?\s*(" + _NUMERO.pattern + ")", re.IGNORECASE)


def parsear_linea(linea: str | bytes, columna: int | None = None) -> float | None:
    """Temperatura de una línea del Arduino; None si no hay una lectura inequívoca.

    Reglas (en orden), pensadas para sketches típicos del DHT11 que imprimen también la humedad:
      1. `columna=N` (1 = primera): se toma el N-ésimo número de la línea.
      2. Si hay una etiqueta de temperatura (`Temperatura: 24.0`, `Temp=24`, `T=24`), se toma el número que la sigue.
      3. Si la línea tiene un único número, es la temperatura.
      4. Con varios números sin etiqueta (p. ej. `45.0,24.0`) es AMBIGUO: se descarta (use `--columna`).
    Acepta coma decimal; ignora `nan`, `inf` y bytes inválidos.
    """
    texto = linea.decode("utf-8", errors="ignore") if isinstance(linea, bytes) else linea
    if re.search(r"fail|error|nan|inf", texto, re.IGNORECASE) and not _NUMERO.search(texto):
        return None
    numeros = _NUMERO.findall(texto)
    if columna is not None:
        elegido = numeros[columna - 1] if 0 < columna <= len(numeros) else None
    elif (m := _ETIQUETA_TEMP.search(texto)) is not None:
        elegido = m.group(1)
    elif len(numeros) == 1:
        elegido = numeros[0]
    else:
        elegido = None
    if elegido is None:
        return None
    try:
        valor = float(elegido.replace(",", "."))
    except ValueError:
        return None
    return valor if math.isfinite(valor) else None


def a_kelvin(valor: float, unidad: str) -> float:
    """Convierte la lectura a kelvin (`unidad`: 'c' Celsius, 'k' kelvin, 'f' Fahrenheit)."""
    u = unidad.lower()
    if u == "k":
        return valor
    if u == "c":
        return valor + 273.15
    if u == "f":
        return (valor - 32.0) * 5.0 / 9.0 + 273.15
    raise ValueError(f"Unidad desconocida: {unidad!r} (use c, k o f)")


def construir_condiciones(temperatura_k: float, *, campo: str = "ambiente", o2: float = 0.21, presion_kpa: float = 101.3,
                          flujo_cm_s: float = 10.0, temp_ambiente_k: float = 295.0, espesor_mm: float = 0.2,
                          material: str = "sibal", regimen: str = "opuesto") -> dict[str, Any]:
    """JSON válido para `POST /api/v1/predict` con la temperatura medida en el campo indicado.

    Raises:
        ValueError: campo desconocido o temperatura fuera del rango físico que acepta la API.
    """
    if campo not in RANGO_K:
        raise ValueError(f"Campo desconocido: {campo!r} (use reaccion o ambiente)")
    lo, hi = RANGO_K[campo]
    if not lo <= temperatura_k <= hi:
        raise ValueError(f"{temperatura_k:.1f} K fuera del rango aceptado para '{campo}' ({lo:g}-{hi:g} K); ¿unidad o sensor mal configurados?")
    cond: dict[str, Any] = {"fraccion_o2": o2, "velocidad_flujo_cm_s": flujo_cm_s, "presion_kpa": presion_kpa,
                            "temperatura_ambiente_k": temp_ambiente_k, "espesor_combustible_mm": espesor_mm, "material": material,
                            "regimen_flujo": regimen}
    if campo == "ambiente":
        cond["temperatura_ambiente_k"] = round(temperatura_k, 2)
    else:
        cond["temperatura_reaccion_k"] = round(temperatura_k, 2)
    return cond


def enviar(url: str, condiciones: dict[str, Any], timeout_s: float = 5.0) -> dict[str, Any]:
    """POST JSON a la API y devuelve la respuesta decodificada.

    Raises:
        ValueError: URL que no es http(s), o respuesta de error de la API (el mensaje incluye el detalle).
        urllib.error.URLError: sin conexión con el servidor.
    """
    if urlparse(url).scheme not in {"http", "https"}:
        raise ValueError("La URL debe empezar por http:// o https://")
    peticion = urllib.request.Request(url, data=json.dumps(condiciones).encode(), headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(peticion, timeout=timeout_s) as r:  # noqa: S310 (esquema validado arriba)
            return json.loads(r.read())
    except urllib.error.HTTPError as error:
        detalle = error.read().decode("utf-8", errors="ignore")[:300]
        raise ValueError(f"La API respondió HTTP {error.code}: {detalle}") from error


def url_pulso(url_predict: str) -> str:
    """URL de `/api/v1/hardware/ping` en el mismo servidor que `url_predict`."""
    partes = urlparse(url_predict)
    return f"{partes.scheme}://{partes.netloc}/api/v1/hardware/ping"


def lineas_serial(puerto: str, baudios: int, reintento_s: float = 2.0, silencio_s: float = 10.0) -> Iterator[bytes]:
    """Líneas del puerto serial; ante desconexión, puerto ocupado o cable suelto reintenta hasta Ctrl+C.

    Avisa si el Arduino lleva `silencio_s` segundos sin enviar nada (sketch equivocado, baudios distintos o sensor colgado).
    """
    try:
        import serial  # pyserial: dependencia solo del puente (requirements-hardware.txt)
    except ImportError as error:
        raise SystemExit("Falta pyserial: py -m pip install -r requirements-hardware.txt") from error
    primera = True
    while True:
        try:
            with serial.Serial(puerto, baudios, timeout=1) as conexion:
                logger.info("%s a %d baudios", "Conectado a " + puerto if primera else "RECONECTADO a " + puerto, baudios)
                primera = False
                time.sleep(2.0)  # un Arduino se reinicia al abrir el puerto; se espera a que arranque
                conexion.reset_input_buffer()
                ultimo_dato = time.monotonic()
                avisado = False
                while True:
                    linea = conexion.readline()
                    if linea:
                        ultimo_dato, avisado = time.monotonic(), False
                        yield linea
                    elif not avisado and time.monotonic() - ultimo_dato > silencio_s:
                        logger.warning("Sin datos de %s hace %.0f s: ¿baudios distintos (%d), sketch equivocado o Monitor Serie abierto?", puerto, silencio_s, baudios)
                        avisado = True
        except (serial.SerialException, OSError) as error:  # cable desconectado, puerto ocupado ("Acceso denegado") o inexistente
            logger.error("Puerto %s no disponible (%s); reintento en %.0f s", puerto, error, reintento_s)
            time.sleep(reintento_s)


def procesar(lineas: Iterable[bytes | str], *, url: str, unidad: str, campo: str, intervalo_s: float, ajustes: dict[str, Any],
             enviador: Callable[[str, dict[str, Any]], dict[str, Any]] = enviar, reloj: Callable[[], float] = time.monotonic,
             detallado: bool = False, salida: Callable[[str], None] = print, columna: int | None = None,
             pulsador: Callable[[dict[str, Any] | None], object] | None = None) -> int:
    """Bucle principal: parsea, valida, consulta la API e imprime. Devuelve cuántas respuestas recibió.

    Una línea ilegible, una lectura fuera de rango o un fallo de red se informan y NO detienen el puente.
    `intervalo_s` limita la frecuencia de consultas (un Arduino puede enviar decenas de lecturas por segundo).
    """
    ultimo = -math.inf
    respuestas = descartadas = 0
    for linea in lineas:
        valor = parsear_linea(linea, columna)
        if valor is None:
            descartadas += 1
            logger.debug("Línea ignorada: %r", linea)
            if descartadas in (1, 20) or descartadas % 200 == 0:  # no inunda la consola si el Arduino envía solo basura
                salida(f"[AVISO] {descartadas} línea(s) sin temperatura utilizable (última: {linea!r:.80}); ¿baudios o formato del sketch?")
            continue
        if reloj() - ultimo < intervalo_s:
            continue
        try:
            cond = construir_condiciones(a_kelvin(valor, unidad), campo=campo, **ajustes)
            ultimo = reloj()
            temp_k = cond["temperatura_reaccion_k"] if campo == "reaccion" else cond["temperatura_ambiente_k"]
            try:
                r = enviador(url, cond)
            except (ValueError, urllib.error.URLError, TimeoutError, OSError):
                if pulsador is not None:
                    pulsador(None)  # el sensor está vivo aunque la API rechace la consulta
                raise
            if pulsador is not None:
                pulsador({"temperatura_k": temp_k, "campo": campo, "indice_riesgo": r.get("indice_riesgo"), "nivel_riesgo": r.get("nivel_riesgo")})
        except (ValueError, KeyError, TypeError, urllib.error.URLError, TimeoutError, OSError) as error:
            salida(f"[ERROR] lectura {valor:g}: {error}")
            continue
        respuestas += 1
        salida(f"[{time.strftime('%H:%M:%S')}] sensor={valor:g} {unidad.upper()} → índice={r.get('indice_riesgo')} "
               f"nivel={r.get('nivel_riesgo')} propaga={r.get('probabilidad_propagacion')} llama_fría={r.get('estado_llama_fria')}")
        if campo == "reaccion" and a_kelvin(valor, unidad) < UMBRAL_SIN_LLAMA_K:
            salida("    nota: lectura cercana al ambiente (sin evidencia de llama); el índice refleja el POTENCIAL del entorno, no un evento")
        for aviso in r.get("advertencias", []):
            salida(f"    aviso: {aviso}")
        if detallado:
            salida(json.dumps(r, ensure_ascii=False, indent=2))
    return respuestas


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--puerto", default=PUERTO_POR_DEFECTO, help="COM3, /dev/ttyACM0, ... (por defecto COM3)")
    ap.add_argument("--baudios", type=int, default=BAUDIOS_POR_DEFECTO)
    ap.add_argument("--url", default=URL_POR_DEFECTO)
    ap.add_argument("--unidad", choices=("c", "k", "f"), default="c", help="unidad de lo que envía el Arduino (por defecto Celsius)")
    ap.add_argument("--campo", choices=tuple(RANGO_K), default="ambiente", help="qué mide el sensor: aire ambiente (DHT11, por defecto) o zona de reacción (termopar sobre la llama)")
    ap.add_argument("--intervalo", type=float, default=0.5, help="segundos mínimos entre consultas a la API")
    ap.add_argument("--o2", type=float, default=0.21, help="fracción de O₂ (valor fijo declarado)")
    ap.add_argument("--presion", type=float, default=101.3, help="presión en kPa (valor fijo declarado)")
    ap.add_argument("--flujo", type=float, default=10.0, help="flujo en cm/s (valor fijo declarado)")
    ap.add_argument("--temp-ambiente", type=float, default=295.0, help="K, solo si el sensor mide la reacción")
    ap.add_argument("--espesor", type=float, default=0.2)
    ap.add_argument("--material", choices=("sibal", "pmma", "celulosa"), default="sibal")
    ap.add_argument("--regimen", choices=("opuesto", "concurrente"), default="opuesto")
    ap.add_argument("--columna", type=int, default=None, help="si la línea trae varios números sin etiqueta (p. ej. humedad,temperatura), cuál es la temperatura (1 = primero)")
    ap.add_argument("--dispositivo", default="Arduino R3", help="nombre que verá el HUD en /api/v1/hardware/ping")
    ap.add_argument("--stdin", action="store_true", help="lee las lecturas de la entrada estándar (prueba sin Arduino)")
    ap.add_argument("--detallado", action="store_true", help="imprime también la respuesta JSON completa")
    a = ap.parse_args(argv)
    for flujo in (sys.stdout, sys.stderr):  # la consola de Windows (cp1252/cp437) no codifica «→»: nunca debe tumbar el puente
        if hasattr(flujo, "reconfigure"):
            flujo.reconfigure(errors="replace")
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    ajustes = {"o2": a.o2, "presion_kpa": a.presion, "flujo_cm_s": a.flujo, "temp_ambiente_k": a.temp_ambiente, "espesor_mm": a.espesor,
               "material": a.material, "regimen": a.regimen}
    fuente: Iterable[bytes | str] = sys.stdin if a.stdin else lineas_serial(a.puerto, a.baudios)
    logger.info("Puente IGNIS → %s (%s, %s)", a.url, "stdin" if a.stdin else f"{a.puerto}@{a.baudios}", f"sensor en {a.unidad.upper()}, campo {a.campo}")
    destino_pulso = url_pulso(a.url)

    def pulsar(lectura: dict[str, Any] | None = None) -> None:
        """Avisa al HUD que el sensor está vivo (con la última lectura); un fallo aquí nunca interrumpe las lecturas."""
        cuerpo: dict[str, Any] = {"dispositivo": a.dispositivo}
        if lectura and isinstance(lectura.get("indice_riesgo"), (int, float)):
            cuerpo.update({k: (round(v, 2) if isinstance(v, float) else v) for k, v in lectura.items() if v is not None})
        elif lectura:
            cuerpo.update({k: v for k, v in lectura.items() if k in ("temperatura_k", "campo")})
        try:
            enviar(destino_pulso, cuerpo, timeout_s=2.0)
        except (ValueError, urllib.error.URLError, TimeoutError, OSError) as error:
            logger.debug("Pulso no enviado: %s", error)

    try:
        procesar(fuente, url=a.url, unidad=a.unidad, campo=a.campo, intervalo_s=a.intervalo, ajustes=ajustes, detallado=a.detallado, columna=a.columna, pulsador=pulsar)
    except KeyboardInterrupt:
        logger.info("Puente detenido por el usuario")
    return 0


if __name__ == "__main__":
    sys.exit(main())
