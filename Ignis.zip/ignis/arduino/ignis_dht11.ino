// IGNIS — sketch de ejemplo para Arduino UNO R3 + DHT11 (SUPUESTO: señal en el pin digital 2).
// Biblioteca: "DHT sensor library" de Adafruit (Gestor de bibliotecas del IDE; instala también "Adafruit Unified Sensor").
// Salida a 9600 baudios, una línea cada 2 s:  T=24.0   (el puente también entiende «Temperatura: 24.0 *C»).
// El DHT11 mide AIRE (0-50 °C, ±2 °C) y humedad; NO detecta llamas. Cierre el Monitor Serie del IDE antes de usar el puente.
#include <DHT.h>

#define PIN_DHT 2
DHT dht(PIN_DHT, DHT11);

void setup() {
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  delay(2000);  // el DHT11 admite como máximo 1 lectura por segundo
  float t = dht.readTemperature();  // °C
  if (isnan(t)) {
    Serial.println("ERROR lectura DHT11");  // el puente lo cuenta como línea inválida y sigue
    return;
  }
  Serial.print("T=");
  Serial.println(t, 1);
}
