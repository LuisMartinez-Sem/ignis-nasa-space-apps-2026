# Changelog

## [1.5.1-gas] — Modo gas experimental (solo modelo y predictor)
### Añadido
- `src/modo_gas.py` y `scripts/entrenar_gases.py`: modelo Random Forest SEPARADO para gases entrenado con las tablas CFI-G (PSI-159) en `data/raw/gases/` (323 ensayos útiles; la tabla Inversa trae ~860 filas vacías). Predice P(ignición caliente) y tiempo de quemado; columna `tipo_combustible`.
- `PredictorIgnis.evaluar(..., modo="solido"|"gas")`: por defecto sólido (sin cambios).
- Validación dejando fuera días completos: AUC 0.79, Brier 0.127 frente a 0.151 del modelo trivial, R² (log del tiempo) 0.60. Modelo de sólidos intacto (error Saffire 0.9 %, huella SHA-256 verificada por test).
- Limitaciones: una sola investigación, ~81 % de ignición, fuera del dominio de sólidos (≈220 kPa, O₂ hasta 85 %), no alimenta el índice de riesgo ni el Dashboard.

## [1.5.2] — Usabilidad del Dashboard (solo frontend)
### Añadido
- **Notas del investigador** (botón «Notas»): panel lateral con nota por investigación seleccionada, notas generales, lista de tareas, exportación a TXT y guardado local (`localStorage`); contiene el interruptor de las notas de verificación.
- **Buscador** en el Ranking: filtro en tiempo real por nombre, combustible o hardware (sin acentos ni mayúsculas), con contador y botón de limpiar.
### Cambiado
- Nombres legibles en fichas, comparación, Pareto e Informe de confianza (`areas_seguridad` → «áreas de seguridad», etc.; módulo `etiquetas.js`).
- Pareto: lista lateral ordenada por prioridad, clicable y con resaltado del punto en el gráfico (también al pasar el cursor).
### Corregido
- «Cómo se calcula (método y supuestos)» ahora despliega su texto.

## [1.5.1] — Dashboard pulido e Informe de confianza
### Añadido
- **Informe de confianza** (`/api/v1/investigaciones/{id}/confianza` y `.pdf`; pestaña «Confianza»): cuánto respaldo tiene el riesgo de cada investigación (entradas verificadas / inferidas / supuestas), cálculo explícito `evidencia × combustible × gravedad × validación`, análisis tornado (qué dato pedir primero a PSI) y PDF de una página.
- Respaldo verificado/supuesto en la pestaña Base lunar, con desglose del índice (55 + 30 + 15) y controles de flujo y material.
- Clasificación sugerida por palabras clave (combustible, familia, áreas) para investigaciones nuevas; queda marcada como «sugerida» hasta confirmarla.
- Incidentes propios: agregar (con fuente obligatoria, siempre «no verificado») y quitar; los incidentes base no se pueden quitar.
- Laboratorio de la llama (gravedad 0–1 g) y flujo «microgravedad → hallazgo → Tierra» en «Del espacio a la Tierra».
### Cambiado
- Pareto: lienzo nítido a 1366×768 (sobremuestreo 2×, caja con tamaño propio, redibujo al mostrar la pestaña), guía de lectura, hipervolumen y prioridad explicados, lista de puntos que comparten posición.
- Demo guiada: resalta el elemento explicado, texto grande y teclas ← → Espacio Esc con captura en la ventana.
- «Huecos» pasa a «Hoja de ruta»: oportunidades de investigación y siguiente paso con versión; los límites siguen declarados.
- Reproductor de incidentes: marcas numeradas con lista de eventos y barra de avance.
- El Dashboard solo muestra los controles que le corresponden; Caja negra, audio, hardware e historial del índice son del Monitor.
- Licencia y CITATION incluyen a Elias Navarro Lopez.
### Retirado
- Módulos vacíos y scripts de empaquetado de versiones anteriores; datos de prueba del paquete.

## [1.5.0] — Datos de prueba, demo guiada y Monitor con contexto
- Datos de prueba (CSV): `GET/POST/DELETE /api/v1/investigaciones/prueba` (+ `/plantilla`); reversible, marcado PRUEBA, mismo mapeo y unidades que la ingesta real. Tras importar se actualizan ranking, KPIs, Pareto, mapa, comparación, huecos y Tierra al instante. Verificado: fracción 0,35 → 35 %, 10,2 psi → 70,327 kPa, m/s → cm/s; CSV inválidos se rechazan con mensaje.
- Demo guiada (`demo.js`, 10 pasos, ≈ 90 s, teclado y pausa) con acciones reales; retira lo que cargó al salir.
- Monitor: panel de hardware permanente (columna izquierda, gráfica en vivo) y panel «Atmósfera en contexto» (`contexto.js`: pO₂ = fracción × presión, enriquecimiento frente al aire, región según los umbrales del reto).
- Docs: `docs/cumplimiento_reto.md` (matriz del reto), README renovado con capturas.
- Pruebas: +3 Node (`contexto`); importador cubierto en `tests/test_importacion_prueba.py`.

## [1.4.0] — Consola de Investigaciones (rediseño visual completo)
- Vista Investigaciones reorganizada como consola: KPIs, ranking lateral con botón ＋ (sin casillas), bandeja de comparación y estación con 7 pestañas (Análisis, Pareto, Mapa de riesgo, Base lunar, Comparar, Huecos, Del espacio a la Tierra).
- Mapa de riesgo interactivo (`mapa.js`): campo continuo del modelo, cobertura experimental, anclas, entornos, isolínea de pO₂ terrestre y sonda que evalúa cualquier punto con `/predict`; teclado accesible.
- Pareto (`pareto.js`): eje Y elegible, banda P10–P90, P(frontera) por Monte Carlo (semilla fija), dominados, lista de prioridad, animación al cambiar datos.
- Base lunar (`atmosfera.js`): anillos Luna vs ISS, delta explicado, sliders dentro del dominio del modelo, «Abrir en el Monitor» y «Verla en el mapa».
- Hardware: chip y panel con estado en vivo y gráfica (`GET /api/v1/hardware/lectura`); casilla opcional que envía la temperatura del termopar al gemelo. El DHT11 (aire) NO mueve el gemelo, solo ±4 pts del índice.
- Datos nuevos: sondeo de `/investigaciones/estado` por huella; al cambiar se refresca todo y se avisa. Fichas provisionales «NUEVA».
- Fix de layout: columna del body con `minmax(0,1fr)` (sin desborde horizontal en móvil).
- Pruebas: +8 Node (mapa, pareto, hardware, comparación). Límite: no se probó con hardware físico ni con `docker build`; el modelo sigue siendo sintético calibrado, no validado.

## [1.3.4] — Estado del hardware y HUD más limpio
- `GET/POST /api/v1/hardware/ping` (`api/routes/hardware.py`): `conectado` es true si el último pulso del puente tiene ≤ 5 s; `hardware_bridge.py` envía el pulso tras cada lectura válida (`--dispositivo`).
- HUD: notas de verificación y limitaciones ocultas por defecto (botón «Notas: on/off» en la cabecera); la etiqueta «Validación pendiente» ya no se muestra (si hay un validador registrado, sí).
- `tests/test_hardware_ping.py`.
- Límite: la marca de tiempo vive en memoria y el endpoint no autentica (red local de la demo).

## [1.3.3] — Preset lunar explicado y fuentes del catálogo
- `POST /api/v1/preset/lunar`: nuevo campo `explicacion` (delta calculado, no escrito a mano); el HUD lo muestra.
- `data/investigaciones.json`: `fuente` específica por investigación (antes las 19 decían lo mismo, incluso Saffire-I cuyos O₂/presión vienen de un ancla del equipo); respaldo regenerado.
- Tests de ambos cambios en `tests/test_robustez.py`.

## [1.3.2] — Validación del puente con Arduino UNO + DHT11
- `hardware_bridge.py`: el parser reconoce «Temperatura:» y descarta humedad/líneas ambiguas (antes tomaba el primer número = humedad), `--columna`, campo por defecto `ambiente`, reconexión ante puerto ocupado/desconectado (incluye `OSError`), aviso de silencio, límite de avisos con basura y consola de Windows segura.
- `arduino/ignis_dht11.ino` (pin 2 supuesto), `docs/guia_arduino_windows.md`; tests de basura, desconexión y esquema real.
- NO verificado: ejecución con hardware físico ni en Windows (probado con puerto simulado en Linux).

## [1.3.1] — Preparación de hardware y del 13 de noviembre (sin features de backend)
- `hardware_bridge.py` (Arduino por serial → `POST /api/v1/predict`), `requirements-hardware.txt`, `tests/test_hardware_bridge.py`.
- `docs/guia_ingesta.md`.
- Corregido: la telemetría ISS simulada podía superar 101,325 kPa (fuera del dominio) y hacía fallar a veces un test; ahora se centra en 101,0 kPa.
- NO verificado: lectura con un Arduino físico (probado con puerto simulado y por entrada estándar).

## [1.3.0] — Code freeze y despliegue con contenedores
Congelamiento del backend: sin features nuevas respecto de 1.2.0.
### Añadido
- `Dockerfile` (Python 3.13-slim, PyTorch CPU, usuario no root, `HEALTHCHECK` sobre `/health`), `docker-compose.yml` (`docker compose up --build`), `.dockerignore`, `constraints.txt` (versiones probadas; el `.joblib` depende de scikit-learn).
- `data/raw` se monta como volumen para los datos de la NASA del 13 de noviembre.
### Verificación
- pytest completo en verde (232 pruebas) y Node 21/21.
- Copia limpia sin `node_modules` en modo producción: `/health`, HUD, Pareto, mapa, catálogo y preset lunar responden 200.
- NO verificado: `docker build` (el entorno de desarrollo no tenía daemon de Docker). Probarlo antes del evento.

## [1.2.0] — Análisis de Frontera de Pareto
### Añadido
- `GET /api/v1/investigaciones/pareto?entorno=iss|luna|marte`: riesgo del modelo (con intervalo por incertidumbre) × evidencia (0-100) de las 19 investigaciones, capas no dominadas, frontera, codo, hipervolumen y estructura lista para scatter (`src/pareto.py`, `api/routes/pareto.py`).
- Panel «Frontera de Pareto» en Investigaciones (`frontend/js/pareto.js`): scatter en canvas, cuadrante crítico, barras de incertidumbre, lista accesible.
- Tests: `tests/test_pareto.py`, `frontend/test/pareto.test.mjs`.
### Limitaciones
- Con PSI sin leer, el riesgo es casi igual para todas (campos inferidos del entorno); la separación llegará con los datos reales.

## [1.1.1] — Robustez y preparación 13 de noviembre
### Añadido
- `/api/v1/investigaciones` nunca devuelve 500: respaldo hardcodeado con las 19 investigaciones (`src/investigaciones_respaldo.py`, generado con `scripts/regenerar_respaldo.py`), recarga en caliente por mtime y badge de catálogo de respaldo.
- `scripts/ingestar_datos_nasa.py`: lee CSV/JSON de `data/raw/`, mapea al catálogo, falla con aviso en consola; idempotente, conflictos reportados sin sobrescribir.
- `POST /api/v1/preset/lunar` devuelve `monitor.sliders` (O₂ 30 %, 70.0 kPa); slider de presión y botón «Cargar en el Monitor».
- Mejora propia: mapa de riesgo atmosférico y de evidencia (`GET /api/v1/mapa-riesgo`); presión en el ranking.
- `tests/test_robustez.py`: la API sigue viva si se borra o corrompe el archivo.
### Limitaciones
- Preset usa 70.0 kPa (válido ≤ 70.3); falta procesar video→velocidad de datos crudos.

## [1.1.0] — SI Dashboard (reto NASA 2026)
### Añadido
- Vista principal **Investigaciones** (ranking por entorno, desglose, comparación, mapa de huecos, exportación CSV/JSON, preset lunar, aplicaciones en la Tierra). El Monitor pasa a pestaña aparte.
- `data/investigaciones.json` (19), `src/investigaciones.py`, `api/routes/investigaciones.py`, `api/routes/preset.py`, `frontend/js/investigaciones.js`, `frontend/css/investigaciones.css`; tests de Python y Node.
- Informes PDF (forense y en vivo), `/api/v1/iss/telemetria` (simulada), `/api/v1/si-insights`, `scripts/simulador_hardware.py`, `scripts/empaquetar_todo.py`.
### Corregido
- Apollo 1 mostraba `undefined` (faltaba `indice_con_aire`); favicon 404; el historial del Monitor aparecía en otras vistas.
### Limitaciones
- Metadatos reales de PSI no leídos; ranking heurístico no validado; sin modelo de supresión; módulos `bundle/reconstruccion/whatif.js` siguen como placeholders.

## [0.4.3] — Dataset híbrido y Modo Emergencia
### Añadido
- `data/anclas_reales.json` (6 anclas: 3 de entrenamiento, 3 de referencia) e inyección en `generar_dataset_sintetico` (40 filas por ancla; 6000 en total).
- `src/emergencias.py`: `mir-1997`, `iss-2015`, `columbus-cool-flame`, `saffire-cable`. Los tiempos de IGNIS se **miden** con el TCN y el predictor; los objetivos de diseño (0,7 s, 1,2 s, 2 s, 1,5 s, 3 s) quedan en `objetivos_diseno`. Ahorro = ventana de oportunidad contrafactual. La localización 3D se declara **no implementada**.
- `GET /api/v1/emergencias[/{id}]`.
- Corrección Mir 1997: detección visual en t=0, extinción a 90 s, extintores de ESPUMA (el CO₂ es de la ISS); guía «Aislar sector y usar espuma»; comparación detección de IGNIS vs extinción.
- `trazar_detector` en `src/escenarios.py`; `tests/test_anclas_reales.py` (11) y `tests/test_emergencias.py` (8).
### Cambiado
- Calibración: `VELOCIDAD_REFERENCIA_MM_S` 8,0 → 3,7905; `FACTOR_CONCURRENTE` 1,4 → 1,2802; llama fría centro 675 K, ancho 150 K (550–800 K = semimáximo).
- **Desviación:** normalización del índice `tanh(v/10)` → `tanh(v/4,74)` (con 10, CRÍTICO era inalcanzable). Revertir en `predictor.py`, `paleta.js` e `index.html`.
- Error en Saffire-I 193 % → 0,9 %: **calibración, no validación** (las anclas están en el entrenamiento). Modelos reentrenados (RF R² 0,952; profundo R² 0,991).
### Nota
- Fuentes no verificadas por IGNIS: NTRS 20170002628, PSI-98/99, FLEX (Nayagam).

## [0.4.2] — Pivote de datos de PSI
### Cambiado
- `docs/psi_integracion.md` reescrito: los CSV de PSI son índices, los crudos son imágenes que requieren procesamiento; IGNIS usa un dataset sintético calibrado con valores publicados. Sin cambios en el pipeline.
- `docs/pitch.md` con sección "Dataset" y línea honesta; `pitch_3min`, `preguntas_jueces`, `pitch_30s` y `validacion_externa` alineados.

## [0.4.0] — Física y datos reales (en curso)
### Añadido
- Dominio operativo O₂ 0,16–0,40 y P 35–101,325 kPa con advertencias de extrapolación; atmósferas históricas fuera de dominio no se evalúan.
- Índice de riesgo con `tanh` y pesos 0,55/0,30/0,15; `GET /api/v1/modelo/variables_no_incluidas`; `docs/science.md` ampliado.
- Ingesta PSI: `src/lector_psi.py` (CSV/HDF5/JSON, unidades), `src/ingesta_psi.py` (cobertura), `scripts/descargar_psi.py`, `src/reporte_psi.py` (línea base, comparativa RF vs profundo, línea del pitch).
- Dependencia nueva: `h5py`.
- Backend: `src/escenarios.py` + `GET /api/v1/escenarios[/{id}/reproduccion]` (guiones evaluados con RF/profundo y TCN, latencias medidas).
- HUD: reproducción cinemática (0.5×–10×, doble línea de tiempo clicable, latencia sensor→TCN→copiloto, "qué pasaría si"), foco 3D, botón *¿Qué ve el astronauta?* + contraste térmico, mensajes estructurados del copiloto, sonificación (6 tonos, armonía rota, latido 60→140 lpm, voz en CRÍTICO; apagada por defecto), badge "Validación pendiente".
- Evento vs potencial latente: sin reacción térmica ni alarma, el HUD no muestra ALERTA/CRÍTICO.
- Docs: `psi_integracion`, `validacion_externa`, `pitch_3min`, `pitch_30s`, `preguntas_jueces`; `LICENSE` (MIT), `CITATION.cff`.
### Corregido
- Sliders manuales de O₂ ajustados al dominio (16–40 %); antes permitían valores que la API rechaza (422).

## [0.3.0] — Salto "x3"
### Añadido
- **Deep learning**: ensemble profundo con incertidumbre (`modelo_profundo.py`) y afinado con datos reales; **detector temporal TCN** causal para llamas frías (`detector_temporal.py`, ≈1 ms/muestra) con benchmark contra umbral fijo, umbral calibrado y cámara visible.
- Predictor multi-motor (RF / profundo), detección de **fuera de dominio**, explicabilidad local, régimen de flujo concurrente.
- **Pipeline de datos** versionado (`data/versiones`, SHA-256, mapeo de unidades, perfil de cobertura) y CLI de entrenamiento con reporte (`modelos/reporte.json`).
- **Simulador de incidentes** (Mir, Apollo 1, ISS 2015, Saffire) con confianza por hecho, fuentes y comparativa contrafactual.
- API: `/api/v1/incidentes*`, `/modelo/*`, `/datos/*`, `/explain`, `?motor=`, `WS /ws/sensores`, middleware de seguridad, tope de conexiones WS.
- **Frontend 3.0**: gemelo digital Three.js (visión IR/dividida, llama fría solo en IR), anillos 3D, panel del detector, copiloto con comparación de motores, sonificación Web Audio, vista de incidentes. Todo vendorizado (offline).
- Tests: 106 (modelo profundo, pipeline, detector, incidentes, servicio).
### Cambiado
- Rango de O₂ del dominio hasta 100 % (con advertencia de extrapolación).

## [0.1.0]
### Añadido
- Núcleo ML: carga/validación de datos, preprocesamiento, modelo RF (velocidad + probabilidad de propagación con incertidumbre).
- Módulo de Cool Flames (heurístico, pendiente de calibración con FLEX/BASS).
- Predictor con índice de riesgo 0–100 y acciones de apoyo a decisión.
- API FastAPI: `/health`, `/api/v1/predict`, `/api/v1/predict/batch`, `/api/v1/model/info`, WebSockets `/ws/predict` y `/ws/demo`.
- Tests pytest de datos, modelo y API.
